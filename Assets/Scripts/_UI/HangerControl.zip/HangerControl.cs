﻿using UnityEngine;
using System.Collections;
using System;
using System.IO;

public class HangerControl : MonoBehaviour
{
    #region Variables
    public GameObject flights;
    public GameObject ResultPanel;
    public GameObject halfBLKPanel;
    public GameObject rescueAchieveWindow;
    public GameObject soundControlWindow;
    public GameObject allBuyWindow;
    public GameObject pilotLevelUpWindow;

    public GameObject storeWindow;

    public GameObject friendWindow;
    public GameObject friendWeekTab;
    //public GameObject friendInviteTab;
    public GameObject friendMailTab;
    //public GameObject eventTab;

    public GameObject equipWindows;
    public GameObject equipBombTab;
    public GameObject equipReinforceTab;
    public GameObject equipAssistanceTab;
    public GameObject equipOperTab;

    public GameObject skinSelectWindow00;
    public GameObject skinSelectWindow01;
    public GameObject skinSelectWindow02;

    public GameObject GasShortageWindow;
    public GameObject CoinShortageWindow;
    public GameObject MedalShortageWindow;

    public GameObject purchaseConfirmWindow;
    //public GameObject goldPurchaseText;

    public GameObject duraBuyAlarmWindow;

    public GameObject prepareReady;
    public GameObject attackReady;

    public GameObject spIcon01;
    public GameObject spIcon02;



    public GameObject mountIconTemp;
    public Vector3 mountIconPositionTemp;

    string[] bombSpriteName;
    string[] reinforceSpriteName;
    string[] assistSpriteName;
    string[] operSpriteName;

    public GameObject[] specialAttackIcon;
    public GameObject[] specialAttackText;
    public string[] specialAttackName;

    DateTime specialEndTime;

    int specialRestTimeText;

    public GameObject specialRestTimeLabel01;
    //public GameObject specialRestTimeLabel02;


    public int specialDart = 1000;  //원래 1000.
    public int specialSpinball = 1500;  //원래 1500.
    public int specialDust = 2000;  //원래 2000.
    public int specialShield = 300; //원래 300.

    public AudioClip popupClose;
    public AudioClip popupDisplay;

    public AudioClip levelPopupDisplay; //레벨업창 나타날때.

    GameObject winMove;

    GameObject windows;


    string testString;

    bool equipToStoreOn = false;
    bool skin00ToStoreOn = false;
    bool skin01ToStoreOn = false;
    bool skin02ToStoreOn = false;
    bool storeToFriendOn = false;
    bool resultToStoreOn = false;
    bool mainToFriendOn = false;

    public GameObject equipItemName;
    public GameObject equipItemScript;
    public GameObject equipItemPrice;

    public GameObject bgTop;
    public GameObject bgBottom;

    public FlightUpointSetScript flightUpointSetScript;

    public GameObject upgradePointWindow;

    [NonSerialized]
    public bool isSkinFullLevel = false;

    public GameObject noTouchPanel;

    bool gameEndResult;

    int resultSkinNumber;
    string resultSkinName;


    int billingResult = 0;
    int itemNum = 0;
    #endregion


    void Awake()
    {
        //ValueDeliverScript.flightNumber = int.Parse(ValueDeliverScript.gameData["flightNumber"].ToString());
        ValueDeliverScript.resultSkinnumber = resultSkinNumber = ValueDeliverScript.skinNumber;
        resultSkinName = "FlightDura" + ValueDeliverScript.flightNumber.ToString("D3") + "Skin" + ValueDeliverScript.skinNumber.ToString("D3");

        gameEndResult = ValueDeliverScript.gameEndResult;

        if (gameEndResult == true)  // 결과창 사운드 결과창 사운드인지 일반 싸운드 인지 결정하는 부분.
        {
            if (ValueDeliverScript.bgSound == 0.5f)
            {
                GameObject.Find("ResultSoundManager").GetComponent<AudioSource>().volume = 1f;
                GameObject.Find("BgSoundManager").GetComponent<AudioSource>().volume = 0f;
            }
        }

        Time.timeScale = 1f;

        winMove = GameObject.Find("WinMove");
        windows = GameObject.Find("Windows");

        #region 스페셜 출격 관련 비행기 처치 수 서버에서 가져옴.
        specialDart = ValueDeliverScript.specialDart;
        specialSpinball = ValueDeliverScript.specialSpinball;
        specialDust = ValueDeliverScript.specialDust;
        specialShield = ValueDeliverScript.specialShield;
        #endregion


        #region 각종 창들 안보이게 액티브 끔.
        halfBLKPanel.SetActive(false);
        rescueAchieveWindow.SetActive(false);
        soundControlWindow.SetActive(false);
        allBuyWindow.SetActive(false);
        pilotLevelUpWindow.SetActive(false);

        storeWindow.SetActive(false);
        friendWindow.SetActive(false);
        GasShortageWindow.SetActive(false);

        purchaseConfirmWindow.SetActive(false);
        duraBuyAlarmWindow.SetActive(false);

        spIcon01.SetActive(false);
        spIcon02.SetActive(false);

        specialRestTimeLabel01.SetActive(false);
        #endregion





        #region 스킨 잠금 해제 가격 세팅.해쉬테이블에 오브젝트(변수) 생성.
        if (!ValueDeliverScript.isSkinMedalCostLoad)
        {
            ValueDeliverScript.skinMedalCost.Add("Flight000Skin001", 10000);
            ValueDeliverScript.skinMedalCost.Add("Flight000Skin002", 15000);
            ValueDeliverScript.skinMedalCost.Add("Flight000Skin003", 25000);
            ValueDeliverScript.skinMedalCost.Add("Flight000Skin004", 45);
            ValueDeliverScript.skinMedalCost.Add("Flight000Skin005", 35000);

            ValueDeliverScript.skinMedalCost.Add("Flight001Skin001", 22000);
            ValueDeliverScript.skinMedalCost.Add("Flight001Skin002", 37000);
            ValueDeliverScript.skinMedalCost.Add("Flight001Skin003", 47000);
            ValueDeliverScript.skinMedalCost.Add("Flight001Skin004", 80);
            ValueDeliverScript.skinMedalCost.Add("Flight001Skin005", 57000);

            ValueDeliverScript.skinMedalCost.Add("Flight002Skin001", 35000);
            ValueDeliverScript.skinMedalCost.Add("Flight002Skin002", 50000);
            ValueDeliverScript.skinMedalCost.Add("Flight002Skin003", 80000);
            ValueDeliverScript.skinMedalCost.Add("Flight002Skin004", 120);
            ValueDeliverScript.skinMedalCost.Add("Flight002Skin005", 150000);

            ValueDeliverScript.isSkinMedalCostLoad = true;
        }

        #endregion


        #region 내구도가격 ::: 스킨,레벨별 세팅.해쉬테이블에 오브젝트(변수) 생성.
        if (!ValueDeliverScript.isDuraCostLoad)
        {
            ValueDeliverScript.duraCost.Add("Flight000Skin001Level001", 300);
            ValueDeliverScript.duraCost.Add("Flight000Skin001Level002", 400);
            ValueDeliverScript.duraCost.Add("Flight000Skin001Level003", 500);
            ValueDeliverScript.duraCost.Add("Flight000Skin001Level004", 600);
            ValueDeliverScript.duraCost.Add("Flight000Skin001Level005", 700);
            ValueDeliverScript.duraCost.Add("Flight000Skin001Level006", 800);
            ValueDeliverScript.duraCost.Add("Flight000Skin001Level007", 900);
            ValueDeliverScript.duraCost.Add("Flight000Skin001Level008", 1000);
            ValueDeliverScript.duraCost.Add("Flight000Skin001Level009", 1100);
            ValueDeliverScript.duraCost.Add("Flight000Skin001Level010", 1200);

            ValueDeliverScript.duraCost.Add("Flight000Skin002Level001", 300);
            ValueDeliverScript.duraCost.Add("Flight000Skin002Level002", 400);
            ValueDeliverScript.duraCost.Add("Flight000Skin002Level003", 500);
            ValueDeliverScript.duraCost.Add("Flight000Skin002Level004", 600);
            ValueDeliverScript.duraCost.Add("Flight000Skin002Level005", 700);
            ValueDeliverScript.duraCost.Add("Flight000Skin002Level006", 800);
            ValueDeliverScript.duraCost.Add("Flight000Skin002Level007", 900);
            ValueDeliverScript.duraCost.Add("Flight000Skin002Level008", 1000);
            ValueDeliverScript.duraCost.Add("Flight000Skin002Level009", 1100);
            ValueDeliverScript.duraCost.Add("Flight000Skin002Level010", 1200);

            ValueDeliverScript.duraCost.Add("Flight000Skin003Level001", 300);
            ValueDeliverScript.duraCost.Add("Flight000Skin003Level002", 400);
            ValueDeliverScript.duraCost.Add("Flight000Skin003Level003", 500);
            ValueDeliverScript.duraCost.Add("Flight000Skin003Level004", 600);
            ValueDeliverScript.duraCost.Add("Flight000Skin003Level005", 700);
            ValueDeliverScript.duraCost.Add("Flight000Skin003Level006", 800);
            ValueDeliverScript.duraCost.Add("Flight000Skin003Level007", 900);
            ValueDeliverScript.duraCost.Add("Flight000Skin003Level008", 1000);
            ValueDeliverScript.duraCost.Add("Flight000Skin003Level009", 1100);
            ValueDeliverScript.duraCost.Add("Flight000Skin003Level010", 1200);

            ValueDeliverScript.duraCost.Add("Flight000Skin004Level001", 300);
            ValueDeliverScript.duraCost.Add("Flight000Skin004Level002", 400);
            ValueDeliverScript.duraCost.Add("Flight000Skin004Level003", 500);
            ValueDeliverScript.duraCost.Add("Flight000Skin004Level004", 600);
            ValueDeliverScript.duraCost.Add("Flight000Skin004Level005", 700);
            ValueDeliverScript.duraCost.Add("Flight000Skin004Level006", 800);
            ValueDeliverScript.duraCost.Add("Flight000Skin004Level007", 900);
            ValueDeliverScript.duraCost.Add("Flight000Skin004Level008", 1000);
            ValueDeliverScript.duraCost.Add("Flight000Skin004Level009", 1100);
            ValueDeliverScript.duraCost.Add("Flight000Skin004Level010", 1200);

            ValueDeliverScript.duraCost.Add("Flight000Skin005Level001", 300);
            ValueDeliverScript.duraCost.Add("Flight000Skin005Level002", 400);
            ValueDeliverScript.duraCost.Add("Flight000Skin005Level003", 500);
            ValueDeliverScript.duraCost.Add("Flight000Skin005Level004", 600);
            ValueDeliverScript.duraCost.Add("Flight000Skin005Level005", 700);
            ValueDeliverScript.duraCost.Add("Flight000Skin005Level006", 800);
            ValueDeliverScript.duraCost.Add("Flight000Skin005Level007", 900);
            ValueDeliverScript.duraCost.Add("Flight000Skin005Level008", 1000);
            ValueDeliverScript.duraCost.Add("Flight000Skin005Level009", 1100);
            ValueDeliverScript.duraCost.Add("Flight000Skin005Level010", 1200);

            ValueDeliverScript.duraCost.Add("Flight001Skin001Level001", 300);
            ValueDeliverScript.duraCost.Add("Flight001Skin001Level002", 450);
            ValueDeliverScript.duraCost.Add("Flight001Skin001Level003", 600);
            ValueDeliverScript.duraCost.Add("Flight001Skin001Level004", 750);
            ValueDeliverScript.duraCost.Add("Flight001Skin001Level005", 900);
            ValueDeliverScript.duraCost.Add("Flight001Skin001Level006", 1050);
            ValueDeliverScript.duraCost.Add("Flight001Skin001Level007", 1200);
            ValueDeliverScript.duraCost.Add("Flight001Skin001Level008", 1350);
            ValueDeliverScript.duraCost.Add("Flight001Skin001Level009", 1500);
            ValueDeliverScript.duraCost.Add("Flight001Skin001Level010", 1650);
            ValueDeliverScript.duraCost.Add("Flight001Skin002Level001", 300);
            ValueDeliverScript.duraCost.Add("Flight001Skin002Level002", 450);
            ValueDeliverScript.duraCost.Add("Flight001Skin002Level003", 600);
            ValueDeliverScript.duraCost.Add("Flight001Skin002Level004", 750);
            ValueDeliverScript.duraCost.Add("Flight001Skin002Level005", 900);
            ValueDeliverScript.duraCost.Add("Flight001Skin002Level006", 1050);
            ValueDeliverScript.duraCost.Add("Flight001Skin002Level007", 1200);
            ValueDeliverScript.duraCost.Add("Flight001Skin002Level008", 1350);
            ValueDeliverScript.duraCost.Add("Flight001Skin002Level009", 1500);
            ValueDeliverScript.duraCost.Add("Flight001Skin002Level010", 1650);

            ValueDeliverScript.duraCost.Add("Flight001Skin003Level001", 300);
            ValueDeliverScript.duraCost.Add("Flight001Skin003Level002", 450);
            ValueDeliverScript.duraCost.Add("Flight001Skin003Level003", 600);
            ValueDeliverScript.duraCost.Add("Flight001Skin003Level004", 750);
            ValueDeliverScript.duraCost.Add("Flight001Skin003Level005", 900);
            ValueDeliverScript.duraCost.Add("Flight001Skin003Level006", 1050);
            ValueDeliverScript.duraCost.Add("Flight001Skin003Level007", 1200);
            ValueDeliverScript.duraCost.Add("Flight001Skin003Level008", 1350);
            ValueDeliverScript.duraCost.Add("Flight001Skin003Level009", 1500);
            ValueDeliverScript.duraCost.Add("Flight001Skin003Level010", 1650);

            ValueDeliverScript.duraCost.Add("Flight001Skin004Level001", 300);
            ValueDeliverScript.duraCost.Add("Flight001Skin004Level002", 450);
            ValueDeliverScript.duraCost.Add("Flight001Skin004Level003", 600);
            ValueDeliverScript.duraCost.Add("Flight001Skin004Level004", 750);
            ValueDeliverScript.duraCost.Add("Flight001Skin004Level005", 900);
            ValueDeliverScript.duraCost.Add("Flight001Skin004Level006", 1050);
            ValueDeliverScript.duraCost.Add("Flight001Skin004Level007", 1200);
            ValueDeliverScript.duraCost.Add("Flight001Skin004Level008", 1350);
            ValueDeliverScript.duraCost.Add("Flight001Skin004Level009", 1500);
            ValueDeliverScript.duraCost.Add("Flight001Skin004Level010", 1650);

            ValueDeliverScript.duraCost.Add("Flight001Skin005Level001", 300);
            ValueDeliverScript.duraCost.Add("Flight001Skin005Level002", 450);
            ValueDeliverScript.duraCost.Add("Flight001Skin005Level003", 600);
            ValueDeliverScript.duraCost.Add("Flight001Skin005Level004", 750);
            ValueDeliverScript.duraCost.Add("Flight001Skin005Level005", 900);
            ValueDeliverScript.duraCost.Add("Flight001Skin005Level006", 1050);
            ValueDeliverScript.duraCost.Add("Flight001Skin005Level007", 1200);
            ValueDeliverScript.duraCost.Add("Flight001Skin005Level008", 1350);
            ValueDeliverScript.duraCost.Add("Flight001Skin005Level009", 1500);
            ValueDeliverScript.duraCost.Add("Flight001Skin005Level010", 1650);

            ValueDeliverScript.duraCost.Add("Flight002Skin001Level001", 300);
            ValueDeliverScript.duraCost.Add("Flight002Skin001Level002", 500);
            ValueDeliverScript.duraCost.Add("Flight002Skin001Level003", 700);
            ValueDeliverScript.duraCost.Add("Flight002Skin001Level004", 900);
            ValueDeliverScript.duraCost.Add("Flight002Skin001Level005", 1100);
            ValueDeliverScript.duraCost.Add("Flight002Skin001Level006", 1300);
            ValueDeliverScript.duraCost.Add("Flight002Skin001Level007", 1500);
            ValueDeliverScript.duraCost.Add("Flight002Skin001Level008", 1700);
            ValueDeliverScript.duraCost.Add("Flight002Skin001Level009", 1900);
            ValueDeliverScript.duraCost.Add("Flight002Skin001Level010", 2100);

            ValueDeliverScript.duraCost.Add("Flight002Skin002Level001", 300);
            ValueDeliverScript.duraCost.Add("Flight002Skin002Level002", 500);
            ValueDeliverScript.duraCost.Add("Flight002Skin002Level003", 700);
            ValueDeliverScript.duraCost.Add("Flight002Skin002Level004", 900);
            ValueDeliverScript.duraCost.Add("Flight002Skin002Level005", 1100);
            ValueDeliverScript.duraCost.Add("Flight002Skin002Level006", 1300);
            ValueDeliverScript.duraCost.Add("Flight002Skin002Level007", 1500);
            ValueDeliverScript.duraCost.Add("Flight002Skin002Level008", 1700);
            ValueDeliverScript.duraCost.Add("Flight002Skin002Level009", 1900);
            ValueDeliverScript.duraCost.Add("Flight002Skin002Level010", 2100);

            ValueDeliverScript.duraCost.Add("Flight002Skin003Level001", 300);
            ValueDeliverScript.duraCost.Add("Flight002Skin003Level002", 500);
            ValueDeliverScript.duraCost.Add("Flight002Skin003Level003", 700);
            ValueDeliverScript.duraCost.Add("Flight002Skin003Level004", 900);
            ValueDeliverScript.duraCost.Add("Flight002Skin003Level005", 1100);
            ValueDeliverScript.duraCost.Add("Flight002Skin003Level006", 1300);
            ValueDeliverScript.duraCost.Add("Flight002Skin003Level007", 1500);
            ValueDeliverScript.duraCost.Add("Flight002Skin003Level008", 1700);
            ValueDeliverScript.duraCost.Add("Flight002Skin003Level009", 1900);
            ValueDeliverScript.duraCost.Add("Flight002Skin003Level010", 2100);

            ValueDeliverScript.duraCost.Add("Flight002Skin004Level001", 300);
            ValueDeliverScript.duraCost.Add("Flight002Skin004Level002", 500);
            ValueDeliverScript.duraCost.Add("Flight002Skin004Level003", 700);
            ValueDeliverScript.duraCost.Add("Flight002Skin004Level004", 900);
            ValueDeliverScript.duraCost.Add("Flight002Skin004Level005", 1100);
            ValueDeliverScript.duraCost.Add("Flight002Skin004Level006", 1300);
            ValueDeliverScript.duraCost.Add("Flight002Skin004Level007", 1500);
            ValueDeliverScript.duraCost.Add("Flight002Skin004Level008", 1700);
            ValueDeliverScript.duraCost.Add("Flight002Skin004Level009", 1900);
            ValueDeliverScript.duraCost.Add("Flight002Skin004Level010", 2100);

            ValueDeliverScript.duraCost.Add("Flight002Skin005Level001", 300);
            ValueDeliverScript.duraCost.Add("Flight002Skin005Level002", 500);
            ValueDeliverScript.duraCost.Add("Flight002Skin005Level003", 700);
            ValueDeliverScript.duraCost.Add("Flight002Skin005Level004", 900);
            ValueDeliverScript.duraCost.Add("Flight002Skin005Level005", 1100);
            ValueDeliverScript.duraCost.Add("Flight002Skin005Level006", 1300);
            ValueDeliverScript.duraCost.Add("Flight002Skin005Level007", 1500);
            ValueDeliverScript.duraCost.Add("Flight002Skin005Level008", 1700);
            ValueDeliverScript.duraCost.Add("Flight002Skin005Level009", 1900);
            ValueDeliverScript.duraCost.Add("Flight002Skin005Level010", 2100);

            ValueDeliverScript.isDuraCostLoad = true;
        }
        #endregion

        #region 골드구매가격 세팅.해쉬테이블에 오브젝트(변수) 생성.
        if (!ValueDeliverScript.isGoldPriceLoad)
        {
            ValueDeliverScript.goldPrice.Add("GoldPrice001", 10);
            ValueDeliverScript.goldPrice.Add("GoldPrice002", 29);
            ValueDeliverScript.goldPrice.Add("GoldPrice003", 49);
            ValueDeliverScript.goldPrice.Add("GoldPrice004", 79);
            ValueDeliverScript.goldPrice.Add("GoldPrice005", 129);

            ValueDeliverScript.goldPrice.Add("GoldPrice001Num", 7000);
            ValueDeliverScript.goldPrice.Add("GoldPrice002Num", 21000 + 2100);
            ValueDeliverScript.goldPrice.Add("GoldPrice003Num", 35000 + 5300);
            ValueDeliverScript.goldPrice.Add("GoldPrice004Num", 56000 + 11200);
            ValueDeliverScript.goldPrice.Add("GoldPrice005Num", 91000 + 27300);

            ValueDeliverScript.isGoldPriceLoad = true;
        }
        #endregion

        #region 가스(연료)구매가격 세팅.해쉬테이블에 오브젝트(변수) 생성.
        if (!ValueDeliverScript.isGasPriceLoad)
        {
            ValueDeliverScript.gasPrice.Add("GasPrice001", 5);
            ValueDeliverScript.gasPrice.Add("GasPrice002", 10);
            ValueDeliverScript.gasPrice.Add("GasPrice003", 30);
            ValueDeliverScript.gasPrice.Add("GasPrice004", 50);
            ValueDeliverScript.gasPrice.Add("GasPrice005", 100);

            ValueDeliverScript.gasPrice.Add("GasPrice001Num", 5);
            ValueDeliverScript.gasPrice.Add("GasPrice002Num", 10 + 1);
            ValueDeliverScript.gasPrice.Add("GasPrice003Num", 30 + 5);
            ValueDeliverScript.gasPrice.Add("GasPrice004Num", 50 + 8);
            ValueDeliverScript.gasPrice.Add("GasPrice005Num", 100 + 25);

            ValueDeliverScript.isGasPriceLoad = true;
        }
        #endregion

        #region 메달구매가격 세팅.해쉬테이블에 오브젝트(변수) 생성.
        if (!ValueDeliverScript.isMedalPriceLoad)
        {
            ValueDeliverScript.medalPrice.Add("MedalPrice001", 2);
            ValueDeliverScript.medalPrice.Add("MedalPrice002", 4);
            ValueDeliverScript.medalPrice.Add("MedalPrice003", 6);
            ValueDeliverScript.medalPrice.Add("MedalPrice004", 12);
            ValueDeliverScript.medalPrice.Add("MedalPrice005", 100000);

            ValueDeliverScript.medalPrice.Add("MedalPrice001Num", 20);
            ValueDeliverScript.medalPrice.Add("MedalPrice002Num", 40 + 5);
            ValueDeliverScript.medalPrice.Add("MedalPrice003Num", 60 + 15);
            ValueDeliverScript.medalPrice.Add("MedalPrice004Num", 120 + 40);
            ValueDeliverScript.medalPrice.Add("MedalPrice005Num", 1000 + 200);

            ValueDeliverScript.isMedalPriceLoad = true;
        }
        #endregion

        #region 오퍼레이터 락오프 세팅.해쉬테이블에 오브젝트(변수) 생성.
        if (!ValueDeliverScript.isOperaterLockOff)
        {
            ValueDeliverScript.operaterLockOff.Add("Operater000", true);
            ValueDeliverScript.operaterLockOff.Add("Operater001", false);
            ValueDeliverScript.operaterLockOff.Add("Operater002", false);
            ValueDeliverScript.operaterLockOff.Add("Operater003", false);

            ValueDeliverScript.isOperaterLockOff = true;
        }
        #endregion


        #region 총알 가격과 스킬 가격을 창에서 제대로 보이게 세팅.//
        // 총알 가격과 스킬 가격을 창에서 제대로 보이게 세팅.

        int flight000Bullet = int.Parse(ValueDeliverScript.gameData["flight000Bullet"].ToString());
        int flight001Bullet = int.Parse(ValueDeliverScript.gameData["flight001Bullet"].ToString());
        int flight002Bullet = int.Parse(ValueDeliverScript.gameData["flight002Bullet"].ToString());

        int flight000Skill = int.Parse(ValueDeliverScript.gameData["flight000Skill"].ToString());
        int flight001Skill = int.Parse(ValueDeliverScript.gameData["flight001Skill"].ToString());
        int flight002Skill = int.Parse(ValueDeliverScript.gameData["flight002Skill"].ToString());

        GameObject.Find("FlightTag00/_Tag/BulletUpCost").GetComponent<UILabel>().text = ValueDeliverScript.flight000BulletUpCoin[flight000Bullet + 1].ToString();
        GameObject.Find("FlightTag01/_Tag/BulletUpCost").GetComponent<UILabel>().text = ValueDeliverScript.flight001BulletUpCoin[flight001Bullet + 1].ToString();
        GameObject.Find("FlightTag02/_Tag/BulletUpCost").GetComponent<UILabel>().text = ValueDeliverScript.flight002BulletUpCoin[flight002Bullet + 1].ToString();

        GameObject.Find("FlightTag00/_Tag/SkillUpCost").GetComponent<UILabel>().text = ValueDeliverScript.flight000SkillUpCoin[flight000Skill + 1].ToString();
        GameObject.Find("FlightTag01/_Tag/SkillUpCost").GetComponent<UILabel>().text = ValueDeliverScript.flight001SkillUpCoin[flight001Skill + 1].ToString();
        GameObject.Find("FlightTag02/_Tag/SkillUpCost").GetComponent<UILabel>().text = ValueDeliverScript.flight002SkillUpCoin[flight002Skill + 1].ToString();
        // 총알 가격과 스킬 가격을 창에서 제대로 보이게 세팅.
        #endregion

        #region 이큅 아이템 이름과 그에 맞는 스프라이트의 이름을 묶어준다.

        ValueDeliverScript.equipSpriteName.Set("Bomb01", "icon_equip_bomb_big_2");//플라즈마웨이브.
        ValueDeliverScript.equipSpriteName.Set("Bomb02", "");
        ValueDeliverScript.equipSpriteName.Set("Bomb03", "");
        ValueDeliverScript.equipSpriteName.Set("Bomb04", "");
        ValueDeliverScript.equipSpriteName.Set("Bomb05", "icon_equip_bomb_big_6");//블랙홀.
        ValueDeliverScript.equipSpriteName.Set("Bomb06", "");
        ValueDeliverScript.equipSpriteName.Set("Bomb07", "");
        ValueDeliverScript.equipSpriteName.Set("Bomb08", "");
        ValueDeliverScript.equipSpriteName.Set("Bomb09", "");
        ValueDeliverScript.equipSpriteName.Set("Bomb10", "");
        ValueDeliverScript.equipSpriteName.Set("Bomb11", "");
        ValueDeliverScript.equipSpriteName.Set("Bomb12", "");

        ValueDeliverScript.equipSpriteName.Set("Reinforce01", "icon_equip_force_big_1");//싱글증폭기.
        ValueDeliverScript.equipSpriteName.Set("Reinforce02", "icon_equip_force_big_2");//듀얼증폭기.
        ValueDeliverScript.equipSpriteName.Set("Reinforce03", "icon_equip_force_big_3");//스핀볼탐지증폭기.
        ValueDeliverScript.equipSpriteName.Set("Reinforce04", "icon_equip_force_big_4");//다트탐지증폭기.
        ValueDeliverScript.equipSpriteName.Set("Reinforce05", "icon_equip_force_big_5");//더스트탐지증폭기.
        ValueDeliverScript.equipSpriteName.Set("Reinforce06", "icon_equip_force_big_6");//실드탐지증폭기.
        ValueDeliverScript.equipSpriteName.Set("Reinforce07", "icon_equip_force_big_7");//크리티컬엑셀레이터.
        ValueDeliverScript.equipSpriteName.Set("Reinforce08", "icon_equip_boost_big_1");//파이널파워업.
        ValueDeliverScript.equipSpriteName.Set("Reinforce09", "");
        ValueDeliverScript.equipSpriteName.Set("Reinforce10", "");
        ValueDeliverScript.equipSpriteName.Set("Reinforce11", "");
        ValueDeliverScript.equipSpriteName.Set("Reinforce12", "");

        ValueDeliverScript.equipSpriteName.Set("Assist01", "icon_equip_sub_big_1");//보호막.(쉴드)
        ValueDeliverScript.equipSpriteName.Set("Assist02", "icon_equip_sub_big_2");//자석.
        ValueDeliverScript.equipSpriteName.Set("Assist03", "icon_equip_sub_big_3");//빠른핵폭탄.(숏봄)
        ValueDeliverScript.equipSpriteName.Set("Assist04", "icon_equip_sub_big_4");//스킬드레인.(에너지드레인)
        ValueDeliverScript.equipSpriteName.Set("Assist05", "icon_equip_boost_big_7");//더블윙박스.
        ValueDeliverScript.equipSpriteName.Set("Assist06", "icon_equip_boost_big_6");//스트롱웜홀.
        ValueDeliverScript.equipSpriteName.Set("Assist07", "");
        ValueDeliverScript.equipSpriteName.Set("Assist08", "");
        ValueDeliverScript.equipSpriteName.Set("Assist09", "");
        ValueDeliverScript.equipSpriteName.Set("Assist10", "");
        ValueDeliverScript.equipSpriteName.Set("Assist11", "");
        ValueDeliverScript.equipSpriteName.Set("Assist12", "");

        #endregion

        #region 이큅 아이템 이름과 그에 맞는 아이템의 이름을 묶어준다.

        ValueDeliverScript.equipItemName.Set("Bomb01", "플라즈마웨이브");//플라즈마웨이브.
        ValueDeliverScript.equipItemName.Set("Bomb02", "");
        ValueDeliverScript.equipItemName.Set("Bomb03", "");
        ValueDeliverScript.equipItemName.Set("Bomb04", "");
        ValueDeliverScript.equipItemName.Set("Bomb05", "블랙홀");//블랙홀.
        ValueDeliverScript.equipItemName.Set("Bomb06", "");
        ValueDeliverScript.equipItemName.Set("Bomb07", "");
        ValueDeliverScript.equipItemName.Set("Bomb08", "");
        ValueDeliverScript.equipItemName.Set("Bomb09", "");
        ValueDeliverScript.equipItemName.Set("Bomb10", "");
        ValueDeliverScript.equipItemName.Set("Bomb11", "");
        ValueDeliverScript.equipItemName.Set("Bomb12", "");

        ValueDeliverScript.equipItemName.Set("Reinforce01", "싱글증폭기");//싱글증폭기.
        ValueDeliverScript.equipItemName.Set("Reinforce02", "듀얼증폭기");//듀얼증폭기.
        ValueDeliverScript.equipItemName.Set("Reinforce03", "스핀볼탐지증폭기");//스핀볼탐지증폭기.
        ValueDeliverScript.equipItemName.Set("Reinforce04", "다트탐지증폭기");//다트탐지증폭기.
        ValueDeliverScript.equipItemName.Set("Reinforce05", "더스트탐지증폭기");//더스트탐지증폭기.
        ValueDeliverScript.equipItemName.Set("Reinforce06", "실드탐지증폭기");//실드탐지증폭기.
        ValueDeliverScript.equipItemName.Set("Reinforce07", "크리티컬엑셀레이터");//크리티컬엑셀레이터.
        ValueDeliverScript.equipItemName.Set("Reinforce08", "파이널파워업");//파이널파워업.
        ValueDeliverScript.equipItemName.Set("Reinforce09", "");
        ValueDeliverScript.equipItemName.Set("Reinforce10", "");
        ValueDeliverScript.equipItemName.Set("Reinforce11", "");
        ValueDeliverScript.equipItemName.Set("Reinforce12", "");

        ValueDeliverScript.equipItemName.Set("Assist01", "쉴드");//보호막.(쉴드)
        ValueDeliverScript.equipItemName.Set("Assist02", "자석");//자석.
        ValueDeliverScript.equipItemName.Set("Assist03", "빠른핵폭탄");//빠른핵폭탄.(숏봄)
        ValueDeliverScript.equipItemName.Set("Assist04", "스킬드레인");//스킬드레인.(에너지드레인)
        ValueDeliverScript.equipItemName.Set("Assist05", "더블윙박스");//더블윙박스.
        ValueDeliverScript.equipItemName.Set("Assist06", "스트롱웜홀");//스트롱웜홀.
        ValueDeliverScript.equipItemName.Set("Assist07", "");
        ValueDeliverScript.equipItemName.Set("Assist08", "");
        ValueDeliverScript.equipItemName.Set("Assist09", "");
        ValueDeliverScript.equipItemName.Set("Assist10", "");
        ValueDeliverScript.equipItemName.Set("Assist11", "");
        ValueDeliverScript.equipItemName.Set("Assist12", "");

        #endregion

        #region 이큅 아이템 이름과 그에 맞는 아이템의 가격을 묶어준다.

        ValueDeliverScript.equipItemPrice.Set("Bomb01", "500");//플라즈마웨이브.
        ValueDeliverScript.equipItemPrice.Set("Bomb02", "");
        ValueDeliverScript.equipItemPrice.Set("Bomb03", "");
        ValueDeliverScript.equipItemPrice.Set("Bomb04", "");
        ValueDeliverScript.equipItemPrice.Set("Bomb05", "1500");//블랙홀.
        ValueDeliverScript.equipItemPrice.Set("Bomb06", "");
        ValueDeliverScript.equipItemPrice.Set("Bomb07", "");
        ValueDeliverScript.equipItemPrice.Set("Bomb08", "");
        ValueDeliverScript.equipItemPrice.Set("Bomb09", "");
        ValueDeliverScript.equipItemPrice.Set("Bomb10", "");
        ValueDeliverScript.equipItemPrice.Set("Bomb11", "");
        ValueDeliverScript.equipItemPrice.Set("Bomb12", "");

        ValueDeliverScript.equipItemPrice.Set("Reinforce01", "1200");//싱글증폭기.
        ValueDeliverScript.equipItemPrice.Set("Reinforce02", "1500");//듀얼증폭기.
        ValueDeliverScript.equipItemPrice.Set("Reinforce03", "1900");//스핀볼탐지증폭기.
        ValueDeliverScript.equipItemPrice.Set("Reinforce04", "1900");//다트탐지증폭기.
        ValueDeliverScript.equipItemPrice.Set("Reinforce05", "1900");//더스트탐지증폭기.
        ValueDeliverScript.equipItemPrice.Set("Reinforce06", "1900");//실드탐지증폭기.
        ValueDeliverScript.equipItemPrice.Set("Reinforce07", "2500");//크리티컬엑셀레이터.
        ValueDeliverScript.equipItemPrice.Set("Reinforce08", "1200");//파이널파워업.
        ValueDeliverScript.equipItemPrice.Set("Reinforce09", "");
        ValueDeliverScript.equipItemPrice.Set("Reinforce10", "");
        ValueDeliverScript.equipItemPrice.Set("Reinforce11", "");
        ValueDeliverScript.equipItemPrice.Set("Reinforce12", "");

        ValueDeliverScript.equipItemPrice.Set("Assist01", "1500");//보호막.(쉴드)
        ValueDeliverScript.equipItemPrice.Set("Assist02", "900");//자석.
        ValueDeliverScript.equipItemPrice.Set("Assist03", "2500");//빠른핵폭탄.(숏봄)
        ValueDeliverScript.equipItemPrice.Set("Assist04", "2500");//스킬드레인.(에너지드레인)
        ValueDeliverScript.equipItemPrice.Set("Assist05", "3000");//더블윙박스.
        ValueDeliverScript.equipItemPrice.Set("Assist06", "1500");//스트롱웜홀.
        ValueDeliverScript.equipItemPrice.Set("Assist07", "");
        ValueDeliverScript.equipItemPrice.Set("Assist08", "");
        ValueDeliverScript.equipItemPrice.Set("Assist09", "");
        ValueDeliverScript.equipItemPrice.Set("Assist10", "");
        ValueDeliverScript.equipItemPrice.Set("Assist11", "");
        ValueDeliverScript.equipItemPrice.Set("Assist12", "");

        #endregion

        if (PlayerPrefs.HasKey("isTutComplete") == false)
        {
            PlayerPrefs.SetInt("isTutComplete", 0);
        }
        ValueDeliverScript.isTutComplete = PlayerPrefs.GetInt("isTutComplete");


    }//Awake 끝.

    //Start 시작.
    void Start()
    {


        #region 비행기의 락 해제 가격을 제대로 보이게 세팅.//
        int userLevel = int.Parse(ValueDeliverScript.gameData["userLevel"].ToString());

        if (userLevel >= 10) //코만치 락 해제되어 코인으로 살수 있는 조건.
        {
            GameObject.Find("FlightLock/FlightLockMove/Dummy").transform.FindChild("FlightLockSet01/PriceLabel").GetComponent<UILabel>().text = ValueDeliverScript.gameData["FlightLockOff001Coin"].ToString();
            GameObject.Find("FlightLock/FlightLockMove/Dummy").transform.FindChild("FlightLockSet01/CoinIcon").GetComponent<UISprite>().spriteName = "icon_small_gold";
            GameObject.Find("FlightLock/FlightLockMove/Dummy").transform.FindChild("FlightLockSet01/CoinIcon").GetComponent<UISprite>().MakePixelPerfect();
        }
        else if (userLevel < 10) //코만치 락 해제되어 코인으로 살수 있는 조건.
        {
            GameObject.Find("FlightLock/FlightLockMove/Dummy").transform.FindChild("FlightLockSet01/PriceLabel").GetComponent<UILabel>().text = ValueDeliverScript.gameData["FlightLockOff001Medal"].ToString();
            GameObject.Find("FlightLock/FlightLockMove/Dummy").transform.FindChild("FlightLockSet01/CoinIcon").GetComponent<UISprite>().spriteName = "icon_deco";
            GameObject.Find("FlightLock/FlightLockMove/Dummy").transform.FindChild("FlightLockSet01/CoinIcon").GetComponent<UISprite>().MakePixelPerfect();
        }

        if (userLevel >= 20) //팬텀 락 해제되어 코인으로 살수 있는 조건.
        {
            GameObject.Find("FlightLock/FlightLockMove/Dummy").transform.FindChild("FlightLockSet02/PriceLabel").GetComponent<UILabel>().text = ValueDeliverScript.gameData["FlightLockOff002Coin"].ToString();
            GameObject.Find("FlightLock/FlightLockMove/Dummy").transform.FindChild("FlightLockSet02/CoinIcon").GetComponent<UISprite>().spriteName = "icon_small_gold";
            GameObject.Find("FlightLock/FlightLockMove/Dummy").transform.FindChild("FlightLockSet02/CoinIcon").GetComponent<UISprite>().MakePixelPerfect();
        }
        else if (userLevel < 20)
        {
            GameObject.Find("FlightLock/FlightLockMove/Dummy").transform.FindChild("FlightLockSet02/PriceLabel").GetComponent<UILabel>().text = ValueDeliverScript.gameData["FlightLockOff002Medal"].ToString();
            GameObject.Find("FlightLock/FlightLockMove/Dummy").transform.FindChild("FlightLockSet02/CoinIcon").GetComponent<UISprite>().spriteName = "icon_deco";
            GameObject.Find("FlightLock/FlightLockMove/Dummy").transform.FindChild("FlightLockSet02/CoinIcon").GetComponent<UISprite>().MakePixelPerfect();
        }

        #endregion



        #region //행거시작시 튜토리얼을 시작할지 본 게임을 시작할지 결정하는 부분.
        if (ValueDeliverScript.isTutComplete == 2)
        {
            SpecialAttack1();   // 스페셜 어택 설정과 실행중인지 확인하고 안되어있으면 되도록 만드는 함수.
            SkinWindowClose();  //스킨 관련된 정보를 처음에 제대로 처리를 해서 창에 정보를 심어 제대로 보이게 만드는 함수.
        }

        if (ValueDeliverScript.isTutComplete == 0)
        {
            tutManagerScript.ActivateHanger();
            tutManagerScript.centerBlack.GetComponent<UITexture>().material.SetColor("_TintColor", new Color(0, 0, 0, 1));
            tutManagerScript.centerBlack.SetActive(true);
        }
        else if (ValueDeliverScript.isTutComplete == 1)
        {
            tutManagerScript.ActivateResult();
        }
        #endregion

        ValueDeliverScript.flightWindowPosition = ValueDeliverScript.flightNumber;
        flights.transform.FindChild("MoveTF/FlightsMove").localPosition = new Vector3(ValueDeliverScript.flightNumber * -1000, 0, 0);

        LoadEquip();
        #region   게임 시작하고 처음 보이는 스페셜 어택 정보를 강제로 로딩해서 첫화면에 제대로 보여지게 하기 위해 삽입하는 코드
        Transform specialMessage = prepareReady.transform.FindChild("OperMessage/SpecialMessage");
        specialMessage.FindChild("AttackedUfoText");
        specialMessage.FindChild("AttackWishUfoText");
        specialMessage.FindChild("SpecialAttackIcon");
        specialMessage.FindChild("UfoNameText");
        #endregion //게임 시작하고 처음 보이는 스페셜 어택 정보를 강제로 로딩해서 첫화면에 제대로 보여지게 하기 위해 삽입하는 코드//
        EquipStartSetting();
        if (gameEndResult)
        {
            StartCoroutine(FirstResultRoad());  //결과창이 보여지도록 해주는 함수를 호출한다.
        }
        else
        {
            if (pilotLevelUpWindow.activeSelf == true)
            {
                flights.transform.localPosition = new Vector3(-1200, 0, 0);
                prepareReady.transform.FindChild("OperMessage").localPosition = new Vector3(-1200, 0, 0);
                prepareReady.transform.FindChild("PrepareBtn").localPosition = new Vector3(-1200, 0, 0);
                prepareReady.transform.FindChild("RankFriendTF").localPosition = new Vector3(-1200, 0, 0);
            }
            else
            {
                StartCoroutine(FirstLoad());
            }
        }
        gameObject.GetComponent<WhiteFadeScript>().Activate(); // 격납고 시작시 블랙에서 화이트로 페이드인 해줌.
        if (!gameEndResult)
        {
            SkinWindowClose();
        }


    }

    #region 이큅 윈도우들 안에 세팅되어있는 아이템들을 찾아서 목록화시키고 그것들을 유사 스프라이트 이름들을 저장하여 다른곳에서도 쓸 수 있게 만들기 위한부분//
    //행거컨트롤 start에서 불러 들여 행거가 시작될때마다 아이템의 세팅이 제대로 되어있는지 검사하고 정리를 해준다.

    public void LoadEquip()
    {

        int findMountitem = 0; //마운드 아이템은 배열에 저장되지 않게 하기 위해 만들어 놓은 불린 변수.
        int findHighlightItem = 0;
        //이큅내의 각각의 탭에서 아이템의 갯수를 헤아려 배열의 길이를 정한다. 이렇게 하면 앞으로 아이템을 각각 따로 검색하지 않고 배열에서 불러내기만 하면 된다.
        //2를 빼는 것은 아이템박스가 아닌 오브젝트는 배열수에서 제외하기 위함이다.
        GameObject[] equipBombItem = new GameObject[equipBombTab.transform.FindChild("Item").childCount - 2];   //-2를 하는 것은 차일드중에 마우스아이템과 하일라이트 아이템이 있기때문. 이것은 이큅 아이템이 아니다.
        GameObject[] equipReinforceItem = new GameObject[equipReinforceTab.transform.FindChild("Item").childCount - 2];
        GameObject[] equipAssistanceItem = new GameObject[equipAssistanceTab.transform.FindChild("Item").childCount - 2];
        GameObject[] equipOperItem = new GameObject[equipOperTab.transform.FindChild("Item").childCount - 2];

        //Debug.Log("::: Equip collection Lenth :::");
        //Debug.Log("equipBombItem"+equipBombItem.Length);
        //Debug.Log("equipReinforceItem"+equipReinforceItem.Length);
        //Debug.Log("equipAssistanceItem"+equipAssistanceItem.Length);
        //Debug.Log("equipOperItem" + equipOperItem.Length);

        #region 이큅 아이템들을 배열에 넣어서 보관해놓는다. 이렇게 하면 언제든 불러 쓸수 있다.
        for (int i = 0; i < equipBombTab.transform.FindChild("Item").childCount; i++)
        {
            GameObject tempItem = equipBombTab.transform.FindChild("Item").GetChild(i).gameObject;
            //Debug.Log("tempItem ::: " + tempItem.name);

            if (tempItem.name == "MountItem")
            { findMountitem = 1; continue; }

            if (tempItem.name == "HilightItem")
            { findHighlightItem = 1; continue; }

            equipBombItem[i - findMountitem - findHighlightItem] = tempItem;
            //Debug.Log("equipBombItem[" + (i - findMountitem - findHighlightItem) + "] ::: " + equipBombItem[i - findMountitem - findHighlightItem].name);
        }

        findMountitem = 0;
        findHighlightItem = 0;
        for (int i = 0; i < equipReinforceTab.transform.FindChild("Item").childCount; i++)
        {
            GameObject tempItem = equipReinforceTab.transform.FindChild("Item").GetChild(i).gameObject;

            if (tempItem.name == "MountItem")
            { findMountitem = 1; continue; }

            if (tempItem.name == "HilightItem")
            { findHighlightItem = 1; continue; }

            equipReinforceItem[i - findMountitem - findHighlightItem] = tempItem;
        }

        findMountitem = 0;
        findHighlightItem = 0;
        for (int i = 0; i < equipAssistanceTab.transform.FindChild("Item").childCount; i++)
        {
            GameObject tempItem = equipAssistanceTab.transform.FindChild("Item").GetChild(i).gameObject;

            if (tempItem.name == "MountItem")
            { findMountitem = 1; continue; }

            if (tempItem.name == "HilightItem")
            { findHighlightItem = 1; continue; }

            equipAssistanceItem[i - findMountitem - findHighlightItem] = tempItem;
        }

        findMountitem = 0;
        findHighlightItem = 0;
        for (int i = 0; i < equipOperTab.transform.FindChild("Item").childCount; i++)
        {
            //Debug.Log("::: equipOperTab ChildCount is " + equipOperTab.transform.FindChild("Item").childCount + " :::");
            GameObject tempItem = equipOperTab.transform.FindChild("Item").GetChild(i).gameObject;

            if (tempItem.name == "MountItem")
            { findMountitem = 1; continue; }

            if (tempItem.name == "HilightItem")
            { findHighlightItem = 1; continue; }

            equipOperItem[i - findMountitem - findHighlightItem] = tempItem;
        }
        //여기까지해서 아이템박스 오브젝트들을 배열화하여 임시저장.
        #endregion





        //각각의 이큅 아이템들의 이름을 받아올 준비를 해놓는다. 첫번째 0번은 단순 점 이미지가 들어가야 되기에 배열의 크기를 하나더 크게한다.
        bombSpriteName = new string[equipBombItem.Length + 1];
        reinforceSpriteName = new string[equipReinforceItem.Length + 1];
        assistSpriteName = new string[equipAssistanceItem.Length + 1];
        operSpriteName = new string[equipOperItem.Length + 1];

        //각각의 아이템이름이 들어가는 배열에 첫번째는 비어있다는 뜻으로 쓰일 이미지의 이름을 넣어놓는다.
        bombSpriteName[0] = "base_result_black";
        reinforceSpriteName[0] = "base_result_black";
        assistSpriteName[0] = "base_result_black";
        operSpriteName[0] = "base_result_black";

        //이큅의 각각 탭에서 각각의 아이템들이 이름을 검색해서 스트링 배열에 넣어서 저장해놓는다.
        for (int i = 0; i < equipBombItem.Length; i++)
        {
            //Debug.Log("equipBombItem ::: " + i + " ::: name ::: " + equipBombItem[i].name);
            int itemNumber;
            if (equipBombItem[i].GetComponent<ItemKeyValueScript>())
            {
                itemNumber = equipBombItem[i].GetComponent<ItemKeyValueScript>().itemNumber;
                if (itemNumber > 0)
                {
                    equipBombItem[i].transform.FindChild("Label").GetComponent<UILabel>().text = (ValueDeliverScript.gameData["EquipBomb" + itemNumber.ToString("D2")]).ToString();   //구매되어 있는 아이템의 갯수를 입력한다.
                    bombSpriteName[itemNumber] = equipBombItem[i].transform.FindChild("Item").GetComponent<UISprite>().spriteName;
                    ValueDeliverScript.bombSpriteName = bombSpriteName;
                }
            }
        }

        for (int i = 0; i < equipReinforceItem.Length; i++)
        {
            int itemNumber;
            if (equipReinforceItem[i].GetComponent<ItemKeyValueScript>())
            {
                itemNumber = equipReinforceItem[i].GetComponent<ItemKeyValueScript>().itemNumber;
                if (itemNumber > 0)
                {
                    equipReinforceItem[i].transform.FindChild("Label").GetComponent<UILabel>().text = ValueDeliverScript.gameData["EquipReinforce" + itemNumber.ToString("00")].ToString();   //구매되어 있는 아이템의 갯수를 입력한다.
                    reinforceSpriteName[itemNumber] = equipReinforceItem[i].transform.FindChild("Item").GetComponent<UISprite>().spriteName;
                    ValueDeliverScript.reinforceSpriteName = reinforceSpriteName;
                }
            }
        }

        for (int i = 0; i < equipAssistanceItem.Length; i++)
        {
            int itemNumber;
            if (equipAssistanceItem[i].GetComponent<ItemKeyValueScript>())
            {
                itemNumber = equipAssistanceItem[i].GetComponent<ItemKeyValueScript>().itemNumber;
                if (itemNumber > 0)
                {
                    equipAssistanceItem[i].transform.FindChild("Label").GetComponent<UILabel>().text = ValueDeliverScript.gameData["EquipAssist" + itemNumber.ToString("00")].ToString();   //구매되어 있는 아이템의 갯수를 입력한다.
                    assistSpriteName[itemNumber] = equipAssistanceItem[i].transform.FindChild("Item").GetComponent<UISprite>().spriteName;
                    ValueDeliverScript.assistSpriteName = assistSpriteName;
                }
            }
        }

        for (int i = 0; i < equipOperItem.Length; i++)
        {
            int itemNumber;
            if (equipOperItem[i].GetComponent<ItemKeyValueScript>())
            {
                itemNumber = equipOperItem[i].GetComponent<ItemKeyValueScript>().itemNumber;
                if (itemNumber > 0)
                {
                    equipOperItem[i].transform.FindChild("Label").GetComponent<UILabel>().text = ValueDeliverScript.gameData["EquipOper" + itemNumber.ToString("00")].ToString();  //구매되어 있는 아이템의 갯수를 입력한다.
                    operSpriteName[itemNumber] = equipOperItem[i].transform.FindChild("Item").GetComponent<UISprite>().spriteName;
                    ValueDeliverScript.operSpriteName = operSpriteName;
                }
            }
        }
        //이큅의 각각 탭에서 각각의 아이템들이 이름을 검색해서 스트링 배열에 넣어서 저장해놓는다.
    }
    //LoadEquip()의 마지막


    #endregion 로드 이큅을 함수내용을 끝낸다.

    public TutManagerScript tutManagerScript;

    bool isRLowTabAnim = false;

    IEnumerator ResultPanelShowAll()
    {

        ResultPanel.transform.FindChild("ResultPanelRight").animation.Play("ResultPanelRightAnim01");
        ResultPanel.transform.FindChild("ResultPanelLeft").animation.Play("ResultPanelLeftAnim02");

        yield return new WaitForSeconds(0.5f);
        ResultPanel.transform.FindChild("ResultLowTab").animation.Play("ResultLowTabAnim01");
        yield return new WaitForSeconds(ResultPanel.transform.FindChild("ResultLowTab").animation["ResultLowTabAnim01"].clip.length);
        isRLowTabAnim = true;
    }

    IEnumerator FirstResultRoad()
    {
        bgTop.animation.Play("BGMainTopAnim01");
        bgBottom.animation.Play("BGMainBottomAnim01");
        yield return new WaitForSeconds(1f);

        flights.transform.localPosition = new Vector3(-1200, 0, 0);
        ResultPanel.transform.FindChild("ResultPanelLeft").localPosition = new Vector3(-850, 0, 6);
        ResultPanel.transform.FindChild("ResultPanelLeft").animation.Play("ResultPanelLeftAnim01");
        yield return new WaitForSeconds(0.5f);

        if (pilotLevelUpWindow.activeSelf == false)
            StartCoroutine(ResultPanelShowAll());

        else
            noTouchPanel.SetActive(false);
    }

    IEnumerator FirstLoad() //처음 실행했을때 비행기의 위치를 이전 마지막 선택된 비행기 위치로 바꾸어줌.
    {

        bgTop.animation.Play("BGMainTopAnim01");

        bgBottom.animation.Play("BGMainBottomAnim01");
        yield return new WaitForSeconds(1f);

        flights.animation.Play("FlightsPanelAnim01");
        prepareReady.animation.Play("PrepareReadyAnim01");
        flights.transform.FindChild("MoveTF/FlightsMove").localPosition = new Vector3(ValueDeliverScript.flightNumber * -1000, 0, 0);
        GameObject.Find("FlightLock/FlightLockMove").transform.localPosition = flights.transform.FindChild("MoveTF/FlightsMove").localPosition;

        //선택된 비행기가 락이 걸려있는지 여부를 알아보고 락이 걸려있으면 락 걸려있음을 표시.

        if (ValueDeliverScript.flightNumber != 0)
        {
            if (int.Parse((ValueDeliverScript.gameData["FlightLockOff" + ValueDeliverScript.flightWindowPosition.ToString("000")]).ToString()) == 2)
            {
                GameObject.Find("MoveTF").GetComponent<UIPanel>().alpha = 1f;
                GameObject.Find("FlightLock/FlightLockMove/Dummy").transform.FindChild("FlightLockSet" + ValueDeliverScript.flightNumber.ToString("00")).gameObject.SetActive(false);
            }
            else if (int.Parse((ValueDeliverScript.gameData["FlightLockOff" + ValueDeliverScript.flightWindowPosition.ToString("000")]).ToString()) == 2)
            {
                GameObject.Find("MoveTF").GetComponent<UIPanel>().alpha = 0.5f;
                GameObject.Find("FlightLock/FlightLockMove/Dummy").transform.FindChild("FlightLockSet" + ValueDeliverScript.flightNumber.ToString("00")).gameObject.SetActive(true);
            }
        }
    }

    void SpecialAttack1()
    {
        if (ValueDeliverScript.isTutComplete != 2) return;        // 아직 튜토리얼이 끝나지 않았으면 스페셜 어택 관련된 것을 실행하지 않는다.

        //미션이 완성된 기록이 있는가 먼저 검사한다.201년 3월 12일 코딩중 중단. 3월 13일 아침에 와서 해결할것. 어떤 변수가 미션 완료를 기록하는 것인지 먼저 찾아야 됨.
        //유니티 최신 버전으로 업데이트 할것. 현 프로젝트는 백업.

        int isSpecialAttackOn = int.Parse(ValueDeliverScript.gameData["isSpecialAttackOn"].ToString());
        int isSpecialMissionSelect = int.Parse(ValueDeliverScript.gameData["isSpecialMissionSelect"].ToString());

        if (isSpecialAttackOn == 0 && isSpecialMissionSelect == 0)    //스페셜 어택 미션 컴플릿도 안되어있고 스페셜 어택 미션이 발동이 안되어있으면~
        {
            int rndVal = UnityEngine.Random.Range(0, 400);              //스페셜 어택 미션 랜덤 선택.
            if (rndVal < 100)
                ValueDeliverScript.gameData["specialAttackType"] = 0;       //specialSpinball
            else if (rndVal < 200)
                ValueDeliverScript.gameData["specialAttackType"] = 1;       //specialDart
            else if (rndVal < 300)
                ValueDeliverScript.gameData["specialAttackType"] = 2;       //specialDust
            else
                ValueDeliverScript.gameData["specialAttackType"] = 3;       //specialShield
            ValueDeliverScript.gameData["isSpecialMissionSelect"] = 1;      //스페셜 어택이 발동되었음을 기록함.
        }

        if (int.Parse(ValueDeliverScript.gameData["isSpecialAttackOn"].ToString()) == 0)             // 스페셜 어택 미션을 아직 달성하지 못했으면~ 여기는 
        {
            SpecialAttackNotComplete();                               //스페셜 어택2 함수를 실행함.
        }

        else if (int.Parse(ValueDeliverScript.gameData["isSpecialAttackOn"].ToString()) == 1)             // 이미 스페셜 어택 미션을 컴플릿 했으면... 지금 막 게임에서 돌아와서 검사할때는 기본이 무조건 낫 컴플릿이기 때문에 이곳으로 오질 못함.
        {
            GameObject.Find("SpecialAttackInfo").transform.localScale = new Vector3(1, 0, 1);   //스페셜 어택 기본 정보를 스케일을 줄여서 안보이게 처리
            GameObject.Find("SpecialInfo/SpecialAttackOn").transform.localScale = new Vector3(1, 1, 1);   //스페셜 어택 발동 문자 스케일 키워서 표시.

            GameObject.Find("SpecialAttackOnText").transform.localScale = new Vector3(52, 46, 1);   //스페셜 어택 발동 문자 스케일 키워서 표시.
            GameObject.Find("GameSpecialStart").transform.localPosition = new Vector3(389, -281, 0);
            GameObject.Find("ResultLowTab/AttackBtn/GameStart").GetComponent<UISprite>().enabled = false;

            GameObject.Find("PrepareBtn/GameStart").GetComponent<UISprite>().spriteName = "Btn_SpecialGameReady_00";
            GameObject.Find("PrepareBtn/GameStart").GetComponent<UIImageButton>().normalSprite = "Btn_SpecialGameReady_00";
            GameObject.Find("PrepareBtn/GameStart").GetComponent<UIImageButton>().hoverSprite = "Btn_SpecialGameReady_00";
            GameObject.Find("PrepareBtn/GameStart").GetComponent<UIImageButton>().pressedSprite = "Btn_SpecialGameReady_01";

            GameObject.Find("AttackReady/AttackBtn/GameStart").GetComponent<UISprite>().spriteName = "Btn_SpecialGame_00";
            GameObject.Find("AttackReady/AttackBtn/GameStart").GetComponent<UIImageButton>().normalSprite = "Btn_SpecialGame_00";
            GameObject.Find("AttackReady/AttackBtn/GameStart").GetComponent<UIImageButton>().hoverSprite = "Btn_SpecialGame_00";
            GameObject.Find("AttackReady/AttackBtn/GameStart").GetComponent<UIImageButton>().pressedSprite = "Btn_SpecialGame_01";


            int tempIconNum = 0;
            switch (int.Parse(ValueDeliverScript.gameData["specialAttackType"].ToString()))
            {
                case 0:
                    tempIconNum = 1;
                    break;
                case 1:
                    tempIconNum = 3;
                    break;
                case 2:
                    tempIconNum = 2;
                    break;
                case 3:
                    tempIconNum = 4;
                    break;
            }
            for (int i = 0; i < specialAttackIcon.Length; i++)                   //이부분에서 아이콘을 표시하여준다. 에어로게이트 아틀라스 사용.
            {
                specialAttackIcon[i].GetComponent<UISprite>().spriteName = "item_icon" + tempIconNum;
                specialAttackIcon[i].GetComponent<UISprite>().MakePixelPerfect();
                ValueDeliverScript.gameData["specialAttackItemName"] = "item_icon" + tempIconNum;
            }

            StartCoroutine(SpecialAttackTime());        //스페셜 어택 미션을 달성했으면 바로 시간을 재는 함수를 실행함.
        }
        ValueDeliverScript.gameData["flightNumber"] = ValueDeliverScript.flightNumber;
        //Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
        ValueDeliverScript.SaveGameData();
        //Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
    }

    void SpecialAttackNotComplete()
    {
        int spinballCount = int.Parse(ValueDeliverScript.gameData["spinballCount"].ToString());
        int isSpecialAttackOn = int.Parse(ValueDeliverScript.gameData["isSpecialAttackOn"].ToString());

        int dartCount = int.Parse(ValueDeliverScript.gameData["dartCount"].ToString());
        int dustCount = int.Parse(ValueDeliverScript.gameData["dustCount"].ToString());
        int shieldCount = int.Parse(ValueDeliverScript.gameData["shieldCount"].ToString());

        switch (int.Parse(ValueDeliverScript.gameData["specialAttackType"].ToString()))
        {
            case 0:
                if (spinballCount >= specialSpinball)             //현재 잡은 스핀볼이 제시기준보다 더 많으면~
                {
                    ValueDeliverScript.gameData["specialAttackItemMaxNumber"] = specialSpinball;
                    ValueDeliverScript.gameData["spinballCount"] = specialSpinball;              //잡은 스핀볼을 제시기준하고 똑같은 수치로 먼저 변환.
                    ResultSpecialAttackOnAnimation();

                    if (isSpecialAttackOn == 0)
                    {
                        ValueDeliverScript.gameData["isSpecialAttackOn"] = 1;                       //스페셜 어택 미션을 달성했음을 기록.
                        SpecialAttackTimeSet(ValueDeliverScript.specialAttackAddTime);   //스페셜 어택 유지 시간을 정하기 위해 함수를 호출.
                    }
                }

                for (int i = 0; i < specialAttackIcon.Length; i++)                   //이부분에서 아이콘을 표시하여준다.
                {
                    specialAttackIcon[i].GetComponent<UISprite>().spriteName = "item_icon1";
                    specialAttackIcon[i].GetComponent<UISprite>().MakePixelPerfect();
                    ValueDeliverScript.gameData["specialAttackItemName"] = "item_icon1";
                }
                specialAttackText[0].GetComponent<UILabel>().text = "/ " + specialSpinball;
                specialAttackText[1].GetComponent<UILabel>().text = specialAttackName[0];
                specialAttackText[2].GetComponent<UILabel>().text = ValueDeliverScript.gameData["spinballCount"].ToString();
                specialAttackText[3].GetComponent<UILabel>().text = "/ " + specialSpinball;
                specialAttackText[4].GetComponent<UILabel>().text = ValueDeliverScript.gameData["spinballCount"].ToString();

                specialAttackText[5].GetComponent<UILabel>().text = specialAttackName[0];
                specialAttackText[6].GetComponent<UILabel>().text = ValueDeliverScript.gameData["spinballCount"].ToString();
                specialAttackText[7].GetComponent<UILabel>().text = "/ " + specialSpinball;

                break;

            case 1:
                if (dartCount >= specialDart)
                {
                    ValueDeliverScript.gameData["specialAttackItemMaxNumber"] = specialDart;
                    ValueDeliverScript.gameData["dartCount"] = specialDart;
                    ResultSpecialAttackOnAnimation();

                    if (isSpecialAttackOn == 0)
                    {
                        ValueDeliverScript.gameData["isSpecialAttackOn"] = 1;                       //스페셜 어택 미션을 달성했음을 기록.
                        SpecialAttackTimeSet(ValueDeliverScript.specialAttackAddTime);   //스페셜 어택 유지 시간을 정하기 위해 함수를 호출.
                    }
                }

                for (int i = 0; i < specialAttackIcon.Length; i++)
                {
                    specialAttackIcon[i].GetComponent<UISprite>().spriteName = "item_icon3";
                    specialAttackIcon[i].GetComponent<UISprite>().MakePixelPerfect();
                    ValueDeliverScript.gameData["specialAttackItemName"] = "item_icon3";
                }
                specialAttackText[0].GetComponent<UILabel>().text = "/ " + specialDart;
                specialAttackText[1].GetComponent<UILabel>().text = specialAttackName[1];
                specialAttackText[2].GetComponent<UILabel>().text = ValueDeliverScript.gameData["dartCount"].ToString();
                specialAttackText[3].GetComponent<UILabel>().text = "/ " + specialDart;
                specialAttackText[4].GetComponent<UILabel>().text = ValueDeliverScript.gameData["dartCount"].ToString();

                specialAttackText[5].GetComponent<UILabel>().text = specialAttackName[1];
                specialAttackText[6].GetComponent<UILabel>().text = ValueDeliverScript.gameData["dartCount"].ToString();
                specialAttackText[7].GetComponent<UILabel>().text = "/ " + specialDart;

                break;

            case 2:
                if (dustCount >= specialDust)
                {
                    ValueDeliverScript.gameData["specialAttackItemMaxNumber"] = specialDust;
                    ValueDeliverScript.gameData["dustCount"] = specialDust;
                    ResultSpecialAttackOnAnimation();

                    if (isSpecialAttackOn == 0)
                    {
                        ValueDeliverScript.gameData["isSpecialAttackOn"] = 1;                       //스페셜 어택 미션을 달성했음을 기록.
                        SpecialAttackTimeSet(ValueDeliverScript.specialAttackAddTime);   //스페셜 어택 유지 시간을 정하기 위해 함수를 호출.
                    }
                }

                for (int i = 0; i < specialAttackIcon.Length; i++)
                {
                    specialAttackIcon[i].GetComponent<UISprite>().spriteName = "item_icon2";
                    specialAttackIcon[i].GetComponent<UISprite>().MakePixelPerfect();
                    ValueDeliverScript.gameData["specialAttackItemName"] = "item_icon2";
                }
                specialAttackText[0].GetComponent<UILabel>().text = "/ " + specialDust;
                specialAttackText[1].GetComponent<UILabel>().text = specialAttackName[2];
                specialAttackText[2].GetComponent<UILabel>().text = ValueDeliverScript.gameData["dustCount"].ToString();
                specialAttackText[3].GetComponent<UILabel>().text = "/ " + specialDust;
                specialAttackText[4].GetComponent<UILabel>().text = ValueDeliverScript.gameData["dustCount"].ToString();

                specialAttackText[5].GetComponent<UILabel>().text = specialAttackName[2];
                specialAttackText[6].GetComponent<UILabel>().text = ValueDeliverScript.gameData["dustCount"].ToString();
                specialAttackText[7].GetComponent<UILabel>().text = "/ " + specialDust;

                break;

            case 3:
                if (shieldCount >= specialShield)
                {
                    ValueDeliverScript.gameData["specialAttackItemMaxNumber"] = specialShield;
                    ValueDeliverScript.gameData["shieldCount"] = specialShield;
                    ResultSpecialAttackOnAnimation();

                    if (isSpecialAttackOn == 0)
                    {
                        ValueDeliverScript.gameData["isSpecialAttackOn"] = 1;                       //스페셜 어택 미션을 달성했음을 기록.
                        SpecialAttackTimeSet(ValueDeliverScript.specialAttackAddTime);   //스페셜 어택 유지 시간을 정하기 위해 함수를 호출.
                    }
                }

                for (int i = 0; i < specialAttackIcon.Length; i++)
                {
                    specialAttackIcon[i].GetComponent<UISprite>().spriteName = "item_icon4";
                    specialAttackIcon[i].GetComponent<UISprite>().MakePixelPerfect();
                    ValueDeliverScript.gameData["specialAttackItemName"] = "item_icon4";
                }
                specialAttackText[0].GetComponent<UILabel>().text = "/ " + specialShield;
                specialAttackText[1].GetComponent<UILabel>().text = specialAttackName[3];
                specialAttackText[2].GetComponent<UILabel>().text = ValueDeliverScript.gameData["shieldCount"].ToString();
                specialAttackText[3].GetComponent<UILabel>().text = "/ " + specialShield;
                specialAttackText[4].GetComponent<UILabel>().text = ValueDeliverScript.gameData["shieldCount"].ToString();

                specialAttackText[5].GetComponent<UILabel>().text = specialAttackName[3];
                specialAttackText[6].GetComponent<UILabel>().text = ValueDeliverScript.gameData["shieldCount"].ToString();
                specialAttackText[7].GetComponent<UILabel>().text = "/ " + specialShield;

                break;
        }
        ValueDeliverScript.gameData["flightNumber"] = ValueDeliverScript.flightNumber;
        //Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
        ValueDeliverScript.SaveGameData();
        //Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
    }

    void SpecialAttackTimeSet(int specialTime = 30)
    {
        ValueDeliverScript.gameData["specialEndTime"] = System.DateTime.Now.AddMinutes(specialTime).ToBinary().ToString();  //시간을 저장한다. 이값은 밸류딜리버스크립트에 저장된다.

        specialRestTimeLabel01.SetActive(true);
        StartCoroutine(SpecialAttackTime());

        ValueDeliverScript.gameData["flightNumber"] = ValueDeliverScript.flightNumber;
        //Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
        ValueDeliverScript.SaveGameData();
        //Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
    }

    IEnumerator SpecialAttackTime()         //이 코루틴 함수에서 시간을 재서 표시하는 역할을 함.
    {

        for (int i = 0; i < specialAttackIcon.Length; i++)//스페셜 어택 온 된 아이콘(적 유에프오 표시)를 한다.
        {
            specialAttackIcon[i].GetComponent<UISprite>().spriteName = ValueDeliverScript.gameData["specialAttackItemName"].ToString();    //스프라이트에 지정된 아이콘을 표시한다.
            specialAttackIcon[i].GetComponent<UISprite>().MakePixelPerfect();   //찌그러짐을 방지하기 위해 메이크 픽셀 퍼펙트를 실행한다.
        }

        Debug.Log("====Special Attack Time Label Show====");
        specialRestTimeLabel01.SetActive(true);                           //남은 시간을 표시하는 숫자를 보이게 만듬.
        specialEndTime = DateTime.FromBinary(Convert.ToInt64(double.Parse(ValueDeliverScript.gameData["specialEndTime"].ToString())));   //밸류딜리버스크립트에 저장된 시간을 불러온다.
        specialRestTimeText = specialEndTime.Subtract(System.DateTime.Now).Seconds;                //+1을 해주는 것은 남은 시간을 무조건 올림값으로 처리하기 위해서. 기본적으로 버림값을 취함. 현재 시간과 스페셜 출격이 끝날 시간의 차이를 계산하여 그값을 정수로 돌려준다.

        while (specialRestTimeText > -1)                                                                    //아직 스페셜 출격타임이 끝나지 않았으면
        {
            specialRestTimeText = specialEndTime.Subtract(System.DateTime.Now).Minutes;
            specialRestTimeLabel01.GetComponent<UILabel>().text = (1 + (specialRestTimeText)).ToString("D2") + "分!"; //출격 아이콘 위에 스페셜 출격 표시하는 부분에 시간을 적어준다.
            yield return new WaitForSeconds(1f);
        }

        //이부분은 바로 위의 while 루프가 끝나면 실행이 되는 부분이다. 아직 스페셜 미션 완료 보상 시간이 남아있으면 이부분으로 들어오질 못한다.
        //스페셜 출격 시간이 모두 지나면 아래 부분이 실행이 된다.
        ValueDeliverScript.gameData["isSpecialAttackOn"] = 0; //스페셜 어택 미션 완료 여부가 미완으로~
        ValueDeliverScript.gameData["isSpecialMissionSelect"] = 0; //스페셜 어택 미션 종류 지정 여부가 미완으로~

        specialRestTimeLabel01.SetActive(false);      //출격하기 버튼 위에 보이던 스페셜 어택 관련 글씨(숫자) 아이콘을 숨김.

        ValueDeliverScript.gameData["spinballCount"] = ValueDeliverScript.gameData["dustCount"] = ValueDeliverScript.gameData["dartCount"] = ValueDeliverScript.gameData["shieldCount"] = 0;    //지금까지 파괴했던 각각의 ufo 갯수를 초기화.
        SpecialAttack1();   //스페셜 어택 미션 지정을 위해 함수 호출.
        GameObject.Find("SpecialAttackInfo").transform.localScale = new Vector3(1, 1, 1);   //스페셜 어택 기본 정보를 스케일을 줄여서 안보이게 처리
        GameObject.Find("SpecialInfo/SpecialAttackOn").transform.localScale = new Vector3(1, 0, 1);   //스페셜 어택 발동 문자 스케일 키워서 표시.
        GameObject.Find("SpecialAttackOnText").transform.localScale = new Vector3(52, 46, 1);   //스페셜 어택 발동 문자 스케일 키워서 표시.
        GameObject.Find("GameSpecialStart").transform.localPosition = new Vector3(1500, -281, 0);
        GameObject.Find("GameSpecialStart").GetComponent<UISprite>().enabled = false;
        GameObject.Find("ResultLowTab/AttackBtn/GameStart").GetComponent<UISprite>().enabled = true;
        GameObject.Find("ResultLowTab/AttackBtn/GameStart").transform.localPosition = new Vector3(389, -281, 0);

        GameObject.Find("PrepareBtn/GameStart").GetComponent<UISprite>().spriteName = "bt_gameready_n";
        GameObject.Find("PrepareBtn/GameStart").GetComponent<UIImageButton>().normalSprite = "bt_gameready_n";
        GameObject.Find("PrepareBtn/GameStart").GetComponent<UIImageButton>().hoverSprite = "bt_gameready_n";
        GameObject.Find("PrepareBtn/GameStart").GetComponent<UIImageButton>().pressedSprite = "bt_gameready_o";

        GameObject.Find("AttackReady/AttackBtn/GameStart").GetComponent<UISprite>().spriteName = "bt_gamestart_n";
        GameObject.Find("AttackReady/AttackBtn/GameStart").GetComponent<UIImageButton>().normalSprite = "bt_gamestart_n";
        GameObject.Find("AttackReady/AttackBtn/GameStart").GetComponent<UIImageButton>().hoverSprite = "bt_gamestart_n";
        GameObject.Find("AttackReady/AttackBtn/GameStart").GetComponent<UIImageButton>().pressedSprite = "bt_gamestart_o";

        ValueDeliverScript.gameData["flightNumber"] = ValueDeliverScript.flightNumber;
        //Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
        ValueDeliverScript.SaveGameData();
        //Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
    }

    //이큅세팅창에(하단바 좌측에 나오는 아이템 세개 들어가는 창) 구매한 이큅 아이템이 보이도록 만들어준다.
    public void EquipStartSetting()
    {
        int activeBomb = int.Parse(ValueDeliverScript.gameData["activeBomb"].ToString());
        int activeReinforce = int.Parse(ValueDeliverScript.gameData["activeReinforce"].ToString());
        int activeAssist = int.Parse(ValueDeliverScript.gameData["activeAssist"].ToString());

        GameObject equipSetting = GameObject.Find("Equippart").gameObject;

        GameObject bombIcon = equipSetting.transform.FindChild("BombIcon").gameObject;
        EquipIconSetting(bombIcon, activeBomb, "Bomb", bombSpriteName);  //1208번줄 EquipIconSetting()함수 실행.

        GameObject reinforceIcon = equipSetting.transform.FindChild("ReinforceIcon").gameObject;
        EquipIconSetting(reinforceIcon, activeReinforce, "Reinforce", reinforceSpriteName);  //1208번줄 EquipIconSetting()함수 실행.

        GameObject assistIcon = equipSetting.transform.FindChild("AssistanceIcon").gameObject;
        EquipIconSetting(assistIcon, activeAssist, "Assist", assistSpriteName);  //1208번줄 EquipIconSetting()함수 실행.
    }

    public void EquipIconSetting(GameObject Icon, int activeIconNum, string equipName, string[] getSpriteName)
    {

        GameObject equipTabItems = null;   //선택창에서 현재 활성화된 탭을 받아둘 변수를 미리 선언한다.
        if (equipName == "Bomb") equipTabItems = GameObject.Find("EquipWindows").transform.FindChild("EquipBombTab/Item").gameObject;
        else if (equipName == "Reinforce") equipTabItems = GameObject.Find("EquipWindows").transform.FindChild("EquipReinforceTab/Item").gameObject;
        else if (equipName == "Assist") equipTabItems = GameObject.Find("EquipWindows").transform.FindChild("EquipAssistTab/Item").gameObject;



        //활성화된 아이템이 기록되어 있고 그 아이템이 한개이상 있을경우.
        if (activeIconNum > 0 && int.Parse((ValueDeliverScript.gameData["Equip" + equipName + activeIconNum.ToString("D2")]).ToString()) > 0)
        {
            equipTabItems.transform.FindChild("MountItem").gameObject.SetActive(true);  //마운트 아이콘을 활성화 한다.

            // 1.먼저 이큅세팅창에 활성화된 아이콘을 표시한다.
            Icon.GetComponent<UISprite>().spriteName = getSpriteName[activeIconNum].Replace("big", "med");
            Icon.GetComponent<UISprite>().MakePixelPerfect();
            //Icon.GetComponent<BoxCollider>().size = new Vector3(1, 1, 1);

            // 2.활성화된 아이템변수와 컴포넌트에 같은 번호를 가진 아이템을 찾는다.
            int itemCount = equipTabItems.transform.childCount;    //탭내의 아이템의 갯수를 센다.
            for (int i = 0; i < itemCount; i++)
            {
                ItemKeyValueScript itemKeyValueScript = equipTabItems.transform.GetChild(i).GetComponent<ItemKeyValueScript>();
                //먼저 아이템인지 확인.
                if (itemKeyValueScript && itemKeyValueScript.itemNumber > 0 && itemKeyValueScript.itemNumber == activeIconNum)
                {
                    //마운트 아이템의 위치를 아이템과 같은 위치가 되도록 한다.
                    equipTabItems.transform.FindChild("MountItem").localPosition = equipTabItems.transform.GetChild(i).localPosition + new Vector3(-1, 3, -1) - equipTabItems.transform.localPosition;
                    equipTabItems.transform.GetChild(i).transform.FindChild("Label").GetComponent<UILabel>().text = (ValueDeliverScript.gameData["Equip" + equipName + activeIconNum.ToString("D2")]).ToString();
                    break;
                }
            }
        }




        //활성화 되어 있는 아이템이 없으면 구매된 아이템이 있는지 검사.
        else
        {
            // 0.어느 아이템도 활성화되어 있지 않게 바꾸어준다.
            if (equipName == "Bomb") ValueDeliverScript.gameData["activeBomb"] = 0;
            else if (equipName == "Reinforce") ValueDeliverScript.gameData["activeReinforce"] = 0;
            else if (equipName == "Assist") ValueDeliverScript.gameData["activeAssist"] = 0;

            // 1.먼저 이큅세팅창에 활성화된 아이콘을 표시한다.
            for (int i = 1; i < getSpriteName.Length; i++)
            {
                //여기서 i 값은 각각의 아이템의 아이템넘버값과 동일함. 바로 위의 액티브 아이콘 값과도 값은 결과를 내는 값임.
                if (int.Parse(ValueDeliverScript.gameData["Equip" + equipName + i.ToString("D2")].ToString()) > 0 && getSpriteName[i] != null)
                {
                    Icon.GetComponent<UISprite>().spriteName = getSpriteName[i].Replace("big", "med");
                    Icon.GetComponent<UISprite>().MakePixelPerfect();
                    //Icon.GetComponent<BoxCollider>().size = new Vector3(1, 1, 1);	//콜라이더의 크기를 적당한 크기로 조정하여 터치 오류를 줄이기 위한 부분.

                    activeIconNum = i;
                    //활성아이템 표시 액티브 변수에 기록.//////////////////////////////////////////////////////////////////////////////
                    if (equipName == "Bomb") ValueDeliverScript.gameData["activeBomb"] = i;																		///
                    else if (equipName == "Reinforce") ValueDeliverScript.gameData["activeReinforce"] = i;																	///
                    else if (equipName == "Assist") ValueDeliverScript.gameData["activeAssist"] = i;																	///
                    break;
                }
                else if (i + 1 >= getSpriteName.Length)
                {

                    if (equipName == "Bomb") ValueDeliverScript.gameData["activeBomb"] = 0;
                    else if (equipName == "Reinforce") ValueDeliverScript.gameData["activeReinforce"] = 0;
                    else if (equipName == "Assist") ValueDeliverScript.gameData["activeAssist"] = 0;
                }	//if끝.
            }	//for끝.

            // 2.이큅아이템 선택창에 장착중 아이콘을 표시준비를 한다.한개이상 구매한 아이템이 있는지 검사한다.
            int itemCount = equipTabItems.transform.childCount;   //탭내의 아이템의 갯수를 센다.
            GameObject[] items = new GameObject[itemCount];

            // 4.정렬을 하기 위해 아이템들을 임시 배열 오브젝트에 모은다.
            for (int i = 0; i < itemCount; i++)
            {
                items[i] = equipTabItems.transform.GetChild(i).gameObject;
            }

            // 5.버블 정렬을 실행한다. 위치번호를 기반으로 배열을 재정렬하여준다.
            GameObject[] sortItems = new GameObject[itemCount];
            sortItems = BubbleSort(items, itemCount);

            // 6.재정렬된 아이템들을 각각 조사하여 적어도 한개이상 있는지 구매되어 있는지 조사한다.
            for (int i = 0; i < itemCount; i++)
            {
                if (!sortItems[i].GetComponent<ItemKeyValueScript>()) continue;
                int itemNum = sortItems[i].GetComponent<ItemKeyValueScript>().itemNumber;
                ////Debug.Log("어디에서 에러가 나는가 알아보자."+equipName + itemNum.ToString("D2"));
                if (itemNum != 0 && int.Parse((ValueDeliverScript.gameData["Equip" + equipName + itemNum.ToString("D2")]).ToString()) > 0)
                {
                    equipTabItems.transform.FindChild("MountItem").gameObject.SetActive(true);  //마운트 아이콘을 활성화 한다.
                    // 7.한개이상 구매되어 있을경우 해당아이템의 위치에 장착중 아이콘을 표시하여준다.
                    equipTabItems.transform.FindChild("MountItem").localPosition = sortItems[i].transform.localPosition + new Vector3(-1, 3, -1);

                    //어떤 아이템이 장착되었는지 활성화 여부를 알려준다.
                    if (equipName == "Bomb") ValueDeliverScript.gameData["activeBomb"] = itemNum;
                    else if (equipName == "Reinforce") ValueDeliverScript.gameData["activeReinforce"] = itemNum;
                    else if (equipName == "Assist") ValueDeliverScript.gameData["activeAssist"] = itemNum;
                    break;
                }
            }
        }
        ValueDeliverScript.gameData["flightNumber"] = ValueDeliverScript.flightNumber;
        //Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
        ValueDeliverScript.SaveGameData();
        //Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
    }//EquipIconSetting함수 끝.



    GameObject[] BubbleSort(GameObject[] items, int itemCount)
    {
        GameObject tempItem = null;
        for (int j = 0; j < itemCount - 1; j++)
        {
            for (int i = 0; i < itemCount - 1; i++)
            {
                ////Debug.Log(":::::: 버블 정렬 현재 반복 횟수 :: J :: " + j + " :: i :: " + i + " ::::::");
                if (!items[i].GetComponent<ItemKeyValueScript>())   //아이템이 아닌 오브젝트일 경우 배열의 맨끝으로 이동시켜 준다.
                {
                    tempItem = items[i];
                    for (int k = i; k < itemCount - 1; k++)
                    {
                        items[k] = items[k + 1];
                    }
                    items[itemCount - 1] = tempItem;
                    continue;
                }

                if (items[i].GetComponent<ItemKeyValueScript>() && items[i + 1].GetComponent<ItemKeyValueScript>())
                {
                    if (items[i].GetComponent<ItemKeyValueScript>().itemPositionNumber > items[i + 1].GetComponent<ItemKeyValueScript>().itemPositionNumber)
                    {
                        tempItem = items[i + 1];
                        items[i + 1] = items[i];
                        items[i] = tempItem;
                    }
                }
            }
        }
        return items;
    }

    IEnumerator GoToGarage()
    {
        if (ValueDeliverScript.bgSound == 0.5f) //소리가 켜져있을경우 결과창 BGM에서 격납고 BGM으로 변경.
        {
            AudioSource resultSound = GameObject.Find("ResultSoundManager").GetComponent<AudioSource>();
            AudioSource bgSound = GameObject.Find("BgSoundManager").GetComponent<AudioSource>();
            resultSound.volume = 1f;
            bgSound.volume = 0f;

            while (resultSound.volume > 0)
            {
                resultSound.volume -= Time.deltaTime * 4;
                bgSound.volume += Time.deltaTime * 4;
                yield return null;
            }
        }

        if (storeWindow.transform.localPosition.x == 40)
        {
            storeWindow.animation.Play("StoreWindowAnim02");
        }
        else
        {
            ResultPanel.transform.FindChild("ResultPanelLeft").animation.Play("ResultPanelLeftAnim03");
            ResultPanel.transform.FindChild("ResultPanelRight").animation.Play("ResultPanelRightAnim02");
        }
        ResultPanel.transform.FindChild("ResultLowTab").animation.Play("ResultLowTabAnim02");

        yield return new WaitForSeconds(1f);
        flights.animation.Play("FlightsPanelAnim01");
        prepareReady.animation.Play("PrepareReadyAnim01");
        flights.transform.FindChild("MoveTF/FlightsMove").localPosition = new Vector3(ValueDeliverScript.flightNumber * -1000, 0, 0);
        ///*
        if (resultSkinNumber != 0 && int.Parse(ValueDeliverScript.gameData[resultSkinName].ToString()) <= 0)
        {
            Debug.Log("SkinDuraShot!!!!");
            //스킨 내구도가 0이하로 떨어지면 이 부분을 실행!
            //스킨 내구도 복구 유도 창을 띄운다.
            duraBuyAlarmWindow.SetActive(true);
            halfBLKPanel.SetActive(true);
            halfBLKPanel.transform.localPosition = new Vector3(halfBLKPanel.transform.localPosition.x, halfBLKPanel.transform.localPosition.y, duraBuyAlarmWindow.transform.localPosition.z + 5);
        }
        else
        {
            flights.SetActive(true);
            ResultPanel.SetActive(false);
        }
        //*/
    }


    IEnumerator GoToGarage2()
    {
        ValueDeliverScript.rescueArlamFriendId = "";

        if (ValueDeliverScript.isBgSound == true) //소리가 켜져있을경우 결과창 BGM에서 격납고 BGM으로 변경.
        {
            AudioSource resultSound = GameObject.Find("ResultSoundManager").GetComponent<AudioSource>();
            AudioSource bgSound = GameObject.Find("BgSoundManager").GetComponent<AudioSource>();
            resultSound.volume = 1f;
            bgSound.volume = 0f;
            bgSound.Play();

            while (resultSound.volume > 0)
            {
                resultSound.volume -= Time.deltaTime * 4;
                bgSound.volume += Time.deltaTime * 4;
                yield return null;
            }

        }

        if (storeWindow.transform.localPosition.x == 40)
            storeWindow.animation.Play("StoreWindowAnim02");
        else
        {
            ResultPanel.transform.FindChild("ResultPanelLeft").animation.Play("ResultPanelLeftAnim03");
            ResultPanel.transform.FindChild("ResultPanelRight").animation.Play("ResultPanelRightAnim02");
        }

        ResultPanel.transform.FindChild("ResultLowTab").animation.Play("ResultLowTabAnim02");
        bgTop.animation.Play("BGMainTopAnim02");
        yield return new WaitForSeconds(1f);

        /////////
        friendWindow.SetActive(true);

        friendWindow.transform.FindChild("TapSprits/RankTab").GetComponent<UISprite>().spriteName = "Btn_TapRight_00";
        friendWindow.transform.FindChild("TapSprits/MailTab").GetComponent<UISprite>().spriteName = "Btn_TapRight_01";

        friendWindow.transform.FindChild("RankGrid").GetComponent<UIPanel>().alpha = 1;
        friendWindow.transform.FindChild("RankGrid").gameObject.SetActive(true);

        friendWindow.transform.FindChild("MessageGrid").gameObject.SetActive(false);
        friendWindow.transform.FindChild("MessageGrid").GetComponent<UIPanel>().alpha = 0;

        prepareReady.animation.Play("PrepareReadyAnim01_1");
        friendWindow.animation.Play("FriendWindowAnim01");
        yield return new WaitForSeconds(0.5f);
        friendWindow.transform.FindChild("BackBtn").gameObject.SetActive(true);
        /////////



        if (resultSkinNumber != 0 && int.Parse(ValueDeliverScript.gameData[resultSkinName].ToString()) <= 0)
        {
            Debug.Log("SkinDuraShot!!!!");
            //스킨 내구도가 0이하로 떨어지면 이 부분을 실행!
            //스킨 내구도 복구 유도 창을 띄운다.
            duraBuyAlarmWindow.SetActive(true);
            halfBLKPanel.SetActive(true);
            halfBLKPanel.transform.localPosition = new Vector3(halfBLKPanel.transform.localPosition.x, halfBLKPanel.transform.localPosition.y, duraBuyAlarmWindow.transform.localPosition.z + 5);

        }
    }

    public GameObject NoSelectFriendWindow;
    public GameObject BlockMessageFriendWindow;

    void NoSelectFriend()
    {
        NoSelectFriendWindow.SetActive(true);
        halfBLKPanel.transform.localPosition = new Vector3(halfBLKPanel.transform.localPosition.x, halfBLKPanel.transform.localPosition.y, NoSelectFriendWindow.transform.localPosition.z + 5);
    }

    void CloseNoSelectFriend()
    {
        NoSelectFriendWindow.SetActive(false);
        halfBLKPanel.SetActive(false);
    }

    void BlockMessageFriend()
    {
        BlockMessageFriendWindow.SetActive(true);
        halfBLKPanel.transform.localPosition = new Vector3(halfBLKPanel.transform.localPosition.x, halfBLKPanel.transform.localPosition.y, BlockMessageFriendWindow.transform.localPosition.z + 5);
    }

    void CloseBlockMessageFriend()
    {
        BlockMessageFriendWindow.SetActive(false);
        halfBLKPanel.SetActive(false);
    }

    public void Arlam()
    {
        halfBLKPanel.SetActive(false);
        // 알람처리 구문 입력.
        rescueAchieveWindow.SetActive(false);
        halfBLKPanel.transform.localPosition = new Vector3(halfBLKPanel.transform.localPosition.x, halfBLKPanel.transform.localPosition.y, -166);
        ValueDeliverScript.isArlamRescue = true;
    }

    public void ArlamCancel()
    {
        halfBLKPanel.SetActive(false);
        //알람캔슬처리 입력.
        rescueAchieveWindow.SetActive(false);
        halfBLKPanel.transform.localPosition = new Vector3(halfBLKPanel.transform.localPosition.x, halfBLKPanel.transform.localPosition.y, -166);
    }

    public void GoToSoundWindow()
    {
        halfBLKPanel.SetActive(true);

        soundControlWindow.SetActive(true);
        halfBLKPanel.transform.localPosition = new Vector3(halfBLKPanel.transform.localPosition.x, halfBLKPanel.transform.localPosition.y, soundControlWindow.transform.localPosition.z + 5);
    }

    public void SoundWindowClose()
    {
        halfBLKPanel.SetActive(false);
        soundControlWindow.SetActive(false);
        halfBLKPanel.transform.localPosition = new Vector3(halfBLKPanel.transform.localPosition.x, halfBLKPanel.transform.localPosition.y, -166);
    }

    public void GoToAllBuyWindow()
    {
        int coinRest = int.Parse(ValueDeliverScript.gameData["coinRest"].ToString());
        if (coinRest < ValueDeliverScript.salePriceInt)
        {
            GoToCoinShortageWindow();
            return;
        }

        halfBLKPanel.SetActive(true);
        allBuyWindow.SetActive(true);
        halfBLKPanel.transform.localPosition = new Vector3(halfBLKPanel.transform.localPosition.x, halfBLKPanel.transform.localPosition.y, allBuyWindow.transform.localPosition.z + 5);
    }

    public void AllBuyWindowBuy()
    {
        halfBLKPanel.SetActive(false);
        allBuyWindow.SetActive(false);
        halfBLKPanel.transform.localPosition = new Vector3(halfBLKPanel.transform.localPosition.x, halfBLKPanel.transform.localPosition.y, -166);

        ValueDeliverScript.gameData["Equip" + ValueDeliverScript.saleItem01] = (int.Parse(ValueDeliverScript.gameData["Equip" + ValueDeliverScript.saleItem01].ToString()) + 1);
        ValueDeliverScript.gameData["Equip" + ValueDeliverScript.saleItem02] = (int.Parse(ValueDeliverScript.gameData["Equip" + ValueDeliverScript.saleItem02].ToString()) + 1);
        ValueDeliverScript.gameData["Equip" + ValueDeliverScript.saleItem03] = (int.Parse(ValueDeliverScript.gameData["Equip" + ValueDeliverScript.saleItem03].ToString()) + 1);

        ValueDeliverScript.gameData["activeBomb"] = int.Parse(ValueDeliverScript.saleItem01.Replace("Bomb", ""));
        ValueDeliverScript.gameData["activeReinforce"] = int.Parse(ValueDeliverScript.saleItem02.Replace("Reinforce", ""));
        ValueDeliverScript.gameData["activeAssist"] = int.Parse(ValueDeliverScript.saleItem03.Replace("Assist", ""));

        ValueDeliverScript.gameData["coinRest"] = int.Parse(ValueDeliverScript.gameData["coinRest"].ToString()) - ValueDeliverScript.salePriceInt;


        GameObject.Find("GameManager").GetComponent<GasTimeScript>().MedalRecount(); //화면에 표시되는 메달양을 다시 계산하여 재표시하여줌.
        GameObject.Find("GameManager").GetComponent<GasTimeScript>().CoinRecount(); //화면에 표시되는 동전양을 다시 계산하여 재표시하여줌.

        EquipStartSetting();  //1173번줄에 있는 이큅스타트세팅 함수를 호출.
        ValueDeliverScript.gameData["flightNumber"] = ValueDeliverScript.flightNumber;
        //Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
        ValueDeliverScript.SaveGameData();
        //Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
    }

    public void AllBuyWindowCancel()
    {
        //구매 캔슬 코드. 굳이 필요없음.
        halfBLKPanel.SetActive(false);
        allBuyWindow.SetActive(false);
        halfBLKPanel.transform.localPosition = new Vector3(halfBLKPanel.transform.localPosition.x, halfBLKPanel.transform.localPosition.y, -166);
    }

    public void GoToPilotLevelUpWindow()
    {
        halfBLKPanel.SetActive(true);
        pilotLevelUpWindow.SetActive(true);
        halfBLKPanel.transform.localPosition = new Vector3(halfBLKPanel.transform.localPosition.x, halfBLKPanel.transform.localPosition.y, pilotLevelUpWindow.transform.localPosition.z + 5);

        int userLevel = int.Parse(ValueDeliverScript.gameData["userLevel"].ToString());
        int upgradePoint = int.Parse(ValueDeliverScript.gameData["upgradePoint"].ToString());

        ValueDeliverScript.gameData["upgradePoint"] = int.Parse(ValueDeliverScript.gameData["upgradePoint"].ToString()) + 1;

        if (isSkinFullLevel && userLevel == 10 && userLevel == 20)
        {
            ValueDeliverScript.gameData["upgradePoint"] = upgradePoint + 5;
            upgradePointWindow.transform.FindChild("PointAdd").GetComponent<UILabel>().text = "X 6";
        }
        else if (userLevel == 10 && userLevel == 20)
        {
            ValueDeliverScript.gameData["upgradePoint"] = upgradePoint + 3;
            upgradePointWindow.transform.FindChild("PointAdd").GetComponent<UILabel>().text = "X 4";
        }
        else
        {
            upgradePointWindow.transform.FindChild("PointAdd").GetComponent<UILabel>().text = "X 1";
        }

        HangerControl hangerCon = GameObject.Find("GameManager").GetComponent<HangerControl>();

        flightUpointSetScript.RedrawStatePoint();
        ValueDeliverScript.gameData["flightNumber"] = ValueDeliverScript.flightNumber;
        //Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
        ValueDeliverScript.SaveGameData();
        //Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
    }

    public void PilotLevelUpWindowClose()
    {
        halfBLKPanel.SetActive(false);
        pilotLevelUpWindow.SetActive(false);
        halfBLKPanel.transform.localPosition = new Vector3(halfBLKPanel.transform.localPosition.x, halfBLKPanel.transform.localPosition.y, -166);
        ShowUpgradePointWindow();
    }

    public void FirstAccessOpen()
    {
        GameObject.Find("Windows").transform.FindChild("FirstAccessWindow").gameObject.SetActive(true);
        halfBLKPanel.SetActive(true);
    }

    public void FirstAccessClose()
    {
        GameObject.Find("Windows").transform.FindChild("FirstAccessWindow").gameObject.SetActive(false);
        StartCoroutine(GameObject.Find("TutManager").GetComponent<TutManagerScript>().TutEnd());
    }

    //기본스토어관련창
    IEnumerator TransChange(GameObject go, float TransValue)   //지정한 탭(내용물들)이 점점 사라지게 할지 보이게 할지 결정하는 함수. 0이면 사라지고 1이면 보임.
    {
        go.SetActive(true);
        float lValue = 0;
        float firstValue = go.GetComponent<UIPanel>().alpha;
        while (lValue <= 1)
        {
            go.GetComponent<UIPanel>().alpha = Mathf.Lerp(firstValue, TransValue, lValue);
            lValue += Time.deltaTime * 3;
            yield return null;
        }
        go.GetComponent<UIPanel>().alpha = Mathf.Lerp(firstValue, TransValue, 1);

        if (TransValue == 0)
        {
            go.SetActive(false);
        }
    }

    IEnumerator GoToStoreCoinWindow()
    {
        CoinShortageWindow.SetActive(false);
        halfBLKPanel.SetActive(false);
        pilotLevelUpWindow.SetActive(false);
        duraBuyAlarmWindow.SetActive(false);

        storeWindow.SetActive(true);

        if (storeWindow.transform.localPosition.x == 40)    //이미 스토어창이 보이는 상태이면(스토어창이 보이는 위치는 x값이 40이다)
        {
            StartCoroutine(TransChange(storeWindow.transform.FindChild("TabCoin").gameObject, 1));
            StartCoroutine(TransChange(storeWindow.transform.FindChild("TabGas").gameObject, 0));
            StartCoroutine(TransChange(storeWindow.transform.FindChild("TabMedal").gameObject, 0));

            //지정된 탭(여기서는 코인) 활성화 이미지로 변경.
            storeWindow.transform.FindChild("Base/TabCoinIcon").GetComponent<UISprite>().spriteName = "bt_blue_t_top_n";
            storeWindow.transform.FindChild("Base/TabGasIcon").GetComponent<UISprite>().spriteName = "bt_blue_t_top_o";
            storeWindow.transform.FindChild("Base/TabMedalIcon").GetComponent<UISprite>().spriteName = "bt_blue_t_top_o";

            //이미지가 변경되면서 왜곡된 이미지를 정상크기와 위치로 맞춰줌.
            storeWindow.transform.FindChild("Base/TabCoinIcon").GetComponent<UISprite>().MakePixelPerfect();
            storeWindow.transform.FindChild("Base/TabGasIcon").GetComponent<UISprite>().MakePixelPerfect();
            storeWindow.transform.FindChild("Base/TabMedalIcon").GetComponent<UISprite>().MakePixelPerfect();


        }
        else
        {
            //스토어창이 보이지 않는 상태이면 탭이미지들을 변경하고 스토어의 백버튼을 활성화한다.
            storeWindow.transform.FindChild("Base/TabCoinIcon").GetComponent<UISprite>().spriteName = "bt_blue_t_top_n";
            storeWindow.transform.FindChild("Base/TabGasIcon").GetComponent<UISprite>().spriteName = "bt_blue_t_top_o";
            storeWindow.transform.FindChild("Base/TabMedalIcon").GetComponent<UISprite>().spriteName = "bt_blue_t_top_o";

            storeWindow.transform.FindChild("Base/TabCoinIcon").GetComponent<UISprite>().MakePixelPerfect();
            storeWindow.transform.FindChild("Base/TabGasIcon").GetComponent<UISprite>().MakePixelPerfect();
            storeWindow.transform.FindChild("Base/TabMedalIcon").GetComponent<UISprite>().MakePixelPerfect();

            storeWindow.transform.FindChild("TabCoin").gameObject.SetActive(true);
            storeWindow.transform.FindChild("TabCoin").GetComponent<UIPanel>().alpha = 1;

            storeWindow.transform.FindChild("TabGas").GetComponent<UIPanel>().alpha = 0;
            storeWindow.transform.FindChild("TabGas").gameObject.SetActive(false);

            storeWindow.transform.FindChild("TabMedal").GetComponent<UIPanel>().alpha = 0;
            storeWindow.transform.FindChild("TabMedal").gameObject.SetActive(false);

            if (equipWindows.transform.localPosition.x == 40)
            {
                equipToStoreOn = true;
                equipWindows.animation.Play("StoreWindowAnim03");
                equipWindows.transform.FindChild("Base/BackBtn").gameObject.SetActive(false);
            }

            else if (ResultPanel.transform.FindChild("ResultPanelLeft").localPosition.x == 0)
            {
                resultToStoreOn = true;
                ResultPanel.transform.FindChild("ResultPanelLeft").animation.Play("ResultPanelLeftAnim03");
                ResultPanel.transform.FindChild("ResultPanelRight").animation.Play("ResultPanelRightAnim02");

                yield return new WaitForSeconds(1f);
            }
            else if (skinSelectWindow00.transform.localPosition.x == 40)
            {
                skin00ToStoreOn = true;
                skinSelectWindow00.animation.Play("SkinSelectWindowAnim03");
                skinSelectWindow00.transform.FindChild("BackBtn").gameObject.SetActive(false);
            }
            else if (skinSelectWindow01.transform.localPosition.x == 40)
            {
                skin01ToStoreOn = true;
                skinSelectWindow01.animation.Play("SkinSelectWindowAnim03");
                skinSelectWindow01.transform.FindChild("BackBtn").gameObject.SetActive(false);
            }
            else if (skinSelectWindow02.transform.localPosition.x == 40)
            {
                skin02ToStoreOn = true;
                skinSelectWindow02.animation.Play("SkinSelectWindowAnim03");
                skinSelectWindow02.transform.FindChild("BackBtn").gameObject.SetActive(false);
            }
            else
            {
                flights.animation.Play("FlightsPanelAnim02");
            }
            //실제 스토어 윈도우가 나타는 애니메이션을 플레이 해준다.
            storeWindow.animation.Play("StoreWindowAnim01");
            yield return new WaitForSeconds(0.5f);
            //백버튼 활성화.
            storeWindow.transform.FindChild("Base/BackBtn").gameObject.SetActive(true);

        }

    }

    IEnumerator GoToStoreGasWindow()
    {
        GasShortageWindow.SetActive(false);
        halfBLKPanel.SetActive(false);
        pilotLevelUpWindow.SetActive(false);
        duraBuyAlarmWindow.SetActive(false);


        storeWindow.SetActive(true);

        if (storeWindow.transform.localPosition.x == 40)
        {
            StartCoroutine(TransChange(storeWindow.transform.FindChild("TabCoin").gameObject, 0));
            StartCoroutine(TransChange(storeWindow.transform.FindChild("TabGas").gameObject, 1));
            StartCoroutine(TransChange(storeWindow.transform.FindChild("TabMedal").gameObject, 0));

            storeWindow.transform.FindChild("Base/TabCoinIcon").GetComponent<UISprite>().spriteName = "bt_blue_t_top_o";
            storeWindow.transform.FindChild("Base/TabGasIcon").GetComponent<UISprite>().spriteName = "bt_blue_t_top_n";
            storeWindow.transform.FindChild("Base/TabMedalIcon").GetComponent<UISprite>().spriteName = "bt_blue_t_top_o";
        }
        else
        {
            storeWindow.transform.FindChild("Base/TabCoinIcon").GetComponent<UISprite>().spriteName = "bt_blue_t_top_o";
            storeWindow.transform.FindChild("Base/TabGasIcon").GetComponent<UISprite>().spriteName = "bt_blue_t_top_n";
            storeWindow.transform.FindChild("Base/TabMedalIcon").GetComponent<UISprite>().spriteName = "bt_blue_t_top_o";

            storeWindow.transform.FindChild("TabCoin").GetComponent<UIPanel>().alpha = 0;
            storeWindow.transform.FindChild("TabCoin").gameObject.SetActive(false);

            storeWindow.transform.FindChild("TabGas").gameObject.SetActive(true);
            storeWindow.transform.FindChild("TabGas").GetComponent<UIPanel>().alpha = 1;

            storeWindow.transform.FindChild("TabMedal").GetComponent<UIPanel>().alpha = 0;
            storeWindow.transform.FindChild("TabMedal").gameObject.SetActive(false);

            if (equipWindows.transform.localPosition.x == 40)
            {
                equipToStoreOn = true;
                equipWindows.animation.Play("StoreWindowAnim03");
                equipWindows.transform.FindChild("Base/BackBtn").gameObject.SetActive(false);
            }

            else if (ResultPanel.transform.FindChild("ResultPanelLeft").transform.localPosition.x == 0)
            {
                resultToStoreOn = true;
                ResultPanel.transform.FindChild("ResultPanelLeft").animation.Play("ResultPanelLeftAnim03");
                ResultPanel.transform.FindChild("ResultPanelRight").animation.Play("ResultPanelRightAnim02");
                yield return new WaitForSeconds(1f);
            }

            else if (skinSelectWindow00.transform.localPosition.x == 40)
            {
                skin00ToStoreOn = true;
                skinSelectWindow00.animation.Play("SkinSelectWindowAnim03");
                skinSelectWindow00.transform.FindChild("BackBtn").gameObject.SetActive(false);
            }
            else if (skinSelectWindow01.transform.localPosition.x == 40)
            {
                skin01ToStoreOn = true;
                skinSelectWindow01.animation.Play("SkinSelectWindowAnim03");
                skinSelectWindow01.transform.FindChild("BackBtn").gameObject.SetActive(false);
            }
            else if (skinSelectWindow02.transform.localPosition.x == 40)
            {
                skin02ToStoreOn = true;
                skinSelectWindow02.animation.Play("SkinSelectWindowAnim03");
                skinSelectWindow02.transform.FindChild("BackBtn").gameObject.SetActive(false);
            }
            else if (equipWindows.transform.localPosition.x == 40)
            {
                equipToStoreOn = true;
                equipWindows.animation.Play("StoreWindowAnim03");
                equipWindows.transform.FindChild("Base/BackBtn").gameObject.SetActive(false);
            }
            else
            {
                flights.animation.Play("FlightsPanelAnim02");
            }
            storeWindow.animation.Play("StoreWindowAnim01");
            yield return new WaitForSeconds(0.5f);
            storeWindow.transform.FindChild("Base/BackBtn").gameObject.SetActive(true);
        }

        storeWindow.transform.FindChild("Base/TabCoinIcon").GetComponent<UISprite>().MakePixelPerfect();
        storeWindow.transform.FindChild("Base/TabGasIcon").GetComponent<UISprite>().MakePixelPerfect();
        storeWindow.transform.FindChild("Base/TabMedalIcon").GetComponent<UISprite>().MakePixelPerfect();
    }

    IEnumerator GoToStoreMedalWindow()
    {
        MedalShortageWindow.SetActive(false);
        GasShortageWindow.SetActive(false);
        halfBLKPanel.SetActive(false);
        pilotLevelUpWindow.SetActive(false);
        duraBuyAlarmWindow.SetActive(false);

        storeWindow.SetActive(true);

        if (storeWindow.transform.localPosition.x == 40)
        {
            StartCoroutine(TransChange(storeWindow.transform.FindChild("TabCoin").gameObject, 0));
            StartCoroutine(TransChange(storeWindow.transform.FindChild("TabGas").gameObject, 0));
            StartCoroutine(TransChange(storeWindow.transform.FindChild("TabMedal").gameObject, 1));

            storeWindow.transform.FindChild("Base/TabCoinIcon").GetComponent<UISprite>().spriteName = "bt_blue_t_top_o";
            storeWindow.transform.FindChild("Base/TabGasIcon").GetComponent<UISprite>().spriteName = "bt_blue_t_top_o";
            storeWindow.transform.FindChild("Base/TabMedalIcon").GetComponent<UISprite>().spriteName = "bt_blue_t_top_n";
        }
        else
        {
            storeWindow.transform.FindChild("Base/TabCoinIcon").GetComponent<UISprite>().spriteName = "bt_blue_t_top_o";
            storeWindow.transform.FindChild("Base/TabGasIcon").GetComponent<UISprite>().spriteName = "bt_blue_t_top_o";
            storeWindow.transform.FindChild("Base/TabMedalIcon").GetComponent<UISprite>().spriteName = "bt_blue_t_top_n";

            storeWindow.transform.FindChild("TabCoin").GetComponent<UIPanel>().alpha = 0;
            storeWindow.transform.FindChild("TabCoin").gameObject.SetActive(false);

            storeWindow.transform.FindChild("TabGas").GetComponent<UIPanel>().alpha = 0;
            storeWindow.transform.FindChild("TabGas").gameObject.SetActive(false);

            storeWindow.transform.FindChild("TabMedal").gameObject.SetActive(true);
            storeWindow.transform.FindChild("TabMedal").GetComponent<UIPanel>().alpha = 1;

            if (equipWindows.transform.localPosition.x == 40)
            {
                equipToStoreOn = true;
                equipWindows.animation.Play("StoreWindowAnim03");
                equipWindows.transform.FindChild("Base/BackBtn").gameObject.SetActive(false);
            }
            else if (ResultPanel.transform.FindChild("ResultPanelLeft").transform.localPosition.x == 0)
            {
                resultToStoreOn = true;
                ResultPanel.transform.FindChild("ResultPanelLeft").animation.Play("ResultPanelLeftAnim03");
                ResultPanel.transform.FindChild("ResultPanelRight").animation.Play("ResultPanelRightAnim02");
                yield return new WaitForSeconds(1f);
            }
            else if (skinSelectWindow00.transform.localPosition.x == 40)
            {
                skin00ToStoreOn = true;
                skinSelectWindow00.animation.Play("SkinSelectWindowAnim03");
                skinSelectWindow00.transform.FindChild("BackBtn").gameObject.SetActive(false);
            }
            else if (skinSelectWindow01.transform.localPosition.x == 40)
            {
                skin01ToStoreOn = true;
                skinSelectWindow01.animation.Play("SkinSelectWindowAnim03");
                skinSelectWindow01.transform.FindChild("BackBtn").gameObject.SetActive(false);
            }
            else if (skinSelectWindow02.transform.localPosition.x == 40)
            {
                skin02ToStoreOn = true;
                skinSelectWindow02.animation.Play("SkinSelectWindowAnim03");
                skinSelectWindow02.transform.FindChild("BackBtn").gameObject.SetActive(false);
            }
            else
            {
                flights.animation.Play("FlightsPanelAnim02");
            }
            storeWindow.animation.Play("StoreWindowAnim01");
            yield return new WaitForSeconds(0.5f);
            storeWindow.transform.FindChild("Base/BackBtn").gameObject.SetActive(true);
        }

        storeWindow.transform.FindChild("Base/TabCoinIcon").GetComponent<UISprite>().MakePixelPerfect();
        storeWindow.transform.FindChild("Base/TabGasIcon").GetComponent<UISprite>().MakePixelPerfect();
        storeWindow.transform.FindChild("Base/TabMedalIcon").GetComponent<UISprite>().MakePixelPerfect();
    }



    //친구관련창.
    IEnumerator GoToFriendRankTab()
    {

        //string path = "file://E:/Kazumi.mp3";
        //WWW www = new WWW(path);

        //yield return www;

        //AudioClip lClip = www.audioClip;

        //Debug.Log("채널 :: " + lClip.channels);
        //Debug.Log("길이 :: " + lClip.length);

        //audio.Stop();
        //audio.clip = lClip;
        //audio.Play();






        ValueDeliverScript.AllMessageCount = 0;

        noTouchPanel.SetActive(true);
        GasShortageWindow.SetActive(false);
        halfBLKPanel.SetActive(false);
        pilotLevelUpWindow.SetActive(false);
        duraBuyAlarmWindow.SetActive(false);

        //게임종료후 결과창에서 친구 정보창으로 이동할때만 작동하는 코드이다//
        if (ResultPanel.transform.FindChild("ResultPanelLeft").transform.localPosition.x == 0)
        {
            Debug.Log("PrepareReadyAnim01");
            ResultPanel.transform.FindChild("ResultPanelLeft").animation.Play("ResultPanelLeftAnim03");
            ResultPanel.transform.FindChild("ResultPanelRight").animation.Play("ResultPanelRightAnim02");
            ResultPanel.transform.FindChild("ResultLowTab").animation.Play("ResultLowTabAnim02");
            yield return new WaitForSeconds(1f);

            prepareReady.animation.Play("PrepareReadyAnim01");
            bgTop.animation.Play("BGMainTopAnim02");
            yield return new WaitForSeconds(0.4f);
            friendWindow.animation.Play("FriendWindowAnim01");
            yield return new WaitForSeconds(0.5f);
            friendWindow.transform.FindChild("BackBtn").gameObject.SetActive(true);

            yield break;
        }
        //게임종료후 결과창에서 친구 정보창으로 이동할때만 작동하는 코드이다//



        //하단의 정보창에서 정보를 어떻게 보여줄 것인가를 결정하고 그에 따른 다른 애니메이션을 작동하게 하는것//
        //친구포인트가 100이상이면 친구 보상을 받을수 있게 버튼을 보여주고//
        //그렇지 않으면 보상 버튼을 보이지 않게 하는 애니메이션을 실행한다//
        else if (int.Parse(ValueDeliverScript.gameData["friendshipPoint"].ToString()) < 100)
        {
            prepareReady.animation.Play("PrepareReadyAnim03");
        }
        else
        {
            prepareReady.animation.Play("PrepareReadyAnim03_1");
        }
        //하단의 정보창에서 정보를 어떻게 보여줄 것인가를 결정하고 그에 따른 다른 애니메이션을 작동하게 하는것//


        //friendWindow는 친구 랭킹이 표시되는 창을 뜻한다//
        friendWindow.SetActive(true);
        friendWindow.transform.FindChild("Script01").GetComponent<UILabel>().text = "点击好友时，可查看所使用的战机组。";
        //friendWindow.transform.FindChild("Script02").GetComponent<UILabel>().text = "연료를 발송하면 우정포인트를 획득할 수 있습니다.";




        //시간을 계산하여 앞으로 초기화가 얼마나 남았는지 알아내는 코드//
        //남은시간을 상단 텍스트 표시부분에 반영하여 얼마가 남았는지 알려준다//
        DayOfWeek todayWeek = DateTime.UtcNow.AddHours(7).DayOfWeek;
        int dayCount = (int)todayWeek;
        int remainDays = 7 - dayCount;
        if (dayCount == 0) remainDays = 0;

        int remainHours = 23 - Mathf.FloorToInt((float)DateTime.UtcNow.AddHours(7).TimeOfDay.TotalHours);

        friendWindow.transform.FindChild("Script03").GetComponent<UILabel>().text = remainDays + "日" + remainHours + "小时后初始化";
        //시간을 계산하여 앞으로 초기화가 얼마나 남았는지 알아내는 코드//
        //남은시간을 상단 텍스트 표시부분에 반영하여 얼마가 남았는지 알려준다//



        if (friendWindow.transform.localPosition.x == 40)
        {
            StartCoroutine(TransChange(friendWeekTab, 1));
            StartCoroutine(TransChange(friendMailTab, 0));
            friendWindow.transform.FindChild("TapSprits/RankTab").GetComponent<UISprite>().spriteName = "Btn_TapRight_00";
            friendWindow.transform.FindChild("TapSprits/MailTab").GetComponent<UISprite>().spriteName = "Btn_TapRight_01";
        }
        else
        {
            friendWindow.transform.FindChild("TapSprits/RankTab").GetComponent<UISprite>().spriteName = "Btn_TapRight_00";
            friendWindow.transform.FindChild("TapSprits/MailTab").GetComponent<UISprite>().spriteName = "Btn_TapRight_01";

            friendWeekTab.GetComponent<UIPanel>().alpha = 1;
            friendWeekTab.SetActive(true);

            friendMailTab.GetComponent<UIPanel>().alpha = 0;
            friendMailTab.SetActive(false);

            if (equipWindows.transform.localPosition.x == 40)
            {
                equipToStoreOn = true;
                equipWindows.animation.Play("StoreWindowAnim03");
                equipWindows.transform.FindChild("Base/BackBtn").gameObject.SetActive(false);
            }
            else if (skinSelectWindow00.transform.localPosition.x == 40)
            {
                skin00ToStoreOn = true;
                skinSelectWindow00.animation.Play("SkinSelectWindowAnim03");
                skinSelectWindow00.transform.FindChild("BackBtn").gameObject.SetActive(false);
            }
            else if (skinSelectWindow01.transform.localPosition.x == 40)
            {
                skin01ToStoreOn = true;
                skinSelectWindow01.animation.Play("SkinSelectWindowAnim03");
                skinSelectWindow01.transform.FindChild("BackBtn").gameObject.SetActive(false);
            }
            else if (skinSelectWindow02.transform.localPosition.x == 40)
            {
                skin02ToStoreOn = true;
                skinSelectWindow02.animation.Play("SkinSelectWindowAnim03");
                skinSelectWindow02.transform.FindChild("BackBtn").gameObject.SetActive(false);
            }
            else if (storeWindow.transform.localPosition.x == 40)
            {
                storeToFriendOn = true;
                storeWindow.animation.Play("StoreWindowAnim03");
                storeWindow.transform.FindChild("Base/BackBtn").gameObject.SetActive(false);
            }
            else if (flights.transform.localPosition.x == 0)
            {
                mainToFriendOn = true;
                flights.animation.Play("FlightsPanelAnim02");
            }
            bgTop.animation.Play("BGMainTopAnim02");
            yield return new WaitForSeconds(0.4f);
            friendWindow.animation.Play("FriendWindowAnim01");
            yield return new WaitForSeconds(0.5f);
            friendWindow.transform.FindChild("BackBtn").gameObject.SetActive(true);
        }
    }

    IEnumerator EscapeFriendWindow()
    {
        prepareReady.transform.FindChild("AllMessageBtn").gameObject.SetActive(false);
        friendWindow.SetActive(true);

        friendWindow.transform.FindChild("RankGrid").GetComponent<RankViewControl>().IsAbleF();
        friendWindow.transform.FindChild("MessageGrid").GetComponent<RankViewControl>().IsAbleF(true);
        bgTop.animation.Play("BGMainTopAnim01");

        if (equipToStoreOn)
        {
            Debug.Log("equipToStoreOn");
            equipWindows.animation.Play("StoreWindowAnim01");
            equipToStoreOn = false;

            friendWindow.transform.FindChild("BackBtn").gameObject.SetActive(false);
            friendWindow.animation.Play("FriendWindowAnim02");

            yield return new WaitForSeconds(0.5f);
            equipWindows.transform.FindChild("Base/BackBtn").gameObject.SetActive(true);
        }
        else if (skin00ToStoreOn)
        {
            Debug.Log("skin00ToStoreOn");
            skinSelectWindow00.animation.Play("SkinSelectWindowAnim01");
            skin00ToStoreOn = false;

            friendWindow.transform.FindChild("BackBtn").gameObject.SetActive(false);
            friendWindow.animation.Play("FriendWindowAnim03");

            yield return new WaitForSeconds(0.5f);
            skinSelectWindow00.transform.FindChild("BackBtn").gameObject.SetActive(true);
        }
        else if (skin01ToStoreOn)
        {
            Debug.Log("skin01ToStoreOn");
            skinSelectWindow01.animation.Play("SkinSelectWindowAnim01");
            skin01ToStoreOn = false;

            friendWindow.transform.FindChild("BackBtn").gameObject.SetActive(false);
            friendWindow.animation.Play("FriendWindowAnim03");

            yield return new WaitForSeconds(0.5f);
            skinSelectWindow01.transform.FindChild("BackBtn").gameObject.SetActive(true);
        }
        else if (skin02ToStoreOn)
        {
            Debug.Log("skin02ToStoreOn");
            skinSelectWindow02.animation.Play("SkinSelectWindowAnim01");
            skin02ToStoreOn = false;

            friendWindow.transform.FindChild("BackBtn").gameObject.SetActive(false);
            friendWindow.animation.Play("FriendWindowAnim03");

            yield return new WaitForSeconds(0.5f);
            skinSelectWindow02.transform.FindChild("BackBtn").gameObject.SetActive(true);
        }
        else if (storeToFriendOn)
        {
            Debug.Log("storeToFriendOn");
            storeWindow.animation.Play("StoreWindowAnim01");
            storeToFriendOn = false;

            friendWindow.transform.FindChild("BackBtn").gameObject.SetActive(false);
            friendWindow.animation.Play("FriendWindowAnim03");

            yield return new WaitForSeconds(0.5f);
            storeWindow.transform.FindChild("Base/BackBtn").gameObject.SetActive(true);
        }
        else if (mainToFriendOn)
        {
            Debug.Log("mainToFriendOn");
            mainToFriendOn = false;
            flights.animation.Play("FlightsPanelAnim01");
            friendWindow.transform.FindChild("BackBtn").gameObject.SetActive(false);
            friendWindow.animation.Play("FriendWindowAnim02");
            flightUpointSetScript.CalRemainPoint();
            flightUpointSetScript.IsBtnAnimationFirst();
            flightUpointSetScript.RemainPointLabel();
        }
        else
        {
            Debug.Log("Null");
            flights.animation.Play("FlightsPanelAnim01");
            friendWindow.transform.FindChild("BackBtn").gameObject.SetActive(false);
            friendWindow.animation.Play("FriendWindowAnim02");
        }

        //하단 버튼과 정보창에 대한 애니메이션을 해준다.
        if (prepareReady.transform.FindChild("FriendPointBtn").localPosition.x != 0)
        {
            Debug.Log("No 0");
            prepareReady.animation.Play("PrepareReadyAnim03_4");
        }
        else
        {
            Debug.Log("Yes 0");
            prepareReady.animation.Play("PrepareReadyAnim03_3");
        }



        yield return new WaitForSeconds(0.2f);

        if (ValueDeliverScript.isResultToHanger)
        {
            Debug.Log("isResultToHanger");

            if (resultSkinNumber != 0 && int.Parse(ValueDeliverScript.gameData[resultSkinName].ToString()) <= 0)
            {
                //스킨 내구도가 0이하로 떨어지면 이 부분을 실행!
                //스킨 내구도 복구 유도 창을 띄운다.
                duraBuyAlarmWindow.SetActive(true);
                halfBLKPanel.SetActive(true);
                halfBLKPanel.transform.localPosition = new Vector3(halfBLKPanel.transform.localPosition.x, halfBLKPanel.transform.localPosition.y, duraBuyAlarmWindow.transform.localPosition.z + 5);
            }

            ValueDeliverScript.isResultToHanger = false;
        }
    }

    //장비구매창.
    public IEnumerator GotoEquipWindows()  //최초 이큅 윈도우를 열때 작동하는 함수.
    {
        GetComponent<FlightSelectBtnScript>().EquipOffBtn();

        #region 어떤 창이 현재 활성화 되어있는지 확인하여 그 확인된 창을 감추는 애니메이션을 실행
        if (storeWindow.transform.localPosition.x == 40)    //스토어(연료,돈,메달)
        {
            storeWindow.transform.FindChild("Base/BackBtn").gameObject.SetActive(false);
            storeWindow.animation.Play("StoreWindowAnim03");
        }
        else if (skinSelectWindow00.transform.localPosition.x == 40)    //포커스킨.
        {
            skinSelectWindow00.transform.FindChild("BackBtn").gameObject.SetActive(false);
            skinSelectWindow00.animation.Play("SkinSelectWindowAnim03");
            SkinWindowClose();
        }
        else if (skinSelectWindow01.transform.localPosition.x == 40)    //코만치스킨.
        {
            skinSelectWindow01.transform.FindChild("BackBtn").gameObject.SetActive(false);
            skinSelectWindow01.animation.Play("SkinSelectWindowAnim03");
            SkinWindowClose();
        }

        else if (skinSelectWindow02.transform.localPosition.x == 40)    //팬텀스킨.
        {
            skinSelectWindow02.transform.FindChild("BackBtn").gameObject.SetActive(false);
            skinSelectWindow02.animation.Play("SkinSelectWindowAnim03");
            SkinWindowClose();
        }

        else if (friendWindow.transform.localPosition.x == 40)   //친구목록(랭킹).
        {
            friendWindow.transform.FindChild("BackBtn").gameObject.SetActive(false);
            friendWindow.animation.Play("FriendWindowAnim03");
            bgTop.animation.Play("BGMainTopAnim01");
            if (int.Parse(ValueDeliverScript.gameData["friendshipPoint"].ToString()) < 100)
            {
                prepareReady.animation.Play("PrepareReadyAnim02_2");
            }
            else
            {
                prepareReady.animation.Play("PrepareReadyAnim02_1");
            }
        }
        else
        {
            flights.animation.Play("FlightsPanelAnim02");   //비행기 선택.
        }
        #endregion

        #region 최초 이큅창이 열릴때의 세팅을 함.

        #region 이큅창에서 처음 나오는 탭의 맨 좌측 아이템을 셀렉트 해서 하단 메세지 부분에 아이템의 이름과 성격 가격등을 보여준다.
        ItemKeyValueScript firstItem = equipBombTab.transform.FindChild("Item/ItemBox01").GetComponent<ItemKeyValueScript>();

        equipItemName.GetComponent<UILabel>().text = firstItem.itemName;
        equipItemPrice.GetComponent<UILabel>().text = firstItem.itemCoinCost.ToString();
        equipItemScript.GetComponent<UILabel>().text = firstItem.itemScript;
        #endregion

        #region 셀렉트 표시를 창을 열었을때는 항상 최좌측에 위치하도록 함.
        equipBombTab.transform.FindChild("Item/HilightItem").localPosition = new Vector3(-326, 68, 6);
        #endregion

        #region 내부적으로 최초 창(탭)을 열었을때는 최좌측 아이템이 내부적으로도 선택되어 있는 것으로 기록하도록 함.
        ValueDeliverScript.SelectedItem = equipBombTab.transform.FindChild("Item/ItemBox01").gameObject;
        ValueDeliverScript.purchaseCharge = equipBombTab.transform.FindChild("Item/ItemBox01").GetComponent<ItemKeyValueScript>().itemCoinCost;
        ValueDeliverScript.SelectedItemSprite = equipBombTab.transform.FindChild("Item/ItemBox01/Item").GetComponent<UISprite>().spriteName;
        mountIconTemp = equipBombTab.transform.FindChild("Item/MountItem").gameObject;
        #endregion

        #endregion

        GoToEquipBombTab();

        //이큅윈도우가 보이는 애니메이션을 실행.
        equipWindows.animation.Play("StoreWindowAnim01");

        if (friendWindow.transform.localPosition.x != 40)
            //하단 바의 준비 아이콘들이 들어가는 애니메이션을 실행.
            prepareReady.animation.Play("PrepareReadyAnim02");

        //0.5초 쉼.
        yield return new WaitForSeconds(0.5f);
        //이큅창을 사라지게 하고 이전 창으로 돌릴수 있는 백버튼을 보이게함.
        equipWindows.transform.FindChild("Base/BackBtn").gameObject.SetActive(true);
        //0.5초 쉼.
        yield return new WaitForSeconds(0.5f);
        //하단 바의 출격 아이콘들이 나오는 애니메이션을 실행.
        attackReady.animation.Play("AttackReadyAnim01");
    }

    IEnumerator GotoEquipWindows2()
    {

        if (ValueDeliverScript.isBgSound == true) //소리가 켜져있을경우 결과창 BGM에서 격납고 BGM으로 변경.
        {
            AudioSource resultSound = GameObject.Find("ResultSoundManager").GetComponent<AudioSource>();
            AudioSource bgSound = GameObject.Find("BgSoundManager").GetComponent<AudioSource>();
            resultSound.volume = 1f;
            bgSound.volume = 0f;
            bgSound.Play();

            while (resultSound.volume > 0)
            {
                resultSound.volume -= Time.deltaTime * 4;
                bgSound.volume += Time.deltaTime * 4;
                yield return null;
            }

        }

        if (storeWindow.transform.localPosition.x == 40)
        {
            storeWindow.animation.Play("StoreWindowAnim02");
        }
        else
        {
            ResultPanel.transform.FindChild("ResultPanelLeft").animation.Play("ResultPanelLeftAnim03");
            ResultPanel.transform.FindChild("ResultPanelRight").animation.Play("ResultPanelRightAnim02");
        }
        ResultPanel.transform.FindChild("ResultLowTab").animation.Play("ResultLowTabAnim02");


        yield return new WaitForSeconds(1f);
        ////////////////////////////////////////
        ////////////////////////////////////////

        #region 최초 이큅창이 열릴때의 세팅을 함.

        #region 이큅창에서 처음 나오는 탭의 맨 좌측 아이템을 셀렉트 해서 하단 메세지 부분에 아이템의 이름과 성격 가격등을 보여준다.
        ItemKeyValueScript firstItem = equipBombTab.transform.FindChild("Item/ItemBox01").GetComponent<ItemKeyValueScript>();

        equipItemName.GetComponent<UILabel>().text = firstItem.itemName;
        equipItemPrice.GetComponent<UILabel>().text = firstItem.itemCoinCost.ToString();
        equipItemScript.GetComponent<UILabel>().text = firstItem.itemScript;
        #endregion

        #region 셀렉트 표시를 창을 열었을때는 항상 최좌측에 위치하도록 함.
        equipBombTab.transform.FindChild("Item/HilightItem").localPosition = new Vector3(-326, 68, 6);
        #endregion

        #region 내부적으로 최초 창(탭)을 열었을때는 최좌측 아이템이 내부적으로도 선택되어 있는 것으로 기록하도록 함.
        ValueDeliverScript.SelectedItem = equipBombTab.transform.FindChild("Item/ItemBox01").gameObject;
        ValueDeliverScript.purchaseCharge = equipBombTab.transform.FindChild("Item/ItemBox01").GetComponent<ItemKeyValueScript>().itemCoinCost;
        ValueDeliverScript.SelectedItemSprite = equipBombTab.transform.FindChild("Item/ItemBox01/Item").GetComponent<UISprite>().spriteName;
        mountIconTemp = equipBombTab.transform.FindChild("Item/MountItem").gameObject;
        #endregion

        #endregion

        //위큅윈도우가 보이는 애니메이션을 실행.
        equipWindows.animation.Play("StoreWindowAnim01");
        //하단 바의 준비 아이콘들이 들어가는 애니메이션을 실행.
        //prepareReady.animation.Play("PrepareReadyAnim02");
        //0.5초 쉼.
        //yield return new WaitForSeconds(0.5f);
        //이큅창을 사라지게 하고 이전 창으로 돌릴수 있는 백버튼을 보이게함.
        equipWindows.transform.FindChild("Base/BackBtn").gameObject.SetActive(true);
        //0.5초 쉼.
        yield return new WaitForSeconds(0.5f);
        //하단 바의 출격 아이콘들이 나오는 애니메이션을 실행.
        attackReady.animation.Play("AttackReadyAnim01");


    }

    IEnumerator ShowAttackButton()
    {


        StartCoroutine(PrepareReady());
        yield return new WaitForSeconds(0.25f);
        yield return StartCoroutine(AttackReady());

        if (skinSelectWindow00.transform.parent.name == "WinMove")
        {
            skinSelectWindow00.transform.parent = windows.transform;
            skinSelectWindow00.transform.localPosition = new Vector3(1540, 0, 0);
        }
        if (skinSelectWindow01.transform.parent.name == "WinMove")
        {
            skinSelectWindow01.transform.parent = windows.transform;
            skinSelectWindow01.transform.localPosition = new Vector3(1540, 0, 0);
        }
        if (skinSelectWindow02.transform.parent.name == "WinMove")
        {
            skinSelectWindow02.transform.parent = windows.transform;
            skinSelectWindow02.transform.localPosition = new Vector3(1540, 0, 0);
        }
    }

    IEnumerator WindowsMove()
    {
        Vector3 firstPosition = winMove.transform.localPosition;
        Vector3 secondPosition = firstPosition + new Vector3(-1500, 0, 0);
        float lValue = 0;

        while (lValue <= 1)
        {
            winMove.transform.localPosition = Vector3.Lerp(firstPosition, secondPosition, lValue);
            lValue += Time.deltaTime * 2f;
            yield return null;
        }
        winMove.transform.localPosition = secondPosition;
    }

    IEnumerator WindowsMoveReverse(GameObject subWin)
    {
        Vector3 firstPosition = winMove.transform.localPosition;
        Vector3 secondPosition = firstPosition + new Vector3(1500, 0, 0);
        float lValue = 0;

        while (lValue <= 1)
        {
            winMove.transform.localPosition = Vector3.Lerp(firstPosition, secondPosition, lValue);
            lValue += Time.deltaTime * 2f;
            yield return null;
        }
        winMove.transform.localPosition = secondPosition;

        //Debug.Log(subWin.name);
        //Debug.Log(subWin.transform.parent);
        subWin.transform.parent = windows.transform;
        subWin.transform.localPosition = new Vector3(1540, 0, 0);
        //Debug.Log(subWin.transform.parent);
    }



    IEnumerator PrepareReady()
    {
        Vector3 attackOldPosition = prepareReady.transform.localPosition;

        float lValue = 0;
        while (lValue <= 1)
        {
            prepareReady.transform.localPosition = Vector3.Lerp(attackOldPosition, new Vector3(-1100, 0, 0), lValue);

            lValue += Time.deltaTime * 4;
            yield return null;
        }
        prepareReady.transform.localPosition = new Vector3(-1100, 0, 0);
    }

    IEnumerator AttackReady()
    {
        GameObject attackReady = GameObject.Find("AttackReady");
        Vector3 prepareOldPosition = attackReady.transform.localPosition;
        yield return null;
        float lValue = 0;
        while (lValue <= 1)
        {
            attackReady.transform.localPosition = Vector3.Lerp(prepareOldPosition, new Vector3(0, 0, 0), lValue);

            lValue += Time.deltaTime * 4;
            yield return null;
        }
        attackReady.transform.localPosition = new Vector3(0, 0, 0);
    }


    IEnumerator PrepareReadyReverse()
    {
        Vector3 attackOldPosition = prepareReady.transform.localPosition;

        float lValue = 0;
        while (lValue <= 1)
        {
            prepareReady.transform.localPosition = Vector3.Lerp(attackOldPosition, new Vector3(0, 0, 0), lValue);

            lValue += Time.deltaTime * 4;
            yield return null;
        }
        prepareReady.transform.localPosition = new Vector3(0, 0, 0);
    }

    IEnumerator AttackReadyReverse()
    {
        GameObject attackReady = GameObject.Find("AttackReady");
        Vector3 prepareOldPosition = attackReady.transform.localPosition;
        yield return null;
        float lValue = 0;
        while (lValue <= 1)
        {
            attackReady.transform.localPosition = Vector3.Lerp(prepareOldPosition, new Vector3(-1100, 0, 0), lValue);

            lValue += Time.deltaTime * 4;
            yield return null;
        }
        attackReady.transform.localPosition = new Vector3(-1100, 0, 0);
    }

    public GameObject purchaseBtn;
    public GameObject purchaseBtnlabel;

    public void GoToEquipBombTab()
    {
        GameObject.Find("EquipWindows").transform.FindChild("Base/CoinAbleLabel").GetComponent<UILabel>().text = "";

        purchaseBtn.SetActive(true);
        purchaseBtnlabel.SetActive(true);

        StartCoroutine(TransChange(equipBombTab, 1));
        StartCoroutine(TransChange(equipReinforceTab, 0));
        StartCoroutine(TransChange(equipAssistanceTab, 0));
        StartCoroutine(TransChange(equipOperTab, 0));

        equipWindows.transform.FindChild("Base/TabBomb").GetComponent<UISprite>().spriteName = "bt_blue_t_top_n";
        equipWindows.transform.FindChild("Base/TabReinforce").GetComponent<UISprite>().spriteName = "bt_blue_t_top_o";
        equipWindows.transform.FindChild("Base/TabAssistance").GetComponent<UISprite>().spriteName = "bt_blue_t_top_o";
        equipWindows.transform.FindChild("Base/TabOper").GetComponent<UISprite>().spriteName = "bt_blue_t_top_o";

        equipWindows.transform.FindChild("Base/TabBomb").GetComponent<UISprite>().MakePixelPerfect();
        equipWindows.transform.FindChild("Base/TabReinforce").GetComponent<UISprite>().MakePixelPerfect();
        equipWindows.transform.FindChild("Base/TabAssistance").GetComponent<UISprite>().MakePixelPerfect();
        equipWindows.transform.FindChild("Base/TabOper").GetComponent<UISprite>().MakePixelPerfect();

        ValueDeliverScript.SelectedItem = null;

        GetComponent<FlightSelectBtnScript>().EquipOffBtn();

        ItemKeyValueScript firstItem = equipBombTab.transform.FindChild("Item/ItemBox01").GetComponent<ItemKeyValueScript>();

        equipWindows.transform.FindChild("Base/GoldIcon").gameObject.SetActive(true);
        equipWindows.transform.FindChild("Base/GoldIcon").GetComponent<UISprite>().spriteName = "icon_small_gold";
        equipItemName.GetComponent<UILabel>().text = firstItem.itemName;
        equipItemPrice.GetComponent<UILabel>().text = firstItem.itemCoinCost.ToString();
        equipItemScript.GetComponent<UILabel>().text = firstItem.itemScript;

        equipBombTab.transform.FindChild("Item/HilightItem").localPosition = new Vector3(-326, 68, 6);

        ValueDeliverScript.SelectedItem = equipBombTab.transform.FindChild("Item/ItemBox01").gameObject;
        ValueDeliverScript.purchaseCharge = equipBombTab.transform.FindChild("Item/ItemBox01").GetComponent<ItemKeyValueScript>().itemCoinCost;
        ValueDeliverScript.SelectedItemSprite = equipBombTab.transform.FindChild("Item/ItemBox01/Item").GetComponent<UISprite>().spriteName;
        mountIconTemp = equipBombTab.transform.FindChild("Item/MountItem").gameObject;
    }

    public void GoToEquipReinforceTab()
    {
        GameObject.Find("EquipWindows").transform.FindChild("Base/CoinAbleLabel").GetComponent<UILabel>().text = "";

        purchaseBtn.SetActive(true);
        purchaseBtnlabel.SetActive(true);

        StartCoroutine(TransChange(equipBombTab, 0));
        StartCoroutine(TransChange(equipReinforceTab, 1));
        StartCoroutine(TransChange(equipAssistanceTab, 0));
        StartCoroutine(TransChange(equipOperTab, 0));

        equipWindows.transform.FindChild("Base/TabBomb").GetComponent<UISprite>().spriteName = "bt_blue_t_top_o";
        equipWindows.transform.FindChild("Base/TabReinforce").GetComponent<UISprite>().spriteName = "bt_blue_t_top_n";
        equipWindows.transform.FindChild("Base/TabAssistance").GetComponent<UISprite>().spriteName = "bt_blue_t_top_o";
        equipWindows.transform.FindChild("Base/TabOper").GetComponent<UISprite>().spriteName = "bt_blue_t_top_o";

        equipWindows.transform.FindChild("Base/TabBomb").GetComponent<UISprite>().MakePixelPerfect();
        equipWindows.transform.FindChild("Base/TabReinforce").GetComponent<UISprite>().MakePixelPerfect();
        equipWindows.transform.FindChild("Base/TabAssistance").GetComponent<UISprite>().MakePixelPerfect();
        equipWindows.transform.FindChild("Base/TabOper").GetComponent<UISprite>().MakePixelPerfect();

        ValueDeliverScript.SelectedItem = null;

        Transform item = equipWindows.transform.FindChild("EquipReinforceTab/Item");
        item.localPosition = new Vector3(0, item.localPosition.y, item.localPosition.z);
        GetComponent<FlightSelectBtnScript>().EquipOffLeftBtn();

        ItemKeyValueScript firstItem = equipReinforceTab.transform.FindChild("Item/ItemBox01").GetComponent<ItemKeyValueScript>();

        equipWindows.transform.FindChild("Base/GoldIcon").gameObject.SetActive(true);
        equipWindows.transform.FindChild("Base/GoldIcon").GetComponent<UISprite>().spriteName = "icon_small_gold";
        equipItemName.GetComponent<UILabel>().text = firstItem.itemName;
        equipItemPrice.GetComponent<UILabel>().text = firstItem.itemCoinCost.ToString();
        equipItemScript.GetComponent<UILabel>().text = firstItem.itemScript;

        equipReinforceTab.transform.FindChild("Item/HilightItem").localPosition = new Vector3(-326, 68, 6);

        ValueDeliverScript.SelectedItem = equipReinforceTab.transform.FindChild("Item/ItemBox01").gameObject;
        ValueDeliverScript.purchaseCharge = equipReinforceTab.transform.FindChild("Item/ItemBox01").GetComponent<ItemKeyValueScript>().itemCoinCost;
        ValueDeliverScript.SelectedItemSprite = equipReinforceTab.transform.FindChild("Item/ItemBox01/Item").GetComponent<UISprite>().spriteName;
        mountIconTemp = equipReinforceTab.transform.FindChild("Item/MountItem").gameObject;
    }

    public void GoToEquipAssistanceTab()
    {
        GameObject.Find("EquipWindows").transform.FindChild("Base/CoinAbleLabel").GetComponent<UILabel>().text = "";

        purchaseBtn.SetActive(true);
        purchaseBtnlabel.SetActive(true);

        StartCoroutine(TransChange(equipBombTab, 0));
        StartCoroutine(TransChange(equipReinforceTab, 0));
        StartCoroutine(TransChange(equipAssistanceTab, 1));
        StartCoroutine(TransChange(equipOperTab, 0));

        equipWindows.transform.FindChild("Base/TabBomb").GetComponent<UISprite>().spriteName = "bt_blue_t_top_o";
        equipWindows.transform.FindChild("Base/TabReinforce").GetComponent<UISprite>().spriteName = "bt_blue_t_top_o";
        equipWindows.transform.FindChild("Base/TabAssistance").GetComponent<UISprite>().spriteName = "bt_blue_t_top_n";
        equipWindows.transform.FindChild("Base/TabOper").GetComponent<UISprite>().spriteName = "bt_blue_t_top_o";

        equipWindows.transform.FindChild("Base/TabBomb").GetComponent<UISprite>().MakePixelPerfect();
        equipWindows.transform.FindChild("Base/TabReinforce").GetComponent<UISprite>().MakePixelPerfect();
        equipWindows.transform.FindChild("Base/TabAssistance").GetComponent<UISprite>().MakePixelPerfect();
        equipWindows.transform.FindChild("Base/TabOper").GetComponent<UISprite>().MakePixelPerfect();

        ValueDeliverScript.SelectedItem = null;
        GetComponent<FlightSelectBtnScript>().EquipOffBtn();

        ItemKeyValueScript firstItem = equipAssistanceTab.transform.FindChild("Item/ItemBox01").GetComponent<ItemKeyValueScript>();

        equipWindows.transform.FindChild("Base/GoldIcon").gameObject.SetActive(true);
        equipWindows.transform.FindChild("Base/GoldIcon").GetComponent<UISprite>().spriteName = "icon_small_gold";
        equipItemName.GetComponent<UILabel>().text = firstItem.itemName;
        equipItemPrice.GetComponent<UILabel>().text = firstItem.itemCoinCost.ToString();
        equipItemScript.GetComponent<UILabel>().text = firstItem.itemScript;

        equipAssistanceTab.transform.FindChild("Item/HilightItem").localPosition = new Vector3(-326, 68, 6);

        ValueDeliverScript.SelectedItem = equipAssistanceTab.transform.FindChild("Item/ItemBox01").gameObject;
        ValueDeliverScript.purchaseCharge = equipAssistanceTab.transform.FindChild("Item/ItemBox01").GetComponent<ItemKeyValueScript>().itemCoinCost;
        ValueDeliverScript.SelectedItemSprite = equipAssistanceTab.transform.FindChild("Item/ItemBox01/Item").GetComponent<UISprite>().spriteName;
        mountIconTemp = equipAssistanceTab.transform.FindChild("Item/MountItem").gameObject;
    }

    public void GoToEquipOperTab()
    {
        //코인구매가능 글씨 감춤.
        GameObject.Find("EquipWindows").transform.FindChild("Base/CoinAbleLabel").GetComponent<UILabel>().text = "";

        purchaseBtn.SetActive(false);
        purchaseBtnlabel.SetActive(false);

        StartCoroutine(TransChange(equipBombTab, 0));
        StartCoroutine(TransChange(equipReinforceTab, 0));
        StartCoroutine(TransChange(equipAssistanceTab, 0));
        StartCoroutine(TransChange(equipOperTab, 1));

        equipWindows.transform.FindChild("Base/TabBomb").GetComponent<UISprite>().spriteName = "bt_blue_t_top_o";
        equipWindows.transform.FindChild("Base/TabReinforce").GetComponent<UISprite>().spriteName = "bt_blue_t_top_o";
        equipWindows.transform.FindChild("Base/TabAssistance").GetComponent<UISprite>().spriteName = "bt_blue_t_top_o";
        equipWindows.transform.FindChild("Base/TabOper").GetComponent<UISprite>().spriteName = "bt_blue_t_top_n";

        equipWindows.transform.FindChild("Base/TabBomb").GetComponent<UISprite>().MakePixelPerfect();
        equipWindows.transform.FindChild("Base/TabReinforce").GetComponent<UISprite>().MakePixelPerfect();
        equipWindows.transform.FindChild("Base/TabAssistance").GetComponent<UISprite>().MakePixelPerfect();
        equipWindows.transform.FindChild("Base/TabOper").GetComponent<UISprite>().MakePixelPerfect();

        ValueDeliverScript.SelectedItem = null;
        GetComponent<FlightSelectBtnScript>().EquipOffBtn();

        ItemKeyValueScript firstItem = equipOperTab.transform.FindChild("Item/ItemBox01").GetComponent<ItemKeyValueScript>();

        equipItemName.GetComponent<UILabel>().text = firstItem.itemName;
        equipItemPrice.GetComponent<UILabel>().text = "";
        equipItemScript.GetComponent<UILabel>().text = firstItem.itemScript;
        equipOperTab.transform.FindChild("Item/HilightItem").localPosition = new Vector3(-326, 68, 6);

        equipWindows.transform.FindChild("Base/GoldIcon").gameObject.SetActive(false);

        ValueDeliverScript.SelectedItem = equipOperTab.transform.FindChild("Item/ItemBox01").gameObject;
        ValueDeliverScript.purchaseCharge = equipOperTab.transform.FindChild("Item/ItemBox01").GetComponent<ItemKeyValueScript>().itemCoinCost;
        ValueDeliverScript.SelectedItemSprite = equipOperTab.transform.FindChild("Item/ItemBox01/Item").GetComponent<UISprite>().spriteName;
        mountIconTemp = equipOperTab.transform.FindChild("Item/MountItem").gameObject;

        string itemNumName = "Item/ItemBox" + int.Parse(ValueDeliverScript.gameData["activeOper"].ToString()).ToString("00");
        mountIconTemp.transform.localPosition = equipOperTab.transform.FindChild(itemNumName).localPosition + new Vector3(-1, 3, -1);
    }

    public void GoToFriendWeekTab()
    {
        prepareReady.transform.FindChild("FriendPointBtn").gameObject.SetActive(true);
        prepareReady.transform.FindChild("AllMessageBtn").gameObject.SetActive(false);
        StartCoroutine(TransChange(friendWeekTab, 1));
        StartCoroutine(TransChange(friendMailTab, 0));

        friendWindow.transform.FindChild("TapSprits/RankTab").GetComponent<UISprite>().spriteName = "Btn_TapRight_00";
        friendWindow.transform.FindChild("TapSprits/MailTab").GetComponent<UISprite>().spriteName = "Btn_TapRight_01";

        friendWindow.transform.FindChild("TapSprits/RankTab").GetComponent<UISprite>().MakePixelPerfect();
        friendWindow.transform.FindChild("TapSprits/MailTab").GetComponent<UISprite>().MakePixelPerfect();

        friendWindow.transform.FindChild("RankGrid").GetComponent<RankViewControl>().IsAbleT();
        friendWindow.transform.FindChild("MessageGrid").GetComponent<RankViewControl>().IsAbleF(true);

        friendWindow.transform.FindChild("Script01").GetComponent<UILabel>().text = "친구를 터치하면 사용한 기체 세팅을 볼 수 있습니다.";
        friendWindow.transform.FindChild("Script02").GetComponent<UILabel>().text = "연료를 발송하면 우정포인트를 획득할 수 있습니다.";
    }

    public void GoToFriendInviteTab()
    {
        prepareReady.transform.FindChild("FriendPointBtn").gameObject.SetActive(true);
        prepareReady.transform.FindChild("AllMessageBtn").gameObject.SetActive(false);

        StartCoroutine(TransChange(friendWeekTab, 0));
        StartCoroutine(TransChange(friendMailTab, 0));

        friendWindow.transform.FindChild("TapSprits/RankTab").GetComponent<UISprite>().spriteName = "Btn_TapRight_01";
        friendWindow.transform.FindChild("TapSprits/MailTab").GetComponent<UISprite>().spriteName = "Btn_TapRight_01";

        friendWindow.transform.FindChild("TapSprits/RankTab").GetComponent<UISprite>().MakePixelPerfect();
        friendWindow.transform.FindChild("TapSprits/MailTab").GetComponent<UISprite>().MakePixelPerfect();

        friendWindow.transform.FindChild("RankGrid").GetComponent<RankViewControl>().IsAbleF();
        friendWindow.transform.FindChild("MessageGrid").GetComponent<RankViewControl>().IsAbleF(true);

        FriendInviteTabTextRefresh();
    }

    public void FriendInviteTabTextRefresh()
    {
        int remainHour = 23 - System.DateTime.Now.Hour;
        int remainMinute = 60 - System.DateTime.Now.Minute;

        string script = "今天可另外再邀请N" + (30 - int.Parse(ValueDeliverScript.gameData["FriendRequestCount"].ToString())) + "名。(";
        if (int.Parse(ValueDeliverScript.gameData["FriendRequestCount"].ToString()) >= 30)
        {
            script = "已超出今日邀请限量。";
        }

        friendWindow.transform.FindChild("Script01").GetComponent<UILabel>().text = script + remainHour + "小时 " + remainMinute + "后初始化)";
        friendWindow.transform.FindChild("Script02").GetComponent<UILabel>().text = "邀请好友时，可获得友情积分和燃料。";
    }


    public void GoToFriendMailTab()
    {
        prepareReady.transform.FindChild("FriendPointBtn").gameObject.SetActive(false);
        StartCoroutine(IeGoToFriendMailTab());  //서버에서 데이터를 먼저 받아와야 되는 것이 있기에 코루틴으로 변경.

        friendWindow.transform.FindChild("Script01").GetComponent<UILabel>().text = "수신함에는 최대 50개까지 보관할 수 있습니다.";
        friendWindow.transform.FindChild("Script02").GetComponent<UILabel>().text = "";
    }

    IEnumerator IeGoToFriendMailTab()   //바로 위 GoToFriendMailTab 메소드의 실 작동부. 
    {
        GameObject serverLoadingPanel = GameObject.Find("Windows").transform.FindChild("ServerLoadingPanel").gameObject;

        serverLoadingPanel.SetActive(true);

        //기존 메세지탭들을 우선 삭제//
        Transform messageGrid = friendWindow.transform.FindChild("MessageGrid");

        int messageCount = messageGrid.childCount;
        GameObject[] MessageTab;

        MessageTab = new GameObject[messageCount];

        for (int i = 0; i < messageCount; i++)
        {
            MessageTab[i] = messageGrid.GetChild(i).gameObject;
        }

        for (int j = 0; j < messageCount; j++)
        {
            Destroy(MessageTab[j]);
        }
        //기존 메세지탭들을 우선 삭제//

        yield return null;
        StartCoroutine(TransChange(friendWeekTab, 0));
        StartCoroutine(TransChange(friendMailTab, 1));

        friendWindow.transform.FindChild("TapSprits/RankTab").GetComponent<UISprite>().spriteName = "Btn_TapRight_01";
        friendWindow.transform.FindChild("TapSprits/MailTab").GetComponent<UISprite>().spriteName = "Btn_TapRight_00";

        friendWindow.transform.FindChild("TapSprits/RankTab").GetComponent<UISprite>().MakePixelPerfect();
        friendWindow.transform.FindChild("TapSprits/MailTab").GetComponent<UISprite>().MakePixelPerfect();

        friendWindow.transform.FindChild("RankGrid").GetComponent<RankViewControl>().IsAbleF();
        friendWindow.transform.FindChild("MessageGrid").GetComponent<RankViewControl>().IsAbleT();

        prepareReady.transform.FindChild("AllMessageBtn").gameObject.SetActive(true);

        serverLoadingPanel.SetActive(false);
    }

    public void GoToEventTab()
    {
        prepareReady.transform.FindChild("AllMessageBtn").gameObject.SetActive(false);

        friendWeekTab.GetComponent<UIPanel>().alpha = 0;
        friendWeekTab.SetActive(false);

        friendMailTab.GetComponent<UIPanel>().alpha = 0;
        friendMailTab.SetActive(false);

        friendWindow.transform.FindChild("TapSprits/RankTab").GetComponent<UISprite>().spriteName = "Btn_TapRight_01";
        friendWindow.transform.FindChild("TapSprits/MailTab").GetComponent<UISprite>().spriteName = "Btn_TapRight_01";

        friendWindow.transform.FindChild("TapSprits/RankTab").GetComponent<UISprite>().MakePixelPerfect();
        friendWindow.transform.FindChild("TapSprits/MailTab").GetComponent<UISprite>().MakePixelPerfect();

        friendWindow.transform.FindChild("RankGrid").GetComponent<RankViewControl>().IsAbleF();
        friendWindow.transform.FindChild("MessageGrid").GetComponent<RankViewControl>().IsAbleF(true);

        FriendInviteTabTextRefresh();
        friendWindow.transform.FindChild("Script01").GetComponent<UILabel>().text = "진행 중인 이벤트 목록";
        friendWindow.transform.FindChild("Script02").GetComponent<UILabel>().text = "초대 이벤트를 진행 중입니다. 친구들을 초대해 보상을 획득하세요.";
    }


    public void EquipWindowClose()
    {
        halfBLKPanel.SetActive(false);
        equipBombTab.SetActive(false);
        equipReinforceTab.SetActive(false);
        equipAssistanceTab.SetActive(false);
        equipOperTab.SetActive(false);
    }

    //비행기스킨 윈도우.


    IEnumerator GoToSkinSelectWindow000()  //0번 비행기 스킨 셀렉트 창을 여는 함수
    {
        int childCount = skinSelectWindow00.transform.FindChild("Skin").childCount;

        for (int skinNum = 1; skinNum < childCount; skinNum++)
        {
            skinSelectWindow00.transform.FindChild("Skin/Skin" + skinNum.ToString("00")).GetComponent<PositionSkinSendScript>().UpdateSkinInfo();
        }

        flights.animation.Play("FlightsPanelAnim02");
        skinSelectWindow00.animation.Play("SkinSelectWindowAnim01");
        yield return new WaitForSeconds(0.5f);
        skinSelectWindow00.transform.FindChild("BackBtn").gameObject.SetActive(true);
        skinSelectWindow00.GetComponent<SkinHilightScript>().Activate();            // 이부분을 이용하면 스킨레벨과 게이지가 얼마나 차 있는지 정의할수 있음.
        //prepareReady.transform.FindChild("OperMessage/SpecialMessage").gameObject.SetActive(false);
        //prepareReady.transform.FindChild("OperMessage/UpgradePointMessage").gameObject.SetActive(false);
        //prepareReady.transform.FindChild("OperMessage/OperMessageLabel").gameObject.SetActive(true);

        if (ValueDeliverScript.skinNumber > 0)
        {
            prepareReady.transform.FindChild("OperMessage/SpecialAttackOn").gameObject.SetActive(false);
        }

        int isFlightLock = 1;
        if (ValueDeliverScript.skinNumber != 0)
            isFlightLock = int.Parse(ValueDeliverScript.gameData["FlightLock000Skin" + ValueDeliverScript.skinNumber.ToString("000")].ToString());

        if (isFlightLock == 1)
        {
            skinSelectWindow00.transform.FindChild("Lock").gameObject.SetActive(false);
        }
        else
        {
            skinSelectWindow00.transform.FindChild("Lock").gameObject.SetActive(true);
        }

        noTouchPanel.SetActive(false);
    }


    IEnumerator GoToSkinSelectWindow001()  //1번 비행기 스킨 셀렉트 창을 여는 함수
    {
        int childCount = skinSelectWindow00.transform.FindChild("Skin").childCount;

        for (int skinNum = 1; skinNum < childCount; skinNum++)
        {
            skinSelectWindow01.transform.FindChild("Skin/Skin" + skinNum.ToString("00")).GetComponent<PositionSkinSendScript>().UpdateSkinInfo();
        }

        flights.animation.Play("FlightsPanelAnim02");
        skinSelectWindow01.animation.Play("SkinSelectWindowAnim01");
        yield return new WaitForSeconds(0.5f);
        skinSelectWindow01.transform.FindChild("BackBtn").gameObject.SetActive(true);
        skinSelectWindow01.GetComponent<SkinHilightScript>().Activate();
        //prepareReady.transform.FindChild("OperMessage/SpecialMessage").gameObject.SetActive(false);
        //prepareReady.transform.FindChild("OperMessage/UpgradePointMessage").gameObject.SetActive(false);
        //prepareReady.transform.FindChild("OperMessage/OperMessageLabel").gameObject.SetActive(true);

        if (ValueDeliverScript.skinNumber > 0)
        {
            prepareReady.transform.FindChild("OperMessage/SpecialAttackOn").gameObject.SetActive(false);
        }

        int isFlightLock = 1;
        if (ValueDeliverScript.skinNumber != 0)
            isFlightLock = int.Parse(ValueDeliverScript.gameData["FlightLock001Skin" + ValueDeliverScript.skinNumber.ToString("000")].ToString());

        if (isFlightLock == 1)
        {
            skinSelectWindow01.transform.FindChild("Lock").gameObject.SetActive(false);
        }
        else
        {
            skinSelectWindow01.transform.FindChild("Lock").gameObject.SetActive(true);
        }

        noTouchPanel.SetActive(false);
    }

    IEnumerator GoToSkinSelectWindow002()  //2번 비행기 스킨 셀렉트 창을 여는 함수
    {
        int childCount = skinSelectWindow00.transform.FindChild("Skin").childCount;

        for (int skinNum = 1; skinNum < childCount; skinNum++)
        {
            skinSelectWindow02.transform.FindChild("Skin/Skin" + skinNum.ToString("00")).GetComponent<PositionSkinSendScript>().UpdateSkinInfo();
        }

        flights.animation.Play("FlightsPanelAnim02");
        skinSelectWindow02.animation.Play("SkinSelectWindowAnim01");
        yield return new WaitForSeconds(0.5f);
        skinSelectWindow02.transform.FindChild("BackBtn").gameObject.SetActive(true);
        skinSelectWindow02.GetComponent<SkinHilightScript>().Activate();
        //prepareReady.transform.FindChild("OperMessage/SpecialMessage").gameObject.SetActive(false);
        //prepareReady.transform.FindChild("OperMessage/UpgradePointMessage").gameObject.SetActive(false);
        //prepareReady.transform.FindChild("OperMessage/OperMessageLabel").gameObject.SetActive(true);

        if (ValueDeliverScript.skinNumber > 0)
        {
            prepareReady.transform.FindChild("OperMessage/SpecialAttackOn").gameObject.SetActive(false);
        }

        int isFlightLock = 1;
        if (ValueDeliverScript.skinNumber != 0)
            isFlightLock = int.Parse(ValueDeliverScript.gameData["FlightLock002Skin" + ValueDeliverScript.skinNumber.ToString("000")].ToString());

        if (isFlightLock == 1)
        {
            skinSelectWindow02.transform.FindChild("Lock").gameObject.SetActive(false);
        }
        else
        {
            skinSelectWindow02.transform.FindChild("Lock").gameObject.SetActive(true);
        }

        noTouchPanel.SetActive(false);
    }

    public void BackToFlight000()
    {
        skinSelectWindow00.transform.FindChild("BackBtn").gameObject.SetActive(false);
        skinSelectWindow00.animation.Play("SkinSelectWindowAnim02");
        flights.animation.Play("FlightsPanelAnim01");
        //prepareReady.transform.FindChild("OperMessage/OperMessageLabel").GetComponent<UILabel>().text = "";
        flightUpointSetScript.RedrawStatePoint();

        if (flightUpointSetScript.remainPoint <= 0)
        {
            if (int.Parse(ValueDeliverScript.gameData["isSpecialAttackOn"].ToString()) == 1)
            {
                prepareReady.transform.FindChild("OperMessage/SpecialAttackOn").gameObject.SetActive(true);
                prepareReady.transform.FindChild("OperMessage/SpecialMessage").gameObject.SetActive(false);
            }
            else
            {
                prepareReady.transform.FindChild("OperMessage/SpecialAttackOn").gameObject.SetActive(false);
                prepareReady.transform.FindChild("OperMessage/SpecialMessage").gameObject.SetActive(true);
            }
        }
    }

    public void BackToFlight001()
    {
        skinSelectWindow01.transform.FindChild("BackBtn").gameObject.SetActive(false);
        skinSelectWindow01.animation.Play("SkinSelectWindowAnim02");
        flights.animation.Play("FlightsPanelAnim01");
        //prepareReady.transform.FindChild("OperMessage/OperMessageLabel").GetComponent<UILabel>().text = "";
        flightUpointSetScript.RedrawStatePoint();

        if (flightUpointSetScript.remainPoint <= 0)
        {
            if (int.Parse(ValueDeliverScript.gameData["isSpecialAttackOn"].ToString()) == 1)
            {
                prepareReady.transform.FindChild("OperMessage/SpecialAttackOn").gameObject.SetActive(true);
                prepareReady.transform.FindChild("OperMessage/SpecialMessage").gameObject.SetActive(false);
            }
            else
            {
                prepareReady.transform.FindChild("OperMessage/SpecialAttackOn").gameObject.SetActive(false);
                prepareReady.transform.FindChild("OperMessage/SpecialMessage").gameObject.SetActive(true);
            }
        }
    }

    public void BackToFlight002()
    {
        skinSelectWindow02.transform.FindChild("BackBtn").gameObject.SetActive(false);
        skinSelectWindow02.animation.Play("SkinSelectWindowAnim02");
        flights.animation.Play("FlightsPanelAnim01");
        //prepareReady.transform.FindChild("OperMessage/OperMessageLabel").GetComponent<UILabel>().text = "";
        flightUpointSetScript.RedrawStatePoint();

        if (flightUpointSetScript.remainPoint <= 0)
        {
            if (int.Parse(ValueDeliverScript.gameData["isSpecialAttackOn"].ToString()) == 1)
            {
                prepareReady.transform.FindChild("OperMessage/SpecialAttackOn").gameObject.SetActive(true);
                prepareReady.transform.FindChild("OperMessage/SpecialMessage").gameObject.SetActive(false);
            }
            else
            {
                prepareReady.transform.FindChild("OperMessage/SpecialAttackOn").gameObject.SetActive(false);
                prepareReady.transform.FindChild("OperMessage/SpecialMessage").gameObject.SetActive(true);
            }
        }
    }

    IEnumerator BackToFlightFromStore()
    {
        if (equipToStoreOn)
        {
            equipWindows.animation.Play("StoreWindowAnim01");
            equipToStoreOn = false;

            storeWindow.transform.FindChild("Base/BackBtn").gameObject.SetActive(false);
            storeWindow.animation.Play("StoreWindowAnim03");

            yield return new WaitForSeconds(0.5f);
            equipWindows.transform.FindChild("Base/BackBtn").gameObject.SetActive(true);
        }

        else if (skin00ToStoreOn)
        {
            skinSelectWindow00.animation.Play("SkinSelectWindowAnim01");
            skin00ToStoreOn = false;

            storeWindow.transform.FindChild("Base/BackBtn").gameObject.SetActive(false);
            storeWindow.animation.Play("StoreWindowAnim03");

            yield return new WaitForSeconds(0.5f);
            skinSelectWindow00.transform.FindChild("BackBtn").gameObject.SetActive(true);
        }
        else if (skin01ToStoreOn)
        {
            skinSelectWindow01.animation.Play("SkinSelectWindowAnim01");
            skin01ToStoreOn = false;

            storeWindow.transform.FindChild("Base/BackBtn").gameObject.SetActive(false);
            storeWindow.animation.Play("StoreWindowAnim03");

            yield return new WaitForSeconds(0.5f);
            skinSelectWindow01.transform.FindChild("BackBtn").gameObject.SetActive(true);
        }
        else if (skin02ToStoreOn)
        {
            skinSelectWindow02.animation.Play("SkinSelectWindowAnim01");
            skin02ToStoreOn = false;

            storeWindow.transform.FindChild("Base/BackBtn").gameObject.SetActive(false);
            storeWindow.animation.Play("StoreWindowAnim03");

            yield return new WaitForSeconds(0.5f);
            skinSelectWindow02.transform.FindChild("BackBtn").gameObject.SetActive(true);
        }

        else if (resultToStoreOn)
        {
            storeWindow.transform.FindChild("Base/BackBtn").gameObject.SetActive(false);
            storeWindow.animation.Play("StoreWindowAnim03");
            resultToStoreOn = false;
            yield return new WaitForSeconds(0.5f);
            ResultPanel.transform.FindChild("ResultPanelLeft").animation.Play("ResultPanelLeftAnim01");
            yield return new WaitForSeconds(0.5f);
            ResultPanel.transform.FindChild("ResultPanelLeft").animation.Play("ResultPanelLeftAnim02");
            ResultPanel.transform.FindChild("ResultPanelRight").animation.Play("ResultPanelRightAnim01");
        }

        else
        {
            flights.animation.Play("FlightsPanelAnim01");
            storeWindow.transform.FindChild("Base/BackBtn").gameObject.SetActive(false);
            storeWindow.animation.Play("StoreWindowAnim02");
            flightUpointSetScript.RedrawStatePoint();
        }

    }

    IEnumerator BackToFlight()
    {
        equipWindows.transform.FindChild("Base/BackBtn").gameObject.SetActive(false);
        equipWindows.animation.Play("StoreWindowAnim02");
        flights.animation.Play("FlightsPanelAnim01");

        attackReady.animation.Play("AttackReadyAnim02");
        yield return new WaitForSeconds(0.7f);
        prepareReady.animation.Play("PrepareReadyAnim01");

        yield return new WaitForSeconds(0.2f);

        string skinName = "Flight" + ValueDeliverScript.flightNumber.ToString("D3") + "Skin" + ValueDeliverScript.skinNumber.ToString("D3");
        if (ValueDeliverScript.isResultToHanger)
        {
            if (resultSkinNumber != 0 && int.Parse(ValueDeliverScript.gameData[resultSkinName].ToString()) <= 0)
            {
                //스킨 내구도가 0이하로 떨어지면 이 부분을 실행!
                //스킨 내구도 복구 유도 창을 띄운다.
                duraBuyAlarmWindow.SetActive(true);
                halfBLKPanel.SetActive(true);
                halfBLKPanel.transform.localPosition = new Vector3(halfBLKPanel.transform.localPosition.x, halfBLKPanel.transform.localPosition.y, duraBuyAlarmWindow.transform.localPosition.z + 5);

            }

            ValueDeliverScript.isResultToHanger = false;
        }
    }

    IEnumerator BacktoFlight2()
    {
        StartCoroutine(AttackReadyReverse());
        yield return new WaitForSeconds(0.25f);
        StartCoroutine(PrepareReadyReverse());
    }

    public void SkinWindowClose()
    {
        GetComponent<FirstLoadDataScript>().SkinlockOffCount(); //소유 스킨 갯수 표시.
        if (ValueDeliverScript.skinNumber != 0)
        {
            string selectSkinName = "FlightDura" + ValueDeliverScript.flightNumber.ToString("D3") + "Skin" + ValueDeliverScript.skinNumber.ToString("D3");

            //내구도가 0일때 기본 스킨으로 돌리는 방법.
            int selectSkinDuraValue = int.Parse(ValueDeliverScript.gameData[selectSkinName].ToString());
            if (selectSkinDuraValue <= 0)
            {
                ValueDeliverScript.skinNumber = 0;
                switch (ValueDeliverScript.flightNumber)
                {
                    case 00:
                        GameObject.Find("GameManager").GetComponent<FirstLoadDataScript>().Flight000Skin(ValueDeliverScript.skinNumber, ValueDeliverScript.skinLevel);
                        skinSelectWindow00.transform.FindChild("Skin/Skin00").GetComponent<PositionSkinSendScript>().InsertNameLevel();
                        skinSelectWindow00.transform.FindChild("HilightItem").transform.localPosition = new Vector3(78, 68, -2);
                        skinSelectWindow00.transform.FindChild("Dura").gameObject.SetActive(false);
                        break;
                    case 01:
                        GameObject.Find("GameManager").GetComponent<FirstLoadDataScript>().Flight001Skin(ValueDeliverScript.skinNumber, ValueDeliverScript.skinLevel);
                        skinSelectWindow01.transform.FindChild("Skin/Skin00").GetComponent<PositionSkinSendScript>().InsertNameLevel();
                        skinSelectWindow01.transform.FindChild("HilightItem").transform.localPosition = new Vector3(78, 68, -2);
                        skinSelectWindow01.transform.FindChild("Dura").gameObject.SetActive(false);
                        break;
                    case 02:
                        GameObject.Find("GameManager").GetComponent<FirstLoadDataScript>().Flight002Skin(ValueDeliverScript.skinNumber, ValueDeliverScript.skinLevel);
                        skinSelectWindow02.transform.FindChild("Skin/Skin00").GetComponent<PositionSkinSendScript>().InsertNameLevel();
                        skinSelectWindow02.transform.FindChild("HilightItem").transform.localPosition = new Vector3(78, 68, -2);
                        skinSelectWindow02.transform.FindChild("Dura").gameObject.SetActive(false);
                        break;
                }
            }//내구도가 0일때 기본 스킨으로 돌리는 방법.

            selectSkinName = selectSkinName.Replace("Dura", "Lock");
            Debug.Log("selectSkinName  :::  " + selectSkinName);
            //스킨 락이 해제되지 않았을때 기본 스킨으로 돌리는 방법.
            int selectskinLockOff = int.Parse(ValueDeliverScript.gameData[selectSkinName].ToString());
            if (selectskinLockOff == 0)
            {
                ValueDeliverScript.skinNumber = 0;
                switch (ValueDeliverScript.flightNumber)
                {
                    case 00:
                        GameObject.Find("GameManager").GetComponent<FirstLoadDataScript>().Flight000Skin(ValueDeliverScript.skinNumber, ValueDeliverScript.skinLevel);
                        skinSelectWindow00.transform.FindChild("Skin/Skin00").GetComponent<PositionSkinSendScript>().InsertNameLevel();
                        skinSelectWindow00.transform.FindChild("HilightItem").transform.localPosition = new Vector3(78, 68, 2);
                        skinSelectWindow00.transform.FindChild("Lock").gameObject.SetActive(false);
                        break;
                    case 01:
                        GameObject.Find("GameManager").GetComponent<FirstLoadDataScript>().Flight001Skin(ValueDeliverScript.skinNumber, ValueDeliverScript.skinLevel);
                        skinSelectWindow01.transform.FindChild("Skin/Skin00").GetComponent<PositionSkinSendScript>().InsertNameLevel();
                        skinSelectWindow01.transform.FindChild("HilightItem").transform.localPosition = new Vector3(78, 68, 2);
                        skinSelectWindow01.transform.FindChild("Lock").gameObject.SetActive(false);
                        break;
                    case 02:
                        GameObject.Find("GameManager").GetComponent<FirstLoadDataScript>().Flight002Skin(ValueDeliverScript.skinNumber, ValueDeliverScript.skinLevel);
                        skinSelectWindow02.transform.FindChild("Skin/Skin00").GetComponent<PositionSkinSendScript>().InsertNameLevel();
                        skinSelectWindow02.transform.FindChild("HilightItem").transform.localPosition = new Vector3(78, 68, 2);
                        skinSelectWindow02.transform.FindChild("Lock").gameObject.SetActive(false);
                        break;
                }
            }//스킨 락이 해제되지 않았을때 기본 스킨으로 돌리는 방법.
        }
        halfBLKPanel.SetActive(false);
    }

    //가스 부족.구매 유도창 관련 열고 닫기.
    public void GoToGasShortageWindow()
    {
        halfBLKPanel.SetActive(true);
        GasShortageWindow.SetActive(true);
        halfBLKPanel.transform.localPosition = new Vector3(halfBLKPanel.transform.localPosition.x, halfBLKPanel.transform.localPosition.y, GasShortageWindow.transform.localPosition.z + 5);
    }

    public void GasShortageWindowClose()
    {
        halfBLKPanel.SetActive(false);
        GasShortageWindow.SetActive(false);
        halfBLKPanel.transform.localPosition = new Vector3(halfBLKPanel.transform.localPosition.x, halfBLKPanel.transform.localPosition.y, -166);

    }

    public void GasShortageWindowYes()
    {
        halfBLKPanel.transform.localPosition = new Vector3(halfBLKPanel.transform.localPosition.x, halfBLKPanel.transform.localPosition.y, storeWindow.transform.localPosition.z + 5);
    }

    //코인 부족.구매 유도창 관련 열고 닫기.
    public void GoToCoinShortageWindow()
    {
        halfBLKPanel.SetActive(true);
        CoinShortageWindow.SetActive(true);
        halfBLKPanel.transform.localPosition = new Vector3(halfBLKPanel.transform.localPosition.x, halfBLKPanel.transform.localPosition.y, CoinShortageWindow.transform.localPosition.z + 5);
        StartCoroutine(CoinCharSound());
    }

    IEnumerator CoinCharSound()
    {
        int activeOper = int.Parse(ValueDeliverScript.gameData["activeOper"].ToString());
        yield return new WaitForSeconds(0.5f);
        CharacterMsgSndConScript characterMsgSndCon;
        characterMsgSndCon = GameObject.Find("CharacterMsgSndCon").GetComponent<CharacterMsgSndConScript>();
        characterMsgSndCon.CoinShort(activeOper);
    }

    public void CoinShortageWindowClose()
    {
        halfBLKPanel.SetActive(false);
        CoinShortageWindow.SetActive(false);
        halfBLKPanel.transform.localPosition = new Vector3(halfBLKPanel.transform.localPosition.x, halfBLKPanel.transform.localPosition.y, -166);
    }


    //메달 부족.구매 유도창 관련 열고 닫기.
    public void GoToMedalShortageWindow()
    {
        halfBLKPanel.SetActive(true);
        MedalShortageWindow.SetActive(true);
        halfBLKPanel.transform.localPosition = new Vector3(halfBLKPanel.transform.localPosition.x, halfBLKPanel.transform.localPosition.y, MedalShortageWindow.transform.localPosition.z + 5);
        StartCoroutine(MedalCharSound());
    }

    IEnumerator MedalCharSound()
    {
        int activeOper = int.Parse(ValueDeliverScript.gameData["activeOper"].ToString());
        yield return new WaitForSeconds(0.5f);
        CharacterMsgSndConScript characterMsgSndCon;
        characterMsgSndCon = GameObject.Find("CharacterMsgSndCon").GetComponent<CharacterMsgSndConScript>();
        characterMsgSndCon.MedalShort(activeOper);
    }

    public void MedalShortageWindowClose()
    {
        halfBLKPanel.SetActive(false);
        MedalShortageWindow.SetActive(false);
        halfBLKPanel.transform.localPosition = new Vector3(halfBLKPanel.transform.localPosition.x, halfBLKPanel.transform.localPosition.y, -166);
    }


    public void MedalShortageWindowYes()
    {
        MedalShortageWindow.SetActive(false);
        halfBLKPanel.SetActive(false);

        StartCoroutine(TransChange(storeWindow.transform.FindChild("TabCoin").gameObject, 1));
        StartCoroutine(TransChange(storeWindow.transform.FindChild("TabGas").gameObject, 0));
        StartCoroutine(TransChange(storeWindow.transform.FindChild("TabMedal").gameObject, 0));

        storeWindow.transform.FindChild("Base/TabCoinIcon").GetComponent<UISprite>().spriteName = "bt_blue_t_top_n";
        storeWindow.transform.FindChild("Base/TabGasIcon").GetComponent<UISprite>().spriteName = "bt_blue_t_top_o";
        storeWindow.transform.FindChild("Base/TabMedalIcon").GetComponent<UISprite>().spriteName = "bt_blue_t_top_o";

        storeWindow.transform.FindChild("Base/TabCoinIcon").GetComponent<UISprite>().MakePixelPerfect();
        storeWindow.transform.FindChild("Base/TabCoinIcon").GetComponent<UISprite>().MakePixelPerfect();
        storeWindow.transform.FindChild("Base/TabCoinIcon").GetComponent<UISprite>().MakePixelPerfect();

        storeWindow.transform.FindChild("TabCoin").GetComponent<UIPanel>().alpha = 1;
        storeWindow.transform.FindChild("TabCoin").gameObject.SetActive(true);

        storeWindow.transform.FindChild("TabGas").GetComponent<UIPanel>().alpha = 0;
        storeWindow.transform.FindChild("TabGas").gameObject.SetActive(false);

        storeWindow.transform.FindChild("TabMedal").GetComponent<UIPanel>().alpha = 0;
        storeWindow.transform.FindChild("TabMedal").gameObject.SetActive(false);

        storeWindow.transform.parent = winMove.transform;
        StartCoroutine(WindowsMove());
    }


    public void GoToPurchaseConfirmWindow()
    {
        ItemKeyValueScript itemScript = ValueDeliverScript.SelectedItem.GetComponent<ItemKeyValueScript>();
        int itemAmount = int.Parse(ValueDeliverScript.SelectedItem.transform.FindChild("Label").GetComponent<UILabel>().text);

        //캐릭터(오퍼레이터)를 구매시 한번이상 구매하지 못하도록 해준다. 하나이상 있으면 아무것도 하지 않고 그냥 리턴한다.
        if (itemScript.itemKey.Contains("Oper") && itemAmount > 0)
            return;

        string infoMessage; //구매시 나오는 멘트를 담는 스트링 변수.바로 아랫줄부터 이와 관련된 코딩이 됨.
        if (itemScript.itemKey.Contains("Oper"))
        {
            infoMessage = "已购买道具";
            equipWindows.transform.FindChild("Base/ItemBuyBtn").gameObject.SetActive(false);
            equipWindows.transform.FindChild("Base/LabelGet").gameObject.SetActive(false);
            equipWindows.transform.FindChild("Base/GoldIcon").gameObject.SetActive(false);
            equipWindows.transform.FindChild("Base/ItemPrice").GetComponent<UILabel>().text = "";
            equipWindows.transform.FindChild("Base/CoinAbleLabel").GetComponent<UILabel>().text = "";
        }
        else
        {
            infoMessage = "已购买道具";
        }

        int medalRest = int.Parse(ValueDeliverScript.gameData["medalRest"].ToString());
        int coinRest = int.Parse(ValueDeliverScript.gameData["coinRest"].ToString());


        if (itemScript.itemKey.Contains("Oper") && itemScript.isMedalPurchase == true)
        {
            if (medalRest >= ValueDeliverScript.purchaseCharge)
            {
                purchaseConfirmWindow.SetActive(true);
                purchaseConfirmWindow.transform.FindChild("purchaseItem").gameObject.GetComponent<UISprite>().spriteName = ValueDeliverScript.SelectedItemSprite;
                purchaseConfirmWindow.transform.FindChild("purchaseItem").gameObject.GetComponent<UISprite>().MakePixelPerfect();
                purchaseConfirmWindow.transform.FindChild("Script01").GetComponent<UILabel>().text = infoMessage; //가스 이미지를 아이템에 맞게 보여준다.

                GameObject.Find("GameManager").GetComponent<GasTimeScript>().MedalRecount(); //화면에 표시되는 메달양을 다시 계산하여 재표시하여줌.
                GameObject.Find("GameManager").GetComponent<GasTimeScript>().CoinRecount(); //화면에 표시되는 동전양을 다시 계산하여 재표시하여줌.

                purchaseConfirmWindow.GetComponent<purchaseScript>().Activate();    //정해진 시간이 지나면 자동으로 창이 꺼지는 코드가 작동하는 함수 호출.

                PurchaseConfirmWindowCloseYes(); //구매처리가 이루어지는 부분.
            }
            else
            {
                GoToMedalShortageWindow();
                purchaseConfirmWindow.SetActive(false);
            }
        }

        else if (ValueDeliverScript.SelectedItem != null && coinRest >= ValueDeliverScript.purchaseCharge)
        {
            purchaseConfirmWindow.SetActive(true);
            purchaseConfirmWindow.transform.FindChild("purchaseItem").gameObject.GetComponent<UISprite>().spriteName = ValueDeliverScript.SelectedItemSprite;
            purchaseConfirmWindow.transform.FindChild("purchaseItem").gameObject.GetComponent<UISprite>().MakePixelPerfect();
            purchaseConfirmWindow.transform.FindChild("Script01").GetComponent<UILabel>().text = infoMessage; //가스 이미지를 아이템에 맞게 보여준다.

            GameObject.Find("GameManager").GetComponent<GasTimeScript>().MedalRecount(); //화면에 표시되는 메달양을 다시 계산하여 재표시하여줌.
            GameObject.Find("GameManager").GetComponent<GasTimeScript>().CoinRecount(); //화면에 표시되는 동전양을 다시 계산하여 재표시하여줌.

            purchaseConfirmWindow.GetComponent<purchaseScript>().Activate();    //정해진 시간이 지나면 자동으로 창이 꺼지는 코드가 작동하는 함수 호출.

            PurchaseConfirmWindowCloseYes(); //구매처리가 이루어지는 부분.
        }
        else if (ValueDeliverScript.SelectedItem != null && coinRest < ValueDeliverScript.purchaseCharge)
        {
            GoToCoinShortageWindow();
            purchaseConfirmWindow.SetActive(false);
        }

    }

    public void PurchaseConfirmWindowClose()
    {
        purchaseConfirmWindow.SetActive(false);
    }

    public void PurchaseConfirmWindowCloseYes() //구매확인창. 처리 내용들.
    {
        int medalRest = int.Parse(ValueDeliverScript.gameData["medalRest"].ToString());
        int coinRest = int.Parse(ValueDeliverScript.gameData["coinRest"].ToString());

        Vector3 hilightItemPosition = new Vector3(0, 0, 0);

        if (ValueDeliverScript.SelectedItem.GetComponent<ItemKeyValueScript>().isMedalPurchase == true)
        {
            ValueDeliverScript.gameData["medalRest"] = medalRest - ValueDeliverScript.purchaseCharge;
        }
        else
        {
            ValueDeliverScript.gameData["coinRest"] = coinRest - ValueDeliverScript.purchaseCharge;
        }

        GameObject.Find("GameManager").GetComponent<GasTimeScript>().MedalRecount(); //화면에 표시되는 메달양을 다시 계산하여 재표시하여줌.
        GameObject.Find("GameManager").GetComponent<GasTimeScript>().CoinRecount(); //화면에 표시되는 동전양을 다시 계산하여 재표시하여줌.

        string htKey = (ValueDeliverScript.SelectedItem.GetComponent<ItemKeyValueScript>().itemKey).ToString();
        int htvalue = int.Parse((ValueDeliverScript.gameData["Equip" + htKey]).ToString());
        ValueDeliverScript.gameData["Equip" + htKey] = htvalue + ValueDeliverScript.SelectedItem.GetComponent<ItemKeyValueScript>().itemValue;
        ValueDeliverScript.SelectedItem.transform.FindChild("Label").gameObject.GetComponent<UILabel>().text = (ValueDeliverScript.gameData["Equip" + ValueDeliverScript.SelectedItem.GetComponent<ItemKeyValueScript>().itemKey]).ToString();

        //활성화된 아이템(캐릭터)를 기록한다.
        if (ValueDeliverScript.SelectedItem.transform.FindChild("Label").GetComponent<UILabel>().text != "0")
        {
            if (equipBombTab.activeSelf == true)
            {
                ValueDeliverScript.gameData["activeBomb"] = ValueDeliverScript.SelectedItem.GetComponent<ItemKeyValueScript>().itemNumber;
                hilightItemPosition = equipBombTab.transform.FindChild("Item/HilightItem").transform.localPosition;
            }
            else if (equipReinforceTab.activeSelf == true)
            {
                ValueDeliverScript.gameData["activeReinforce"] = ValueDeliverScript.SelectedItem.GetComponent<ItemKeyValueScript>().itemNumber;
                hilightItemPosition = equipReinforceTab.transform.FindChild("Item/HilightItem").transform.localPosition;
            }
            else if (equipAssistanceTab.activeSelf == true)
            {
                ValueDeliverScript.gameData["activeAssist"] = ValueDeliverScript.SelectedItem.GetComponent<ItemKeyValueScript>().itemNumber;
                hilightItemPosition = equipAssistanceTab.transform.FindChild("Item/HilightItem").transform.localPosition;
            }
            else if (equipOperTab.activeSelf == true)
            {
                ValueDeliverScript.gameData["activeOper"] = ValueDeliverScript.SelectedItem.GetComponent<ItemKeyValueScript>().itemNumber;
                hilightItemPosition = equipOperTab.transform.FindChild("Item/HilightItem").transform.localPosition;
                //지금 구매한 캐릭터로 이미지를 변경한다.
                equipWindows.transform.FindChild("Base/GoldIcon").gameObject.SetActive(false);
                equipWindows.transform.FindChild("Base/ItemPrice").GetComponent<UILabel>().text = "";

                CharacterMsgSndConScript characterMsgSndCon;
                characterMsgSndCon = GameObject.Find("CharacterMsgSndCon").GetComponent<CharacterMsgSndConScript>();
                characterMsgSndCon.BuyCharacter(int.Parse(ValueDeliverScript.gameData["activeOper"].ToString()));
                ChangeImage();
            }
        }

        mountIconTemp.SetActive(true);
        mountIconTemp.transform.localPosition = hilightItemPosition; //마운드 아이콘 표시해줌.

        //여기까지가 구매 확인창을 띄워서 확인을 잠깐 보여주고 물밑작업으로 어떤 아이템이 구매가 되고 돈이 차감되는지를 구현.
        EquipStartSetting();  //1173번줄에 있는 이큅스타트세팅 함수를 호출.

        HangerControl hangerCon = GameObject.Find("GameManager").GetComponent<HangerControl>();
        ValueDeliverScript.gameData["flightNumber"] = ValueDeliverScript.flightNumber;
        //Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
        ValueDeliverScript.SaveGameData();
        //Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
    }

    void ChangeImage()
    {
        int CharNum = int.Parse(ValueDeliverScript.gameData["activeOper"].ToString());
        GameObject CharacterLeftImage = GameObject.Find("CharImg");
        GameObject CharacterLabel = GameObject.Find("CharName");
        switch (CharNum)
        {
            case 1:
                CharacterLeftImage.GetComponent<UISprite>().spriteName = "Img_Operator1_01";
                CharacterLabel.GetComponent<UISprite>().spriteName = "text_operator_name1";
                break;
            case 2:
                CharacterLeftImage.GetComponent<UISprite>().spriteName = "Img_Operator2_01";
                CharacterLabel.GetComponent<UISprite>().spriteName = "text_operator_name4";
                break;
            case 3:
                CharacterLeftImage.GetComponent<UISprite>().spriteName = "Img_Operator3_01";
                CharacterLabel.GetComponent<UISprite>().spriteName = "text_operator_name2";
                break;
            case 4:
                CharacterLeftImage.GetComponent<UISprite>().spriteName = "Img_Operator4_01";
                CharacterLabel.GetComponent<UISprite>().spriteName = "text_operator_name3";
                break;
        }
    }


    public void SkinLockOffWindowClose()
    {
        GameObject.Find("Windows").transform.FindChild("SkinLockOffWindow").gameObject.SetActive(false);
    }


    //BulletUp!!!!!!!!!!!!!!!!!!!!
    public void Flight000BulletUp()
    {
        int flight000Bullet = int.Parse(ValueDeliverScript.gameData["flight000Bullet"].ToString());
        int coinRest = int.Parse(ValueDeliverScript.gameData["coinRest"].ToString());
        int upgradePoint = int.Parse(ValueDeliverScript.gameData["upgradePoint"].ToString());

        if (flight000Bullet < 15)
        {
            if (coinRest < ValueDeliverScript.flight000BulletUpCoin[flight000Bullet + 1])
            {
                GoToCoinShortageWindow();
                return;
            }
            else
            {
                flight000Bullet++;
                ValueDeliverScript.gameData["flight000Bullet"] = flight000Bullet;

                Transform flight000BulletTrans = GameObject.Find("FlightTag00/_Tag/BulletSprite").transform;
                GameObject.Find("FlightTag00/_Tag/UserBulletLevelLabel").GetComponent<UILabel>().text = flight000Bullet.ToString("D2");
                flight000BulletTrans.GetComponent<UISprite>().spriteName = "Bullet" + "00_" + flight000Bullet.ToString("D3");
                flight000BulletTrans.GetComponent<UISprite>().MakePixelPerfect();

                ValueDeliverScript.gameData["coinRest"] = coinRest - ValueDeliverScript.flight000BulletUpCoin[flight000Bullet];
                GameObject.Find("FlightTag00/_Tag/BulletUpCost").GetComponent<UILabel>().text = ValueDeliverScript.flight000BulletUpCoin[flight000Bullet + 1].ToString();
                GameObject.Find("GameManager").GetComponent<GasTimeScript>().CoinRecount(); //화면에 표시되는 동전양을 다시 계산하여 재표시하여줌.

                ValueDeliverScript.gameData["upgradePoint"] = upgradePoint + 1;
                GetComponent<FirstLoadDataScript>().FlightLockOffCheck();   //총알을 업뎃하면 확인해서 스킨 락을 풀지 여부를 결정하는 부분.
                flightUpointSetScript.RedrawStatePoint();

                StartCoroutine(WaitFirstThing("X 1"));
                HangerControl hangerCon = GameObject.Find("GameManager").GetComponent<HangerControl>();
            }
            GetComponent<FirstLoadDataScript>().SkinlockOffCount(); //비행기기본창에서 스킨이 몇개 활성화 되어있는지 보이게 하는 함수.
        }
        ValueDeliverScript.gameData["flightNumber"] = ValueDeliverScript.flightNumber;
        //Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
        ValueDeliverScript.SaveGameData();
        //Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
    }

    public void Flight001BulletUp()
    {
        int flight001Bullet = int.Parse(ValueDeliverScript.gameData["flight001Bullet"].ToString());
        int coinRest = int.Parse(ValueDeliverScript.gameData["coinRest"].ToString());
        int upgradePoint = int.Parse(ValueDeliverScript.gameData["upgradePoint"].ToString());

        if (flight001Bullet < 15)
        {
            if (coinRest < ValueDeliverScript.flight000BulletUpCoin[flight001Bullet + 1])
            {
                GoToCoinShortageWindow();
                return;
            }
            else
            {
                flight001Bullet++;
                ValueDeliverScript.gameData["flight001Bullet"] = flight001Bullet;
                Transform flight001BulletTrans = GameObject.Find("FlightTag01/_Tag/BulletSprite").transform;
                GameObject.Find("FlightTag01/_Tag/UserBulletLevelLabel").GetComponent<UILabel>().text = flight001Bullet.ToString("D2");
                flight001BulletTrans.GetComponent<UISprite>().spriteName = "Bullet" + "01_" + flight001Bullet.ToString("D3");
                flight001BulletTrans.GetComponent<UISprite>().MakePixelPerfect();

                ValueDeliverScript.gameData["coinRest"] = coinRest - ValueDeliverScript.flight001BulletUpCoin[flight001Bullet];
                GameObject.Find("FlightTag01/_Tag/BulletUpCost").GetComponent<UILabel>().text = ValueDeliverScript.flight001BulletUpCoin[flight001Bullet + 1].ToString();
                GameObject.Find("GameManager").GetComponent<GasTimeScript>().CoinRecount(); //화면에 표시되는 동전양을 다시 계산하여 재표시하여줌.

                ValueDeliverScript.gameData["upgradePoint"] = upgradePoint + 1;
                GetComponent<FirstLoadDataScript>().FlightLockOffCheck();   //총알을 업뎃하면 확인해서 스킨 락을 풀지 여부를 결정하는 부분.
                flightUpointSetScript.RedrawStatePoint();

                StartCoroutine(WaitFirstThing("X 1"));

                HangerControl hangerCon = GameObject.Find("GameManager").GetComponent<HangerControl>();
            }
            GetComponent<FirstLoadDataScript>().SkinlockOffCount(); //비행기기본창에서 스킨이 몇개 활성화 되어있는지 보이게 하는 함수.
        }
        ValueDeliverScript.gameData["flightNumber"] = ValueDeliverScript.flightNumber;
        //Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
        ValueDeliverScript.SaveGameData();
        //Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
    }


    public void Flight002BulletUp()
    {
        int flight002Bullet = int.Parse(ValueDeliverScript.gameData["flight002Bullet"].ToString());
        int coinRest = int.Parse(ValueDeliverScript.gameData["coinRest"].ToString());
        int upgradePoint = int.Parse(ValueDeliverScript.gameData["upgradePoint"].ToString());

        if (flight002Bullet < 15)
        {
            if (coinRest < ValueDeliverScript.flight000BulletUpCoin[flight002Bullet + 1])
            {
                GoToCoinShortageWindow();
                return;
            }
            else
            {
                flight002Bullet++;
                ValueDeliverScript.gameData["flight002Bullet"] = flight002Bullet;
                Transform flight002BulletTrans = GameObject.Find("FlightTag02/_Tag/BulletSprite").transform;
                GameObject.Find("FlightTag02/_Tag/UserBulletLevelLabel").GetComponent<UILabel>().text = flight002Bullet.ToString("D2");
                flight002BulletTrans.GetComponent<UISprite>().spriteName = "Bullet" + "02_" + flight002Bullet.ToString("D3");
                flight002BulletTrans.GetComponent<UISprite>().MakePixelPerfect();

                ValueDeliverScript.gameData["coinRest"] = coinRest - ValueDeliverScript.flight001BulletUpCoin[flight002Bullet];
                GameObject.Find("FlightTag02/_Tag/BulletUpCost").GetComponent<UILabel>().text = ValueDeliverScript.flight002BulletUpCoin[flight002Bullet + 1].ToString();
                GameObject.Find("GameManager").GetComponent<GasTimeScript>().CoinRecount(); //화면에 표시되는 동전양을 다시 계산하여 재표시하여줌.

                ValueDeliverScript.gameData["upgradePoint"] = upgradePoint + 1;
                GetComponent<FirstLoadDataScript>().FlightLockOffCheck();   //총알을 업뎃하면 확인해서 스킨 락을 풀지 여부를 결정하는 부분.
                flightUpointSetScript.RedrawStatePoint();

                StartCoroutine(WaitFirstThing("X 1"));
                HangerControl hangerCon = GameObject.Find("GameManager").GetComponent<HangerControl>();
            }
            GetComponent<FirstLoadDataScript>().SkinlockOffCount(); //비행기기본창에서 스킨이 몇개 활성화 되어있는지 보이게 하는 함수.
        }
        ValueDeliverScript.gameData["flightNumber"] = ValueDeliverScript.flightNumber;
        //Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
        ValueDeliverScript.SaveGameData();
        //Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
    }


    IEnumerator WaitFirstThing(string val)
    {
        GameObject[] userWin = { skinLockOffWindow, upgradePointWindow };
        yield return StartCoroutine(WaitShowWindow(userWin, ShowUpgradePointWindow));
        upgradePointWindow.transform.FindChild("PointAdd").GetComponent<UILabel>().text = val;
    }

    //SkillUp!!!!!!!!!!!!
    public void Flight000SkillUp()
    {
        int flight000Skill = int.Parse(ValueDeliverScript.gameData["flight000Skill"].ToString());
        int coinRest = int.Parse(ValueDeliverScript.gameData["coinRest"].ToString());
        int upgradePoint = int.Parse(ValueDeliverScript.gameData["upgradePoint"].ToString());

        if (flight000Skill < 5)
        {
            if (coinRest < ValueDeliverScript.flight000SkillUpCoin[flight000Skill + 1])
            {
                GoToCoinShortageWindow();
                return;
            }
            else
            {
                flight000Skill++;
                ValueDeliverScript.gameData["flight000Skill"] = flight000Skill;
                GameObject.Find("FlightTag00/_Tag/UserSkillLevelLabel").GetComponent<UILabel>().text = flight000Skill.ToString("D2");
                ValueDeliverScript.gameData["coinRest"] = coinRest - ValueDeliverScript.flight000SkillUpCoin[flight000Skill];
                GameObject.Find("FlightTag00/_Tag/SkillUpCost").GetComponent<UILabel>().text = ValueDeliverScript.flight000SkillUpCoin[int.Parse(ValueDeliverScript.gameData["flight000Skill"].ToString()) + 1].ToString();
                GameObject.Find("GameManager").GetComponent<GasTimeScript>().CoinRecount(); //화면에 표시되는 동전양을 다시 계산하여 재표시하여줌.
                ValueDeliverScript.gameData["upgradePoint"] = upgradePoint + 1;
                upgradePointWindow.transform.FindChild("PointAdd").GetComponent<UILabel>().text = "X 1";
                ShowUpgradePointWindow();

                flightUpointSetScript.RedrawStatePoint();
                HangerControl hangerCon = GameObject.Find("GameManager").GetComponent<HangerControl>();
            }
        }
        ValueDeliverScript.gameData["flightNumber"] = ValueDeliverScript.flightNumber;
        //Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
        ValueDeliverScript.SaveGameData();
        //Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
    }

    public void Flight001SkillUp()
    {
        int flight001Skill = int.Parse(ValueDeliverScript.gameData["flight001Skill"].ToString());
        int coinRest = int.Parse(ValueDeliverScript.gameData["coinRest"].ToString());
        int upgradePoint = int.Parse(ValueDeliverScript.gameData["upgradePoint"].ToString());

        if (flight001Skill < 5)
        {
            if (coinRest < ValueDeliverScript.flight001SkillUpCoin[flight001Skill + 1])
            {
                GoToCoinShortageWindow();
                return;
            }
            else
            {
                flight001Skill++;
                ValueDeliverScript.gameData["flight001Skill"] = flight001Skill;
                GameObject.Find("FlightTag01/_Tag/UserSkillLevelLabel").GetComponent<UILabel>().text = flight001Skill.ToString("D2");
                ValueDeliverScript.gameData["coinRest"] = coinRest - ValueDeliverScript.flight001SkillUpCoin[flight001Skill];
                GameObject.Find("FlightTag01/_Tag/SkillUpCost").GetComponent<UILabel>().text = ValueDeliverScript.flight001SkillUpCoin[flight001Skill + 1].ToString();
                GameObject.Find("GameManager").GetComponent<GasTimeScript>().CoinRecount(); //화면에 표시되는 동전양을 다시 계산하여 재표시하여줌.
                ValueDeliverScript.gameData["upgradePoint"] = upgradePoint + 1;
                upgradePointWindow.transform.FindChild("PointAdd").GetComponent<UILabel>().text = "X 1";
                ShowUpgradePointWindow();

                flightUpointSetScript.RedrawStatePoint();
                HangerControl hangerCon = GameObject.Find("GameManager").GetComponent<HangerControl>();
            }
        }
        ValueDeliverScript.gameData["flightNumber"] = ValueDeliverScript.flightNumber;
        //Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
        ValueDeliverScript.SaveGameData();
        //Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
    }

    public void Flight002SkillUp()
    {
        int flight002Skill = int.Parse(ValueDeliverScript.gameData["flight002Skill"].ToString());
        int coinRest = int.Parse(ValueDeliverScript.gameData["coinRest"].ToString());
        int upgradePoint = int.Parse(ValueDeliverScript.gameData["upgradePoint"].ToString());

        if (flight002Skill < 5)
        {
            if (coinRest < ValueDeliverScript.flight002SkillUpCoin[flight002Skill + 1])
            {
                GoToCoinShortageWindow();
                return;
            }
            else
            {
                flight002Skill++;
                ValueDeliverScript.gameData["flight002Skill"] = flight002Skill;
                GameObject.Find("FlightTag02/_Tag/UserSkillLevelLabel").GetComponent<UILabel>().text = flight002Skill.ToString("D2");
                ValueDeliverScript.gameData["coinRest"] = coinRest - ValueDeliverScript.flight002SkillUpCoin[flight002Skill];
                GameObject.Find("FlightTag02/_Tag/SkillUpCost").GetComponent<UILabel>().text = ValueDeliverScript.flight002SkillUpCoin[flight002Skill + 1].ToString();
                GameObject.Find("GameManager").GetComponent<GasTimeScript>().CoinRecount(); //화면에 표시되는 동전양을 다시 계산하여 재표시하여줌.
                ValueDeliverScript.gameData["upgradePoint"] = upgradePoint + 1;
                upgradePointWindow.transform.FindChild("PointAdd").GetComponent<UILabel>().text = "X 1";
                ShowUpgradePointWindow();

                flightUpointSetScript.RedrawStatePoint();
                HangerControl hangerCon = GameObject.Find("GameManager").GetComponent<HangerControl>();
            }
        }
        ValueDeliverScript.gameData["flightNumber"] = ValueDeliverScript.flightNumber;
        //Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
        ValueDeliverScript.SaveGameData();
        //Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
    }

    public void DuraRecharge() //수리하기 버튼을 누르면 작동하는 함수. 위치는 SkinSelectWindow  >> Dura //
    {
        string duraCostS = "Flight" + ValueDeliverScript.flightNumber.ToString("D3") + "Skin" + ValueDeliverScript.skinNumber.ToString("D3") + "Level" + ValueDeliverScript.skinLevel.ToString("D3");
        int duraCostI = int.Parse(ValueDeliverScript.duraCost[duraCostS].ToString());
        int coinRest = int.Parse(ValueDeliverScript.gameData["coinRest"].ToString());

        if (duraCostI > coinRest)
        {
            GoToCoinShortageWindow();
            return;
        }
        else
        {
            ValueDeliverScript.gameData["coinRest"] = coinRest - duraCostI;
            GameObject.Find("GameManager").GetComponent<GasTimeScript>().CoinRecount(); //화면에 표시되는 동전양을 다시 계산하여 재표시하여줌.
            GameObject.Find("Dura").SetActive(false);
            string skinName = "FlightDura" + ValueDeliverScript.flightNumber.ToString("D3") + "Skin" + ValueDeliverScript.skinNumber.ToString("D3");

            ValueDeliverScript.gameData[skinName] = 10; //원래는 10//
            GameObject SelectedSkin = GameObject.Find("SkinSelectWindow" + ValueDeliverScript.flightNumber.ToString("D2")).transform.FindChild("Skin").FindChild("Skin" + ValueDeliverScript.skinNumber.ToString("D2")).gameObject;
            SelectedSkin.transform.FindChild("SkinIcon").GetComponent<UISprite>().alpha = 1f;
            SelectedSkin.transform.FindChild("RefairIcon").gameObject.SetActive(false);
            SelectedSkin.transform.FindChild("DuraLabel").GetComponent<UILabel>().text = ValueDeliverScript.gameData[skinName].ToString() + "/10";
        }
        ValueDeliverScript.gameData["flightNumber"] = ValueDeliverScript.flightNumber;
        //Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
        ValueDeliverScript.SaveGameData();
        //Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
    }

    void SkinLockOffMessage()
    {
        int flight000SortieNumber = int.Parse(ValueDeliverScript.gameData["flight000SortieNumber"].ToString());
        int userLevel = int.Parse(ValueDeliverScript.gameData["userLevel"].ToString());
        int flight000BombUseNumber = int.Parse(ValueDeliverScript.gameData["flight000BombUseNumber"].ToString());
        int flight000ScoreHigh = int.Parse(ValueDeliverScript.gameData["flight000ScoreHigh"].ToString());
        int flight000Bullet = int.Parse(ValueDeliverScript.gameData["flight000Bullet"].ToString());

        int flight001EnemyKill = int.Parse(ValueDeliverScript.gameData["flight001EnemyKill"].ToString());
        int flight001GetCoin = int.Parse(ValueDeliverScript.gameData["flight001GetCoin"].ToString());
        int flight001UseSkill = int.Parse(ValueDeliverScript.gameData["flight001UseSkill"].ToString());
        int flight001GetPowerItem = int.Parse(ValueDeliverScript.gameData["flight001GetPowerItem"].ToString());
        int flight001Bullet = int.Parse(ValueDeliverScript.gameData["flight001Bullet"].ToString());

        int flight002KillSpinball = int.Parse(ValueDeliverScript.gameData["flight002KillSpinball"].ToString());
        int flight002SpecialAttack = int.Parse(ValueDeliverScript.gameData["flight002SpecialAttack"].ToString());
        int flight002CompleteInstanceMission = int.Parse(ValueDeliverScript.gameData["flight002CompleteInstanceMission"].ToString());
        int flight002RescueFriend = int.Parse(ValueDeliverScript.gameData["flight002RescueFriend"].ToString());


        GameObject.Find("SkinSelectWindow00/Skin/Skin01").GetComponent<PositionSkinSendScript>().lockOffCondition = flight000SortieNumber + "/100次出击";
        GameObject.Find("SkinSelectWindow00/Skin/Skin02").GetComponent<PositionSkinSendScript>().lockOffCondition = "达到驾驶" + userLevel + "/5级";
        GameObject.Find("SkinSelectWindow00/Skin/Skin03").GetComponent<PositionSkinSendScript>().lockOffCondition = "核弹使用 " + flight000BombUseNumber + "/300次";
        GameObject.Find("SkinSelectWindow00/Skin/Skin04").GetComponent<PositionSkinSendScript>().lockOffCondition = "达到" + flight000ScoreHigh + "/2500000分";
        GameObject.Find("SkinSelectWindow00/Skin/Skin05").GetComponent<PositionSkinSendScript>().lockOffCondition = "战机子弹升级" + flight000Bullet + "/15级";

        GameObject.Find("SkinSelectWindow01/Skin/Skin01").GetComponent<PositionSkinSendScript>().lockOffCondition = "破坏敌机" + flight001EnemyKill + "/50000台";
        GameObject.Find("SkinSelectWindow01/Skin/Skin02").GetComponent<PositionSkinSendScript>().lockOffCondition = "获得得分" + flight001GetCoin + "/100000";
        GameObject.Find("SkinSelectWindow01/Skin/Skin03").GetComponent<PositionSkinSendScript>().lockOffCondition = "技能使用" + flight001UseSkill + "/500次";
        GameObject.Find("SkinSelectWindow01/Skin/Skin04").GetComponent<PositionSkinSendScript>().lockOffCondition = "能量道具获得" + flight001GetPowerItem + "/3000个";
        GameObject.Find("SkinSelectWindow01/Skin/Skin05").GetComponent<PositionSkinSendScript>().lockOffCondition = "战机子弹升级" + flight001Bullet + "/15个级别";

        GameObject.Find("SkinSelectWindow02/Skin/Skin01").GetComponent<PositionSkinSendScript>().lockOffCondition = "旋球破坏" + flight002KillSpinball + "/50000台";
        GameObject.Find("SkinSelectWindow02/Skin/Skin02").GetComponent<PositionSkinSendScript>().lockOffCondition = "特殊出击" + flight002SpecialAttack + "/100次";
        GameObject.Find("SkinSelectWindow02/Skin/Skin03").GetComponent<PositionSkinSendScript>().lockOffCondition = "即时任务" + flight002CompleteInstanceMission + "/完成1000回";
        GameObject.Find("SkinSelectWindow02/Skin/Skin04").GetComponent<PositionSkinSendScript>().lockOffCondition = "救出好友" + flight002RescueFriend + "/5000名";
        GameObject.Find("SkinSelectWindow02/Skin/Skin05").GetComponent<PositionSkinSendScript>().lockOffCondition = "达到第6阶段";
    }

    //비행기 스킨별로 락 해제 조건 검사하고 결과를 알려주는 함수//
    public bool SkinLockCheck(int flightNumber, int skinNumber)
    {
        SkinLockOffMessage();
        bool check = false;
        string skinName = "FlightLock" + flightNumber.ToString("D3") + "Skin" + skinNumber.ToString("D3");
        int flight000SortieNumber = int.Parse(ValueDeliverScript.gameData["flight000SortieNumber"].ToString());
        int userLevel = int.Parse(ValueDeliverScript.gameData["userLevel"].ToString());
        int flight000BombUseNumber = int.Parse(ValueDeliverScript.gameData["flight000BombUseNumber"].ToString());
        int flight000ScoreHigh = int.Parse(ValueDeliverScript.gameData["flight000ScoreHigh"].ToString());
        int flight000Bullet = int.Parse(ValueDeliverScript.gameData["flight000Bullet"].ToString());
        int flight001EnemyKill = int.Parse(ValueDeliverScript.gameData["flight001EnemyKill"].ToString());
        int flight001GetCoin = int.Parse(ValueDeliverScript.gameData["flight001GetCoin"].ToString());
        int flight001UseSkill = int.Parse(ValueDeliverScript.gameData["flight001UseSkill"].ToString());
        int flight001GetPowerItem = int.Parse(ValueDeliverScript.gameData["flight001GetPowerItem"].ToString());
        int flight001Bullet = int.Parse(ValueDeliverScript.gameData["flight001Bullet"].ToString());
        int flight002KillSpinball = int.Parse(ValueDeliverScript.gameData["flight002KillSpinball"].ToString());
        int flight002SpecialAttack = int.Parse(ValueDeliverScript.gameData["flight002SpecialAttack"].ToString());
        int flight002CompleteInstanceMission = int.Parse(ValueDeliverScript.gameData["flight002CompleteInstanceMission"].ToString());
        int flight002RescueFriend = int.Parse(ValueDeliverScript.gameData["flight002RescueFriend"].ToString());
        int flight002WormLevel6 = int.Parse(ValueDeliverScript.gameData["flight002WormLevel5"].ToString());

        switch (skinName)
        {
            //포커 락해제 조건//
            case "FlightLock000Skin001":
                if (flight000SortieNumber >= 100 && int.Parse(ValueDeliverScript.gameData[skinName].ToString()) == 0)    //100회 출격//(완)
                {
                    IsOpenLockOffWindow(skinName);
                    ValueDeliverScript.gameData[skinName] = 1;
                }
                break;
            case "FlightLock000Skin002":
                if (userLevel >= 5 && int.Parse(ValueDeliverScript.gameData[skinName].ToString()) == 0)  //파일럿 5레벨도달//(완)
                {
                    IsOpenLockOffWindow(skinName);
                    ValueDeliverScript.gameData[skinName] = 1;
                }
                break;
            case "FlightLock000Skin003":
                if (flight000BombUseNumber >= 300 && int.Parse(ValueDeliverScript.gameData[skinName].ToString()) == 0)   //핵폭탄 300회 사용//(완)
                {
                    IsOpenLockOffWindow(skinName);
                    ValueDeliverScript.gameData[skinName] = 1;
                }
                break;
            case "FlightLock000Skin004":
                if (flight000ScoreHigh >= 2500000 && int.Parse(ValueDeliverScript.gameData[skinName].ToString()) == 0)    //250만점 달성//(완)
                {
                    IsOpenLockOffWindow(skinName);
                    ValueDeliverScript.gameData[skinName] = 1;
                }
                break;
            case "FlightLock000Skin005":
                if (flight000Bullet >= 15 && int.Parse(ValueDeliverScript.gameData[skinName].ToString()) == 0)   //기체 탄환 15단계 업그레이드//(완)
                {
                    IsOpenLockOffWindow(skinName);
                    ValueDeliverScript.gameData[skinName] = 1;
                }
                break;

            //코만치 락해제 조건//
            case "FlightLock001Skin001":
                if (flight001EnemyKill >= 50000 && int.Parse(ValueDeliverScript.gameData[skinName].ToString()) == 0) //적 50000대 파괴//(완)
                {
                    IsOpenLockOffWindow(skinName);
                    ValueDeliverScript.gameData[skinName] = 1;
                }
                break;
            case "FlightLock001Skin002":
                if (flight001GetCoin >= 100000 && int.Parse(ValueDeliverScript.gameData[skinName].ToString()) == 0)  //100000코인 획득//(완)
                {
                    IsOpenLockOffWindow(skinName);
                    ValueDeliverScript.gameData[skinName] = 1;
                }
                break;
            case "FlightLock001Skin003":
                if (flight001UseSkill >= 500 && int.Parse(ValueDeliverScript.gameData[skinName].ToString()) == 0)    //스킬 500회 사용//(완)
                {
                    IsOpenLockOffWindow(skinName);
                    ValueDeliverScript.gameData[skinName] = 1;
                }
                break;
            case "FlightLock001Skin004":
                if (flight001GetPowerItem >= 3000 && int.Parse(ValueDeliverScript.gameData[skinName].ToString()) == 0)   //파워아이템 3000개 획득//
                {
                    IsOpenLockOffWindow(skinName);
                    ValueDeliverScript.gameData[skinName] = 1;
                }
                break;
            case "FlightLock001Skin005":
                if (flight001Bullet >= 15 && int.Parse(ValueDeliverScript.gameData[skinName].ToString()) == 0)   //기체 탄환 15단계 업그레이드//
                {
                    IsOpenLockOffWindow(skinName);
                    ValueDeliverScript.gameData[skinName] = 1;
                }
                break;

            //팬텀 락해제 조건//
            case "FlightLock002Skin001":
                if (flight002KillSpinball >= 50000 && int.Parse(ValueDeliverScript.gameData[skinName].ToString()) == 0)    //스핀볼 50000대 파괴//
                {
                    IsOpenLockOffWindow(skinName);
                    ValueDeliverScript.gameData[skinName] = 1;
                }
                break;
            case "FlightLock002Skin002":
                if (flight002SpecialAttack >= 100 && int.Parse(ValueDeliverScript.gameData[skinName].ToString()) == 0)    //스페셜출격 100회//
                {
                    IsOpenLockOffWindow(skinName);
                    ValueDeliverScript.gameData[skinName] = 1;
                }
                break;
            case "FlightLock002Skin003":
                if (flight002CompleteInstanceMission >= 1000 && int.Parse(ValueDeliverScript.gameData[skinName].ToString()) == 0) //인스턴트미션 1000회 완료//
                {
                    IsOpenLockOffWindow(skinName);
                    ValueDeliverScript.gameData[skinName] = 1;
                }
                break;
            case "FlightLock002Skin004":
                if (flight002RescueFriend >= 5000 && int.Parse(ValueDeliverScript.gameData[skinName].ToString()) == 0)    //친구 5000명 구출//
                {
                    IsOpenLockOffWindow(skinName);
                    ValueDeliverScript.gameData[skinName] = 1;
                }
                break;
            case "FlightLock002Skin005":
                if (flight002WormLevel6 == 1 && int.Parse(ValueDeliverScript.gameData[skinName].ToString()) == 0)     //6단계 도달//
                {
                    IsOpenLockOffWindow(skinName);
                    ValueDeliverScript.gameData[skinName] = 1;
                }
                break;
        }

        if (int.Parse(ValueDeliverScript.gameData[skinName].ToString()) == 1)
            check = true;

        ValueDeliverScript.gameData["flightNumber"] = ValueDeliverScript.flightNumber;
        ////Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
        ValueDeliverScript.SaveGameData();
        ////Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
        return check;
    }


    public GameObject skinLockOffWindow;

    void IsOpenLockOffWindow(string skinName)
    {
        if (skinSelectWindow00.transform.localPosition.x == 40 || skinSelectWindow01.transform.localPosition.x == 40 || skinSelectWindow02.transform.localPosition.x == 40)
        {
            return;
        }
        int upgradePoint = int.Parse(ValueDeliverScript.gameData["upgradePoint"].ToString());
        upgradePoint++;  //스킨 락이 해제되었으니 강화포인트 1을 지급한다.
        ValueDeliverScript.gameData["upgradePoint"] = upgradePoint;
        //락오프 한적이 없었다면 첨이자 마지막으로 락오프가 되는 것이니 비행기가 락이 풀렸다고 창을 띄워 알려줌.
        if (int.Parse(ValueDeliverScript.gameData[skinName].ToString()) == 0)
        {
            Debug.Log("skinName ::: " + skinName);

            if (skinName.Contains("FlightLock000"))
            {
                int num = int.Parse(skinName.Replace("FlightLock000Skin", "")) + 1;
                skinName = "Fokker" + num.ToString("000");
            }
            else if (skinName.Contains("FlightLock001"))
            {
                int num = int.Parse(skinName.Replace("FlightLock001Skin", "")) + 1;
                skinName = "Fokker" + num.ToString("000");
            }
            else if (skinName.Contains("FlightLock002"))
            {
                int num = int.Parse(skinName.Replace("FlightLock002Skin", "")) + 1;
                skinName = "Fokker" + num.ToString("000");
            }
            skinLockOffWindow.transform.FindChild("Item001").FindChild("Icon").GetComponent<UISprite>().spriteName = skinName + "Fix";
        }
        skinLockOffWindow.SetActive(true);
        StartCoroutine(IsOpenLockOffWindow02());

        HangerControl hangerCon = GameObject.Find("GameManager").GetComponent<HangerControl>();
        ValueDeliverScript.gameData["flightNumber"] = ValueDeliverScript.flightNumber;
        //Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
        ValueDeliverScript.SaveGameData();
        //Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
    }

    IEnumerator IsOpenLockOffWindow02()
    {
        GameObject[] userWin = { skinLockOffWindow };
        yield return StartCoroutine(WaitShowWindow(userWin, ShowUpgradePointWindow));
        upgradePointWindow.transform.FindChild("PointAdd").GetComponent<UILabel>().text = "X 1";
    }


    IEnumerator WaitShowWindow(GameObject[] userWindow01, NextFunc func)
    {
        int winOff = 0;
        foreach (var win in userWindow01)
        {
            if (win.activeSelf == true)
                winOff++;
        }

        if (winOff > 0)
        {
            bool[] firstsWinOff = new bool[userWindow01.Length];
            for (int var = 0; var < firstsWinOff.Length; var++)
            {
                firstsWinOff[var] = true;
            }
            bool[] finalWinOff = firstsWinOff;


            while (true)
            {
                for (int var = 0; var < userWindow01.Length; var++)
                {
                    if (firstsWinOff[var] == true && userWindow01[var].activeSelf == false)
                        continue;
                    if (userWindow01[var].activeSelf == true)
                    {
                        firstsWinOff[var] = false;
                        continue;
                    }
                    if (firstsWinOff[var] == false && userWindow01[var].activeSelf == false)
                        finalWinOff[var] = false;
                }

                int winCloseCount = 0;
                for (int var = 0; var < finalWinOff.Length; var++)
                {
                    if (finalWinOff[var] == true || userWindow01[var].activeSelf == true)
                    {
                        winCloseCount++;
                    }
                }

                if (winCloseCount == 0)
                    break;

                yield return null;
            }
        }
        func();
    }

    public void FlightSkinLockOff() // 스킨 잠금 해제 버튼 눌렀을때 실행되는 함수.
    {

        string skinName = "Flight" + ValueDeliverScript.flightNumber.ToString("D3") + "Skin" + ValueDeliverScript.skinNumber.ToString("D3");  //해쉬테이블에서 스킨별 메달코스트를 가지고 올수 있게 비행기 넘버와 스킨 넘버를 이용하여 스킨 이름을 생성.
        Debug.Log("skinName ::: " + skinName);
        int skinMedalCostI = int.Parse(ValueDeliverScript.skinMedalCost[skinName].ToString()); //락 해제 가격(다이아몬드, 코인)을 가져와 int 형으로 변환하여 사용가능하게 만듬.
        int medalRest = int.Parse(ValueDeliverScript.gameData["medalRest"].ToString()); //현재의 메달량을 Int 형으로 변환하여 가져온다.
        int coinRest = int.Parse(ValueDeliverScript.gameData["coinRest"].ToString());   //현재의 코인량을  int 형으로 변환하여 가져온다.
        int upgradePoint = int.Parse(ValueDeliverScript.gameData["upgradePoint"].ToString());

        if (ValueDeliverScript.skinNumber != 4)
        {

            if (skinMedalCostI > coinRest)   //코인이 부족하면 메달 구매창을 띄움.
            {
                GoToCoinShortageWindow();
                return;
            }
            else
            {
                GameObject SelectedSkin = GameObject.Find("SkinSelectWindow" + ValueDeliverScript.flightNumber.ToString("D2")).transform.FindChild("Skin").FindChild("Skin" + ValueDeliverScript.skinNumber.ToString("D2")).gameObject;
                coinRest -= skinMedalCostI;
                ValueDeliverScript.gameData["coinRest"] = coinRest; //사용메달 차감.
                GameObject.Find("GoldRestLabel").GetComponent<UILabel>().text = coinRest.ToString(); //화면에 표시되는 동전양을 다시 계산하여 재표시하여줌.
                SelectedSkin.transform.parent.parent.FindChild("Lock").gameObject.SetActive(false);   //스킨락 버튼이랑 내용들 숨김.


                //string skinName = "FlightLock" + flightNumber.ToString("D3") + "Skin" + skinNumber.ToString("D3");
                skinName = "FlightLock" + ValueDeliverScript.flightNumber.ToString("D3") + "Skin" + ValueDeliverScript.skinNumber.ToString("D3");  //해쉬테이블에서 스킨별 메달코스트를 가지고 올수 있게 비행기 넘버와 스킨 넘버를 이용하여 스킨 이름을 생성.
                //Skin Name Aample ::: FlightLock000Skin001 :::
                ValueDeliverScript.gameData[skinName] = 1;    //스킨이 락해제 되었음을 저장.

                SelectedSkin.transform.FindChild("SkinIcon").GetComponent<UISprite>().alpha = 1f;
                SelectedSkin.transform.FindChild("LockIcon").gameObject.SetActive(false);

                upgradePoint += 1;
                ValueDeliverScript.gameData["upgradePoint"] = upgradePoint;
                upgradePointWindow.transform.FindChild("PointAdd").GetComponent<UILabel>().text = "X 1";
                ShowUpgradePointWindow();

                flightUpointSetScript.RedrawStatePoint();
                StartCoroutine(SkinLockOffCharSound());
                HangerControl hangerCon = GameObject.Find("GameManager").GetComponent<HangerControl>();
            }
        }
        else
        {
            if (skinMedalCostI > medalRest)   //메달이 부족하면 메달 구매창을 띄움.
            {
                GoToMedalShortageWindow();
                return;
            }
            else
            {
                GameObject SelectedSkin = GameObject.Find("SkinSelectWindow" + ValueDeliverScript.flightNumber.ToString("D2")).transform.FindChild("Skin").FindChild("Skin" + ValueDeliverScript.skinNumber.ToString("D2")).gameObject;
                medalRest -= skinMedalCostI;
                ValueDeliverScript.gameData["medalRest"] = medalRest; //사용금화 차감.
                GameObject.Find("MedalRestLabel").GetComponent<UILabel>().text = medalRest.ToString(); //화면에 표시되는 동전양을 다시 계산하여 재표시하여줌.
                SelectedSkin.transform.parent.parent.FindChild("Lock").gameObject.SetActive(false);   //스킨락 버튼이랑 내용들 숨김.


                //string skinName = "FlightLock" + flightNumber.ToString("D3") + "Skin" + skinNumber.ToString("D3");
                skinName = "FlightLock" + ValueDeliverScript.flightNumber.ToString("D3") + "Skin" + ValueDeliverScript.skinNumber.ToString("D3");  //해쉬테이블에서 스킨별 메달코스트를 가지고 올수 있게 비행기 넘버와 스킨 넘버를 이용하여 스킨 이름을 생성.
                //Skin Name Aample ::: FlightLock000Skin001 :::
                ValueDeliverScript.gameData[skinName] = 1;    //스킨이 락해제 되었음을 저장.

                SelectedSkin.transform.FindChild("SkinIcon").GetComponent<UISprite>().alpha = 1f;
                SelectedSkin.transform.FindChild("LockIcon").gameObject.SetActive(false);

                upgradePoint += 1;
                ValueDeliverScript.gameData["upgradePoint"] = upgradePoint;
                upgradePointWindow.transform.FindChild("PointAdd").GetComponent<UILabel>().text = "X 1";
                ShowUpgradePointWindow();

                flightUpointSetScript.RedrawStatePoint();
                StartCoroutine(SkinLockOffCharSound());
                HangerControl hangerCon = GameObject.Find("GameManager").GetComponent<HangerControl>();
            }
        }

        ValueDeliverScript.gameData["flightNumber"] = ValueDeliverScript.flightNumber;
        //Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
        ValueDeliverScript.SaveGameData();
        //Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
    }

    IEnumerator SkinLockOffCharSound()
    {
        int activeOper = int.Parse(ValueDeliverScript.gameData["activeOper"].ToString());
        yield return new WaitForSeconds(0.5f);
        CharacterMsgSndConScript characterMsgSndCon;
        characterMsgSndCon = GameObject.Find("CharacterMsgSndCon").GetComponent<CharacterMsgSndConScript>();
        characterMsgSndCon.SkinUnlock(activeOper);
    }

    public void OpenSound()
    {
        audio.PlayOneShot(popupDisplay, ValueDeliverScript.fxSound);
    }

    public void LevelPopupDisplay()
    {
        audio.PlayOneShot(levelPopupDisplay, ValueDeliverScript.fxSound);
    }


    public void CloseSound()
    {
    }

    public void GoldPurchaseWindow(int itemNumber)
    {
        int goldPrice = int.Parse((ValueDeliverScript.goldPrice["GoldPrice" + itemNumber.ToString("000")]).ToString());     //아이템 메달가격을 알아온다.
        int goldPriceNum = int.Parse((ValueDeliverScript.goldPrice["GoldPrice" + itemNumber.ToString("000") + "Num"]).ToString());     //아이템별 구매시 지급되는 골드의 갯수를 알아온다.
        int medalRest = int.Parse(ValueDeliverScript.gameData["medalRest"].ToString());
        int coinRest = int.Parse(ValueDeliverScript.gameData["coinRest"].ToString());

        if (goldPrice > medalRest)
        {
            GoToMedalShortageWindow();
            return;
        }
        medalRest -= goldPrice;
        coinRest += goldPriceNum;

        ValueDeliverScript.gameData["medalRest"] = medalRest;
        ValueDeliverScript.gameData["coinRest"] = coinRest;
        purchaseConfirmWindow.SetActive(true);
        purchaseConfirmWindow.GetComponent<purchaseScript>().Activate();
        purchaseConfirmWindow.transform.FindChild("purchaseItem").GetComponent<UISprite>().spriteName = "icon_gold_" + itemNumber; //골드 이미지를 아이템에 맞게 보여준다.
        purchaseConfirmWindow.transform.FindChild("purchaseItem").GetComponent<UISprite>().MakePixelPerfect(); //가스 이미지를 아이템에 맞게 보여준다.
        purchaseConfirmWindow.transform.FindChild("Script01").GetComponent<UILabel>().text = "已购买金币。"; //골드 이미지를 아이템에 맞게 보여준다.
        GameObject.Find("GameManager").GetComponent<GasTimeScript>().MedalRecount(); //화면에 표시되는 메달양을 다시 계산하여 재표시하여줌.
        GameObject.Find("GameManager").GetComponent<GasTimeScript>().CoinRecount(); //화면에 표시되는 동전양을 다시 계산하여 재표시하여줌.
        ValueDeliverScript.gameData["flightNumber"] = ValueDeliverScript.flightNumber;
        //Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
        ValueDeliverScript.SaveGameData();
        //Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
    }

    int gasPrice = 0;
    int gasPriceNum = 0;
    int itemNumberF = 0;
    public GameObject GasOverWindow;

    public void GasPurchaseWindow(int itemNumber)
    {
        gasPrice = int.Parse((ValueDeliverScript.gasPrice["GasPrice" + itemNumber.ToString("000")]).ToString());     //아이템 메달가격을 알아온다.
        gasPriceNum = int.Parse((ValueDeliverScript.gasPrice["GasPrice" + itemNumber.ToString("000") + "Num"]).ToString());     //아이템별 구매시 지급되는 가스(연료)의 갯수를 알아온다.
        itemNumberF = itemNumber;
        int medalRest = int.Parse(ValueDeliverScript.gameData["medalRest"].ToString());

        int gasRest = int.Parse(ValueDeliverScript.gameData["gasRest"].ToString());

        if (gasPrice > medalRest)
        {
            GoToMedalShortageWindow();
            return;
        }
        if (gasPriceNum + gasRest > 500)
        {
            GotoGasOverWindow();
            return;
        }

        GasPurchaseWindow2();
    }

    public void GasPurchaseWindow2()
    {

        int medalRest = int.Parse(ValueDeliverScript.gameData["medalRest"].ToString());
        int gasRest = int.Parse(ValueDeliverScript.gameData["gasRest"].ToString());

        medalRest -= gasPrice;
        gasRest += gasPriceNum;

        //
        GameObject.Find("GasRestLabel").GetComponent<GasRestLabelScript>().GasRest(gasPriceNum, true);
        //


        ValueDeliverScript.gameData["medalRest"] = medalRest;
        ValueDeliverScript.gameData["gasRest"] = gasRest;

        GameObject.Find("GameManager").GetComponent<GasTimeScript>().isChangeFuel = true;
        purchaseConfirmWindow.SetActive(true);
        purchaseConfirmWindow.GetComponent<purchaseScript>().Activate();
        purchaseConfirmWindow.transform.FindChild("purchaseItem").GetComponent<UISprite>().spriteName = "icon_fuel_" + (itemNumberF + 1); //가스 이미지를 아이템에 맞게 보여준다.
        purchaseConfirmWindow.transform.FindChild("purchaseItem").GetComponent<UISprite>().MakePixelPerfect(); //가스 이미지를 아이템에 맞게 보여준다.
        purchaseConfirmWindow.transform.FindChild("Script01").GetComponent<UILabel>().text = "已购买燃料。"; //가스 이미지를 아이템에 맞게 보여준다.

        gasPrice = 0;
        gasPriceNum = 0;
        itemNumberF = 0;

        GameObject.Find("GameManager").GetComponent<GasTimeScript>().MedalRecount(); //화면에 표시되는 메달양을 다시 계산하여 재표시하여줌.
        GameObject.Find("GameManager").GetComponent<GasTimeScript>().CoinRecount(); //화면에 표시되는 동전양을 다시 계산하여 재표시하여줌.

        GameObject.Find("GasRestLabel").GetComponent<GasRestLabelScript>().GasRest(0, false);   //입력된 추가 연료 갯수를 화면에 표시하기 위한 함수 호출.


        ValueDeliverScript.gameData["flightNumber"] = ValueDeliverScript.flightNumber;
        //Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
        ValueDeliverScript.SaveGameData();
        //Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
    }

    void GotoGasOverWindow()
    {
        GasOverWindow.SetActive(true);
        halfBLKPanel.SetActive(true);
        halfBLKPanel.transform.localPosition = new Vector3(halfBLKPanel.transform.localPosition.x, halfBLKPanel.transform.localPosition.y, GasOverWindow.transform.localPosition.z + 5);

    }

    void GasOverWindowYes()
    {
        GasOverWindow.SetActive(false);
        halfBLKPanel.SetActive(false);
        GasPurchaseWindow2();
    }

    void GasOverWindowNo()
    {
        gasPrice = 0;
        gasPriceNum = 0;
        itemNumberF = 0;
        GasOverWindow.SetActive(false);
        halfBLKPanel.SetActive(false);
    }

    public static void Billing(String index)
    {
        //index = "6037045" + index;
        Debug.Log("INdex ::: " + index);
        if (!CmBillingAndroid.Instance.GetActivateFlag(index))
        {
            Debug.Log(":::::::::: Index Next 001");

            CmBillingAndroid.Instance.DoBilling(true, false, index, null, "GameManager", "OnBillingResult");
            Debug.Log(":::::::::: Index Next 002");

        }
    }

    void OnBillingResult(String result)
    {
        Debug.Log("여기오냐?돈?");
        Debug.Log("BillingResult=" + result);

        String[] results = result.Split('|');
        if (CmBillingAndroid.BillingResult.CANCELLED == results[1])
        {
            CmBillingAndroid.Instance.ExitWithUI();
            return;
        }



        if (CmBillingAndroid.BillingResult.SUCCESS == results[1])
        {
            int medalPriceNum = int.Parse((ValueDeliverScript.medalPrice["MedalPrice" + itemNum.ToString("000") + "Num"]).ToString());
            int medalRest = int.Parse(ValueDeliverScript.gameData["medalRest"].ToString());
            medalRest += medalPriceNum;
            ValueDeliverScript.gameData["medalRest"] = medalRest;

            purchaseConfirmWindow.SetActive(true);
            purchaseConfirmWindow.GetComponent<purchaseScript>().Activate();
            if (itemNum > 2) itemNum += 1;

            purchaseConfirmWindow.transform.FindChild("purchaseItem").GetComponent<UISprite>().spriteName = "icon_deco_" + (itemNum); //가스 이미지를 아이템에 맞게 보여준다.
            purchaseConfirmWindow.transform.FindChild("purchaseItem").GetComponent<UISprite>().MakePixelPerfect(); //다이아몬드 이미지를 아이템에 맞게 보여준다.
            purchaseConfirmWindow.transform.FindChild("Script01").GetComponent<UILabel>().text = "已购买钻石"; //다이아몬드 이미지를 아이템에 맞게 보여준다.

            GameObject.Find("GameManager").GetComponent<GasTimeScript>().MedalRecount(); //화면에 표시되는 메달양을 다시 계산하여 재표시하여줌.
            GameObject.Find("GameManager").GetComponent<GasTimeScript>().CoinRecount(); //화면에 표시되는 동전양을 다시 계산하여 재표시하여줌.

            ValueDeliverScript.gameData["flightNumber"] = ValueDeliverScript.flightNumber;
            //Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
            ValueDeliverScript.SaveGameData();
            //Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
        }

        itemNum = 0;
    }


    public void MedalPurchaseWindow(int itemNumber)
    {
        //실제 돈을 지불하고 결제가 되는 내용을 코딩한다.//
        //                                            //
        //                                            //
        //     결제 앱을 통한 실구매 내역 코딩          //
        //                                            //
        //                                            //
        //실제 돈을 지불하고 결제가 되는 내용을 코딩한다.//

        itemNum = itemNumber;
        int medalPriceNum = int.Parse((ValueDeliverScript.medalPrice["MedalPrice" + itemNumber.ToString("000") + "Num"]).ToString());     //아이템별 구매시 지급되는 메달의 갯수를 알아온다.

        Billing(itemNumber.ToString("000")); //4100번째 줄 확인//
    }

    IEnumerator GoSkinSelectWindow()
    {
        duraBuyAlarmWindow.SetActive(false);
        halfBLKPanel.SetActive(false);

        if (friendWindow.transform.localPosition.x < 160)
        {
            bgTop.animation.Play("BGMainTopAnim01");
            friendWindow.animation.Play("FriendWindowAnim02");
            yield return new WaitForSeconds(1f);

            switch (ValueDeliverScript.flightNumber)
            {
                case 0:
                    StartCoroutine(GoToSkinSelectWindow000());
                    break;
                case 1:
                    StartCoroutine(GoToSkinSelectWindow001());
                    break;
                case 2:
                    StartCoroutine(GoToSkinSelectWindow002());
                    break;
            }
        }

        if (ResultPanel.transform.FindChild("ResultPanelLeft").localPosition.x == 0)
        {
            ResultPanel.transform.FindChild("ResultPanelLeft").animation.Play("ResultPanelLeftAnim03");
            ResultPanel.transform.FindChild("ResultPanelRight").animation.Play("ResultPanelRightAnim02");
            ResultPanel.transform.FindChild("ResultLowTab").animation.Play("ResultLowTabAnim02");
            yield return new WaitForSeconds(1f);

            switch (ValueDeliverScript.flightNumber)
            {
                case 0:
                    skinSelectWindow00.animation.Play("SkinSelectWindowAnim01");
                    yield return new WaitForSeconds(0.5f);
                    skinSelectWindow00.transform.FindChild("BackBtn").gameObject.SetActive(true);
                    break;

                case 1:
                    skinSelectWindow01.animation.Play("SkinSelectWindowAnim01");
                    yield return new WaitForSeconds(0.5f);
                    skinSelectWindow01.transform.FindChild("BackBtn").gameObject.SetActive(true);
                    break;

                case 2:
                    skinSelectWindow02.animation.Play("SkinSelectWindowAnim01");
                    yield return new WaitForSeconds(0.5f);
                    skinSelectWindow01.transform.FindChild("BackBtn").gameObject.SetActive(true);
                    break;
            }

            prepareReady.animation.Play("PrepareReadyAnim01");
            flights.transform.FindChild("MoveTF/FlightsMove").localPosition = new Vector3(ValueDeliverScript.flightNumber * -1000, 0, 0);
        }
        else
        {
            switch (ValueDeliverScript.flightNumber)
            {
                case 0:
                    flights.animation.Play("FlightsPanelAnim02");
                    skinSelectWindow00.animation.Play("SkinSelectWindowAnim01");
                    yield return new WaitForSeconds(0.5f);
                    skinSelectWindow00.transform.FindChild("BackBtn").gameObject.SetActive(true);
                    break;

                case 1:
                    flights.animation.Play("FlightsPanelAnim02");
                    skinSelectWindow01.animation.Play("SkinSelectWindowAnim01");
                    yield return new WaitForSeconds(0.5f);
                    skinSelectWindow01.transform.FindChild("BackBtn").gameObject.SetActive(true);
                    break;

                case 2:
                    flights.animation.Play("FlightsPanelAnim02");
                    skinSelectWindow02.animation.Play("SkinSelectWindowAnim01");
                    yield return new WaitForSeconds(0.5f);
                    skinSelectWindow02.transform.FindChild("BackBtn").gameObject.SetActive(true);
                    break;
            }
        }
    }

    void FlightLockOff()
    {
        int userLevel = int.Parse(ValueDeliverScript.gameData["userLevel"].ToString());
        if (ValueDeliverScript.flightWindowPosition == 1 && userLevel >= 10) //코만치 락 해제되어 코인으로 살수 있는 조건.
            FlightLockOffCoin();
        else if (ValueDeliverScript.flightWindowPosition == 1 && userLevel < 10) //코만치 락 해제되어 코인으로 살수 있는 조건.
            FlightLockOffMedal();

        if (ValueDeliverScript.flightWindowPosition == 2 && userLevel >= 20) //팬텀 락 해제되어 코인으로 살수 있는 조건.
            FlightLockOffCoin();
        else if (ValueDeliverScript.flightWindowPosition == 2 && userLevel < 20)
            FlightLockOffMedal();
    }

    void FlightLockOffCoin()
    {
        int coinRest = int.Parse(ValueDeliverScript.gameData["coinRest"].ToString());
        int upgradePoint = int.Parse(ValueDeliverScript.gameData["upgradePoint"].ToString());

        if (coinRest >= int.Parse(ValueDeliverScript.gameData["FlightLockOff" + ValueDeliverScript.flightWindowPosition.ToString("000") + "Coin"].ToString()))
        {
            coinRest -= int.Parse(ValueDeliverScript.gameData["FlightLockOff" + ValueDeliverScript.flightWindowPosition.ToString("000") + "Coin"].ToString());
            ValueDeliverScript.gameData["coinRest"] = coinRest;

            ValueDeliverScript.gameData["FlightLockOff" + ValueDeliverScript.flightWindowPosition.ToString("000")] = 2;  //락오프여부 기록을 트루로 하여 다음에도 선택할수 있게 한다.
            ValueDeliverScript.flightNumber = ValueDeliverScript.flightWindowPosition;   //비행기 락이 풀려있으면 비행기가 현재 선택되어있다고(출격가능) 표시.
            GameObject.Find("FlightLock/FlightLockMove/Dummy").transform.FindChild("FlightLockSet" + ValueDeliverScript.flightNumber.ToString("00")).gameObject.SetActive(false);
            GameObject.Find("MoveTF").GetComponent<UIPanel>().alpha = 1f;
            GameObject.Find("GameManager").GetComponent<GasTimeScript>().CoinRecount(); //화면에 표시되는 동전양을 다시 계산하여 재표시하여줌.

            StartCoroutine(CharacterSoundBuyFlight());

            upgradePoint += 3;
            ValueDeliverScript.gameData["upgradePoint"] = upgradePoint;
            upgradePointWindow.transform.FindChild("PointAdd").GetComponent<UILabel>().text = "X 3";
            ShowUpgradePointWindow();
            flightUpointSetScript.RedrawStatePoint();
            HangerControl hangerCon = GameObject.Find("GameManager").GetComponent<HangerControl>();
        }
        else
            GoToCoinShortageWindow();

        ValueDeliverScript.gameData["flightNumber"] = ValueDeliverScript.flightNumber;
        //Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
        ValueDeliverScript.SaveGameData();
        //Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
    }

    void FlightLockOffMedal()
    {
        int medalRest = int.Parse(ValueDeliverScript.gameData["medalRest"].ToString());
        int upgradePoint = int.Parse(ValueDeliverScript.gameData["upgradePoint"].ToString());

        if (medalRest >= int.Parse(ValueDeliverScript.gameData["FlightLockOff" + ValueDeliverScript.flightWindowPosition.ToString("000") + "Medal"].ToString()))
        {
            medalRest -= int.Parse(ValueDeliverScript.gameData["FlightLockOff" + ValueDeliverScript.flightWindowPosition.ToString("000") + "Medal"].ToString());
            ValueDeliverScript.gameData["medalRest"] = medalRest;
            ValueDeliverScript.gameData["FlightLockOff" + ValueDeliverScript.flightWindowPosition.ToString("000")] = 2;  //락오프여부 기록을 트루로 하여 다음에도 선택할수 있게 한다.
            ValueDeliverScript.flightNumber = ValueDeliverScript.flightWindowPosition;   //비행기 락이 풀려있으면 비행기가 현재 선택되어있다고(출격가능) 표시.
            GameObject.Find("FlightLock/FlightLockMove/Dummy").transform.FindChild("FlightLockSet" + ValueDeliverScript.flightNumber.ToString("00")).gameObject.SetActive(false);
            GameObject.Find("MoveTF").GetComponent<UIPanel>().alpha = 1f;
            GameObject.Find("GameManager").GetComponent<GasTimeScript>().MedalRecount(); //화면에 표시되는 동전양을 다시 계산하여 재표시하여줌.
            StartCoroutine(CharacterSoundBuyFlight());

            upgradePoint += 3;
            ValueDeliverScript.gameData["upgradePoint"] = upgradePoint;

            upgradePointWindow.transform.FindChild("PointAdd").GetComponent<UILabel>().text = "X 3";
            ShowUpgradePointWindow();

            flightUpointSetScript.RedrawStatePoint();
            HangerControl hangerCon = GameObject.Find("GameManager").GetComponent<HangerControl>();
        }
        else
        {
            GoToMedalShortageWindow();
        }
        ValueDeliverScript.gameData["flightNumber"] = ValueDeliverScript.flightNumber;
        //Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
        ValueDeliverScript.SaveGameData();
        //Debug.Log("비행기 번호 :::: " + ValueDeliverScript.gameData["flightNumber"].ToString());
    }

    IEnumerator CharacterSoundBuyFlight()
    {
        int activeOper = int.Parse(ValueDeliverScript.gameData["activeOper"].ToString());
        yield return new WaitForSeconds(0.3f);
        CharacterMsgSndConScript characterMsgSndCon;
        characterMsgSndCon = GameObject.Find("CharacterMsgSndCon").GetComponent<CharacterMsgSndConScript>();
        characterMsgSndCon.BuyFlight(activeOper);
    }

    void ResultSpecialAttackOnAnimation()
    {
        if (!ValueDeliverScript.isSpecialAnimation)
            StartCoroutine(SpecialAnimation());
        else
        {
            Debug.Log("Income2?????????");
            GameObject.Find("SpecialInfo/SpecialAttackOn").transform.localScale = new Vector3(1, 1, 1);
            GameObject.Find("SpecialAttackOnText").transform.localScale = new Vector3(52, 46, 1);   //스페셜 어택 발동 문자 스케일 키워서 표시.
            GameObject.Find("GameSpecialStart").transform.localPosition = new Vector3(389, -281, 0);
            GameObject.Find("ResultLowTab/AttackBtn/GameStart").GetComponent<UISprite>().enabled = false;

            GameObject.Find("PrepareBtn/GameStart").GetComponent<UISprite>().spriteName = "Btn_SpecialGameReady_00";
            GameObject.Find("PrepareBtn/GameStart").GetComponent<UIImageButton>().normalSprite = "Btn_SpecialGameReady_00";
            GameObject.Find("PrepareBtn/GameStart").GetComponent<UIImageButton>().hoverSprite = "Btn_SpecialGameReady_00";
            GameObject.Find("PrepareBtn/GameStart").GetComponent<UIImageButton>().pressedSprite = "Btn_SpecialGameReady_01";

            GameObject.Find("AttackReady/AttackBtn/GameStart").GetComponent<UISprite>().spriteName = "Btn_SpecialGame_00";
            GameObject.Find("AttackReady/AttackBtn/GameStart").GetComponent<UIImageButton>().normalSprite = "Btn_SpecialGame_00";
            GameObject.Find("AttackReady/AttackBtn/GameStart").GetComponent<UIImageButton>().hoverSprite = "Btn_SpecialGame_00";
            GameObject.Find("AttackReady/AttackBtn/GameStart").GetComponent<UIImageButton>().pressedSprite = "Btn_SpecialGame_01";
        }
    }

    IEnumerator SpecialAnimation()
    {
        while (!isRLowTabAnim) yield return new WaitForSeconds(0.1f);

        GameObject.Find("PrepareBtn/GameStart").GetComponent<UISprite>().spriteName = "Btn_SpecialGameReady_00";
        GameObject.Find("PrepareBtn/GameStart").GetComponent<UIImageButton>().normalSprite = "Btn_SpecialGameReady_00";
        GameObject.Find("PrepareBtn/GameStart").GetComponent<UIImageButton>().hoverSprite = "Btn_SpecialGameReady_00";
        GameObject.Find("PrepareBtn/GameStart").GetComponent<UIImageButton>().pressedSprite = "Btn_SpecialGameReady_01";

        GameObject.Find("AttackReady/AttackBtn/GameStart").GetComponent<UISprite>().spriteName = "Btn_SpecialGame_00";
        GameObject.Find("AttackReady/AttackBtn/GameStart").GetComponent<UIImageButton>().normalSprite = "Btn_SpecialGame_00";
        GameObject.Find("AttackReady/AttackBtn/GameStart").GetComponent<UIImageButton>().hoverSprite = "Btn_SpecialGame_00";
        GameObject.Find("AttackReady/AttackBtn/GameStart").GetComponent<UIImageButton>().pressedSprite = "Btn_SpecialGame_01";

        yield return new WaitForSeconds(3f);

        GameObject pilotLevelUpWindow = GameObject.Find("Windows/PilotLevelUpWindow");
        GameObject upgradePointWindow = GameObject.Find("Windows/UpgradePointWindow");

        //while (true)
        //{
        //    if (pilotLevelUpWindow.activeSelf == false && upgradePointWindow.activeSelf == false) break;

        //    yield return new WaitForSeconds(0.1f);
        //}

        GameObject.Find("ResultLowTab").animation.Play("SpecialAnim01");
        ValueDeliverScript.isSpecialAnimation = true;
        yield return new WaitForSeconds(1f);

        GameObject.Find("AttackReady/AttackBtn/GameStart").GetComponent<UISprite>().spriteName = "Btn_SpecialGame_00";
        GameObject.Find("AttackReady/AttackBtn/GameStart").GetComponent<UIImageButton>().normalSprite = "Btn_SpecialGame_00";
        GameObject.Find("AttackReady/AttackBtn/GameStart").GetComponent<UIImageButton>().hoverSprite = "Btn_SpecialGame_00";
        GameObject.Find("AttackReady/AttackBtn/GameStart").GetComponent<UIImageButton>().pressedSprite = "Btn_SpecialGame_01";
        GameObject.Find("ResultLowTab/AttackBtn/GameStart").GetComponent<UISprite>().enabled = false;
    }

    string friendUserId;
    GameObject fuelSendWindow;
    GameObject friendTab;
    public void ShowFuelSendWindow(string userId, string nickName, GameObject fromFriendTab)
    {
        friendTab = fromFriendTab;
        fuelSendWindow = GameObject.Find("Windows").transform.FindChild("FuelSendWindow").gameObject;
        fuelSendWindow.SetActive(true);
        fuelSendWindow.transform.FindChild(nickName + "님께 카카오톡으로 연료를 발송하시겠습니까?");
        friendUserId = userId;
        halfBLKPanel.SetActive(true);
        halfBLKPanel.transform.localPosition = new Vector3(halfBLKPanel.transform.localPosition.x, halfBLKPanel.transform.localPosition.y, fuelSendWindow.transform.localPosition.z + 5);
    }

    void FuelSendWindowYes()
    {
        friendTab.transform.FindChild("GasStatusOn").GetComponent<UISprite>().spriteName = "Btn_FriendSend_02";
        friendTab.transform.FindChild("GasStatusOn").GetComponent<UIImageButton>().normalSprite = "Btn_FriendSend_02";
        friendTab.transform.FindChild("GasStatusOn").GetComponent<UIImageButton>().hoverSprite = "Btn_FriendSend_02";
        friendTab.transform.FindChild("GasStatusOn").GetComponent<UIImageButton>().pressedSprite = "Btn_FriendSend_02";
        friendUserId = "";
        halfBLKPanel.SetActive(false);
        fuelSendWindow.SetActive(false);
    }

    void FuelSendWindowCancel()
    {
        friendTab.transform.FindChild("GasStatusOn").GetComponent<UISprite>().spriteName = "Btn_FriendSend_00";
        friendTab.transform.FindChild("GasStatusOn").GetComponent<UIImageButton>().normalSprite = "Btn_FriendSend_00";
        friendTab.transform.FindChild("GasStatusOn").GetComponent<UIImageButton>().hoverSprite = "Btn_FriendSend_00";
        friendTab.transform.FindChild("GasStatusOn").GetComponent<UIImageButton>().pressedSprite = "Btn_FriendSend_01";
        halfBLKPanel.SetActive(false);
        fuelSendWindow.SetActive(false);
    }

    public GameObject FriendInfoWindow;

    public void ShowFriendInfoWindow(RankDataS friendInfo)
    {
        string icon01Name = "";
        string icon02Name = "";
        string icon03Name = "";
        string icon04Name = "";
        string icon05Name = "";

        switch (friendInfo.Flight)
        {
            case "0":
                icon01Name = "Fokker";
                break;
            case "1":
                icon01Name = "Comanche";
                break;
            case "2":
                icon01Name = "Phantom";
                break;
        }

        switch (friendInfo.Supporter)
        {
            case "1":
                icon02Name = "icon_operator_1";
                break;
            case "2":
                icon02Name = "icon_operator_4";
                break;
            case "3":
                icon02Name = "icon_operator_2";
                break;
            case "4":
                icon02Name = "icon_operator_3";
                break;
        }

        switch (friendInfo.Bomb)
        {
            case "1":
                icon03Name = "icon_equip_bomb_sma_2";
                break;
            case "5":
                icon03Name = "icon_equip_bomb_sma_6";
                break;
        }

        switch (friendInfo.Rein)
        {
            case "1":
                icon04Name = "icon_equip_force_small_1";
                break;
            case "2":
                icon04Name = "icon_equip_force_small_2";
                break;
            case "3":
                icon04Name = "icon_equip_force_small_3";
                break;
            case "4":
                icon04Name = "icon_equip_force_small_4";
                break;
            case "5":
                icon04Name = "icon_equip_force_small_5";
                break;
            case "6":
                icon04Name = "icon_equip_force_small_6";
                break;
            case "7":
                icon04Name = "icon_equip_force_small_7";
                break;
            case "8":
                icon04Name = "icon_equip_boost_small_1";
                break;
        }

        switch (friendInfo.Assist)
        {
            case "1":
                icon05Name = "icon_equip_sub_small_1";
                break;
            case "2":
                icon05Name = "icon_equip_sub_small_2";
                break;
            case "3":
                icon05Name = "icon_equip_sub_small_3";
                break;
            case "4":
                icon05Name = "icon_equip_sub_small_4";
                break;
            case "5":
                icon05Name = "icon_equip_boost_small_7";
                break;
            case "6":
                icon05Name = "icon_equip_boost_small_6";
                break;
        }

        FriendInfoWindow.SetActive(true);
        if (icon02Name == "")
            FriendInfoWindow.transform.FindChild("Items/Item002/Icon2").gameObject.SetActive(false);
        else
            FriendInfoWindow.transform.FindChild("Items/Item002/Icon2").gameObject.SetActive(true);

        if (icon03Name == "")
            FriendInfoWindow.transform.FindChild("Items/Item003/Icon3").gameObject.SetActive(false);
        else
            FriendInfoWindow.transform.FindChild("Items/Item003/Icon3").gameObject.SetActive(true);

        if (icon04Name == "")
            FriendInfoWindow.transform.FindChild("Items/Item003/Icon4").gameObject.SetActive(false);
        else
            FriendInfoWindow.transform.FindChild("Items/Item003/Icon4").gameObject.SetActive(true);

        if (icon05Name == "")
            FriendInfoWindow.transform.FindChild("Items/Item003/Icon5").gameObject.SetActive(false);
        else
            FriendInfoWindow.transform.FindChild("Items/Item003/Icon5").gameObject.SetActive(true);

        FriendInfoWindow.transform.FindChild("UserName").GetComponent<UILabel>().text = friendInfo.NickName;
        FriendInfoWindow.transform.FindChild("Items/Item001/Icon1").GetComponent<UISprite>().spriteName = icon01Name + (int.Parse(friendInfo.Skin) + 1).ToString("000") + "Fix";
        FriendInfoWindow.transform.FindChild("Items/Item001/Icon1").GetComponent<UISprite>().MakePixelPerfect();
        FriendInfoWindow.transform.FindChild("Items/Item002/Icon2").GetComponent<UISprite>().spriteName = icon02Name;
        FriendInfoWindow.transform.FindChild("Items/Item003/Icon3").GetComponent<UISprite>().spriteName = icon03Name;
        FriendInfoWindow.transform.FindChild("Items/Item003/Icon4").GetComponent<UISprite>().spriteName = icon04Name;
        FriendInfoWindow.transform.FindChild("Items/Item003/Icon5").GetComponent<UISprite>().spriteName = icon05Name;
        FriendInfoWindow.transform.FindChild("Script02").GetComponent<UILabel>().text = friendInfo.TWeekScore;

        halfBLKPanel.SetActive(true);
        halfBLKPanel.transform.localPosition = new Vector3(halfBLKPanel.transform.localPosition.x, halfBLKPanel.transform.localPosition.y, FriendInfoWindow.transform.localPosition.z + 5);
    }

    void CloseFriendInfoWindow()
    {
        FriendInfoWindow.SetActive(false);
        halfBLKPanel.SetActive(false);
    }

    public void ShotFriendshipPoint()
    {
        prepareReady.animation.Play("PrepareReadyAnim03_2");

        Transform point100 = prepareReady.transform.FindChild("OperMessage/FriendshipPoint/Point100Amount");
        point100.localScale = new Vector3(0, point100.localScale.y, point100.localScale.z);
        Transform pointIcn01 = prepareReady.transform.FindChild("OperMessage/FriendshipPoint/PointIcn01");
        pointIcn01.localScale = new Vector3(0, pointIcn01.localScale.y, pointIcn01.localScale.z);
    }

    public void ShowUpgradePointWindow()
    {
        upgradePointWindow.SetActive(true);
        halfBLKPanel.SetActive(true);
        halfBLKPanel.transform.localPosition = new Vector3(halfBLKPanel.transform.localPosition.x, halfBLKPanel.transform.localPosition.y, upgradePointWindow.transform.localPosition.z + 5);

    }

    IEnumerator NoClickUpgradePointWindow()
    {
        upgradePointWindow.transform.FindChild("YesBtn").GetComponent<BoxCollider>().enabled = false;
        yield return new WaitForSeconds(2f);
        upgradePointWindow.transform.FindChild("YesBtn").GetComponent<BoxCollider>().enabled = true;
    }

    public void CloseUpgradePointWindow()
    {
        upgradePointWindow.SetActive(false);
        halfBLKPanel.SetActive(false);
    }

    public GameObject RequestWindow;
    public GameObject RequestFailWindow;
    string RequestUserId;

    public void GotoRequestWindow(string userId)
    {
        RequestUserId = userId;
        RequestWindow.SetActive(true);
        halfBLKPanel.SetActive(true);
        halfBLKPanel.transform.localPosition = new Vector3(halfBLKPanel.transform.localPosition.x, halfBLKPanel.transform.localPosition.y, RequestWindow.transform.localPosition.z + 5);
    }

    public void RequestWindowYes()
    {
        RequestWindow.SetActive(false);
        halfBLKPanel.SetActive(false);
    }

    public void RequestWindowCancel()
    {
        RequestWindow.SetActive(false);
        halfBLKPanel.SetActive(false);
    }

    public void GotoRequestFailWindow(string text)
    {
        RequestFailWindow.transform.FindChild("Msg").GetComponent<UILabel>().text = text;
        RequestFailWindow.SetActive(true);
        halfBLKPanel.SetActive(true);
        halfBLKPanel.transform.localPosition = new Vector3(halfBLKPanel.transform.localPosition.x, halfBLKPanel.transform.localPosition.y, RequestFailWindow.transform.localPosition.z + 5);
    }

    public void RequestFailWindowYes()
    {
        RequestFailWindow.SetActive(false);
        halfBLKPanel.SetActive(false);
    }

    public void UnregiLoadLevel()
    {
        StartCoroutine(UnregiLoadLevel2());
    }

    IEnumerator UnregiLoadLevel2()
    {
        yield return new WaitForSeconds(1f);
        Application.LoadLevel("Loading");
    }

    public void GotoFriendLockWindow()
    {
        GameObject FriendLockWindow = GameObject.Find("Window/FriendLockWindow");
        FriendLockWindow.SetActive(true);
        halfBLKPanel.SetActive(true);
        halfBLKPanel.transform.localPosition = new Vector3(halfBLKPanel.transform.localPosition.x, halfBLKPanel.transform.localPosition.y, FriendLockWindow.transform.localPosition.z + 5);
    }

    public void CloseFriendLockWindow()
    {
        GameObject FriendLockWindow = GameObject.Find("Window/FriendLockWindow");
        FriendLockWindow.SetActive(false);
        halfBLKPanel.SetActive(false);
    }

    public IEnumerator GuestPlayOut()
    {
        ValueDeliverScript.isGuestPlay = false;
        yield return new WaitForSeconds(2f);
        Application.LoadLevel("Loading");
    }

    public void GotoMessageOnFailWindow()
    {
        GameObject Window = GameObject.Find("Windows").transform.FindChild("MessageOnFailWindow").gameObject;
        Window.SetActive(true);
        halfBLKPanel.SetActive(true);
        halfBLKPanel.transform.localPosition = new Vector3(halfBLKPanel.transform.localPosition.x, halfBLKPanel.transform.localPosition.y, Window.transform.localPosition.z + 5);
    }

    public void MessageOnFailWindowYes()
    {
        GameObject Window = GameObject.Find("Windows").transform.FindChild("MessageOnFailWindow").gameObject;
        Window.SetActive(false);
        halfBLKPanel.SetActive(false);
    }

    public void GotoFuelFailWindow()
    {
        GameObject Window = GameObject.Find("Windows").transform.FindChild("FuelFailWindow").gameObject;
        Window.SetActive(true);
        halfBLKPanel.SetActive(true);
        halfBLKPanel.transform.localPosition = new Vector3(halfBLKPanel.transform.localPosition.x, halfBLKPanel.transform.localPosition.y, Window.transform.localPosition.z + 5);
    }

    public void FuelFailWindowYes()
    {
        GameObject Window = GameObject.Find("Windows").transform.FindChild("FuelFailWindow").gameObject;
        Window.SetActive(false);
        halfBLKPanel.SetActive(false);

    }

    public GameObject RewardInvite01Window;
    public GameObject RewardInvite02Window;
    public GameObject RewardInvite03Window;
    public GameObject RewardInvite04Window;

    public void GotoRewardInvite01Window()
    {
        RewardInvite01Window.SetActive(true);
        halfBLKPanel.SetActive(true);
        halfBLKPanel.transform.localPosition = new Vector3(halfBLKPanel.transform.localPosition.x, halfBLKPanel.transform.localPosition.y, RewardInvite01Window.transform.localPosition.z + 5);
    }

    public void CloseReward01Window()
    {
        RewardInvite01Window.SetActive(false);
        halfBLKPanel.SetActive(false);
    }

    public void GotoRewardInvite02Window()
    {
        RewardInvite02Window.SetActive(true);
        halfBLKPanel.SetActive(true);
        halfBLKPanel.transform.localPosition = new Vector3(halfBLKPanel.transform.localPosition.x, halfBLKPanel.transform.localPosition.y, RewardInvite02Window.transform.localPosition.z + 5);
    }

    public void CloseReward02Window()
    {
        RewardInvite02Window.SetActive(false);
        halfBLKPanel.SetActive(false);
    }

    public void GotoRewardInvite03Window()
    {
        RewardInvite03Window.SetActive(true);
        halfBLKPanel.SetActive(true);
        halfBLKPanel.transform.localPosition = new Vector3(halfBLKPanel.transform.localPosition.x, halfBLKPanel.transform.localPosition.y, RewardInvite03Window.transform.localPosition.z + 5);
    }

    public void CloseReward03Window()
    {
        RewardInvite03Window.SetActive(false);
        halfBLKPanel.SetActive(false);
    }

    public void GotoRewardInvite04Window()
    {
        RewardInvite04Window.SetActive(true);
        halfBLKPanel.SetActive(true);
        halfBLKPanel.transform.localPosition = new Vector3(halfBLKPanel.transform.localPosition.x, halfBLKPanel.transform.localPosition.y, RewardInvite04Window.transform.localPosition.z + 5);
    }

    public void CloseReward04Window()
    {
        RewardInvite04Window.SetActive(false);
        halfBLKPanel.SetActive(false);
    }


    public void ShowUiInfo01()
    {
        GameObject.Find("Windows").transform.FindChild("UiInfo01Window").gameObject.SetActive(true);
        halfBLKPanel.SetActive(true);
        halfBLKPanel.transform.localPosition = new Vector3(halfBLKPanel.transform.localPosition.x, halfBLKPanel.transform.localPosition.y, RewardInvite04Window.transform.localPosition.z + 10);
    }

    public void CloseUiInfo01()
    {
        GameObject.Find("UiInfo01Window").SetActive(false);
        halfBLKPanel.SetActive(false);
    }

    public void ShowUiInfo02()
    {
        GameObject.Find("Windows").transform.FindChild("UiInfo02Window").gameObject.SetActive(true);
        halfBLKPanel.SetActive(true);
        halfBLKPanel.transform.localPosition = new Vector3(halfBLKPanel.transform.localPosition.x, halfBLKPanel.transform.localPosition.y, RewardInvite04Window.transform.localPosition.z + 10);
    }

    public void CloseUiInfo02()
    {
        GameObject.Find("UiInfo02Window").SetActive(false);
        halfBLKPanel.SetActive(false);
    }

    public void ShowUiInfo03()
    {
        GameObject.Find("Windows").transform.FindChild("UiInfo03Window").gameObject.SetActive(true);
        halfBLKPanel.SetActive(true);
        halfBLKPanel.transform.localPosition = new Vector3(halfBLKPanel.transform.localPosition.x, halfBLKPanel.transform.localPosition.y, RewardInvite04Window.transform.localPosition.z + 10);
    }

    public void CloseUiInfo03()
    {
        GameObject.Find("UiInfo03Window").SetActive(false);
        halfBLKPanel.SetActive(false);
    }


    public void AllMessageAccept() { }

    public void GotoRequestNotOnTimewindow(string text) { }

    public void CloseRequestNotOnTimewindow() { }

    public void GotoRequestuserRejectwindow(string text) { }

    public void CloseRequestuserRejectwindow() { }
}

//델리게이트는 이쪽으로 모아둔다.
public delegate void NextFunc();