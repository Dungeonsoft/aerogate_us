using UnityEngine;
using System.Collections;
using System.Text;
using System.Security;

public class GetUserUniNumber : MonoBehaviour 
{
	public string GetUserInfoUrl = "http://leessoda.cafe24.com/get_userunique.php";
	public string result;
	private string secretKey = "12345"; 
	public GameObject newIDWindow;
	public GameObject server;
	
	
	IEnumerator GetUserUniqueNumber()
	{
		string userUnique = SystemInfo.deviceUniqueIdentifier;
		string hash = Md5Sum(userUnique + secretKey).ToLower();
				
		yield return new WaitForSeconds(0.2f);
		
		WWWForm form = new WWWForm();
		
		form.AddField("Unique_name",userUnique);
		form.AddField("hash",hash);
		
		WWW www = new WWW(GetUserInfoUrl,form);
		yield return www;
		
		result = www.text;
		
		NewIDRecord.userNumber = int.Parse(result);
		
		PlayerPrefs.SetInt("UserUnique", NewIDRecord.userNumber);
		
		int userNumberUnique = PlayerPrefs.GetInt("UserUnique");
		
		Debug.Log("User Number is  " + userNumberUnique);
		
		server.SendMessage("Initializing");
	}
	
	
	public string Md5Sum(string input)
	{
    	// step 1, calculate MD5 hash from input
    	System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create();
    	byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
    	byte[] hash = md5.ComputeHash(inputBytes);
 
    	// step 2, convert byte array to hex string
    	StringBuilder sb = new StringBuilder();
    	for (int i = 0; i < hash.Length; i++)
    	{
    	    sb.Append(hash[i].ToString("X2"));
    	}
    	return sb.ToString();
	}
	
}
