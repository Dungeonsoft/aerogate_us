using UnityEngine;
using System.Collections;
using System.Text;
using System.Security;
using System;

public class GetUserGameInfo : MonoBehaviour
{

    public string GetUserNickNameUrl = "http://leessoda.cafe24.com/get_usergamename.php";
    public string GetUserGameItemUrl = "http://leessoda.cafe24.com/get_usergameitem.php";
    public string GetUserGameInfoUrl = "http://leessoda.cafe24.com/get_usergameinfo.php";
    public string GetRankingInfoUrl = "http://leessoda.cafe24.com/get_ranking.php";
    public string GetMailInfoUrl = "http://leessoda.cafe24.com/get_mailinfo.php";
    public string GetSupportInfoUrl = "http://leessoda.cafe24.com/get_itemsupport.php";
    public string GetStrongInfoUrl = "http://leessoda.cafe24.com/get_itemstrong.php";
    public string GetNuclearInfoUrl = "http://leessoda.cafe24.com/get_itemnuclear.php";
    public string GetBoostInfoUrl = "http://leessoda.cafe24.com/get_itemboost.php";
    public string GetGameSpecialUrl = "http://leessoda.cafe24.com/get_gamespecial.php";
    public string GetGameSpecialOnUrl = "http://leessoda.cafe24.com/get_gamespecialon.php";
    public string GetGameSpecialCountUrl = "http://leessoda.cafe24.com/get_gamespecialcount.php";
    public string GetPhantomInfoUrl = "http://leessoda.cafe24.com/get_phantom.php";
    public string GetPhantomLockInfoUrl = "http://leessoda.cafe24.com/get_phantomlock.php";
    public string GetPhantomSkinInfoUrl = "http://leessoda.cafe24.com/get_phantomskin.php";
    public string GetFokkerInfoUrl = "http://leessoda.cafe24.com/get_fokker.php";
    public string GetFokkerLockInfoUrl = "http://leessoda.cafe24.com/get_fokkerlock.php";
    public string GetFokkerSkinInfoUrl = "http://leessoda.cafe24.com/get_fokkerskin.php";
    public string GetComancheInfoUrl = "http://leessoda.cafe24.com/get_comanche.php";
    public string GetComancheLockInfoUrl = "http://leessoda.cafe24.com/get_comanchelock.php";
    public string GetComancheSKinInfoUrl = "http://leessoda.cafe24.com/get_comancheskin.php";
    public string GetAirCraftInfoUrl = "http://leessoda.cafe24.com/get_aircraftinfo.php";
    public string SetUserNickNameUrl = "http://leessoda.cafe24.com/set_usernickname.php";
    public string GetFriendScoreURL = "http://leessoda.cafe24.com/get_friendscore.php";
    public string GetFriendNameURL = "http://leessoda.cafe24.com/get_friendname.php";

    private string secretKey = "12345";
    string result;

    public int userUniqueNum;
    public string[] serverGameItem;
    public string[] serverGameInfo;
    public string[] serverRakingInfo;
    public string[] serverMailInfo;
    public string[] serverItemSupport;
    public string[] serverItemStrong;
    public string[] serverItemNuclear;
    public string[] serverItemBoost;
    public string[] serverGameSpecial;
    public string[] serverGameSpecialOn;
    public string[] serverGameSpecialCount;
    public string[] serverAircraft_Phantom;
    public string[] serverAircraft_PhantomLock;
    public string[] serverAircraft_PhantomSkin;
    public string[] serverAircraft_Fokker;
    public string[] serverAircraft_FokkerLock;
    public string[] serverAircraft_FokkerSkin;
    public string[] serverAircraft_Comanche;
    public string[] serverAircraft_ComancheLock;
    public string[] serverAircraft_ComancheSkin;
    public string[] serverAircraftInfo;


    void Start()
    {
        userUniqueNum = PlayerPrefs.GetInt("UserUnique");

    }

    IEnumerator GetGameInfo()
    {
        ForKaKao.instance._ui.text += "GetGameInfo000_";
        yield return StartCoroutine(GetUserNickName());
        ForKaKao.instance._ui.text += "GetGameInfo001_";
        yield return StartCoroutine(GetUserGameItem());
        ForKaKao.instance._ui.text += "GetGameInfo002_";
        yield return StartCoroutine(GetUserGameServerInfo());
        ForKaKao.instance._ui.text += "GetGameInfo003_";
        yield return StartCoroutine(GetRanking());
        ForKaKao.instance._ui.text += "GetGameInfo004_";
        yield return StartCoroutine(GetMailBox());
        ForKaKao.instance._ui.text += "GetGameInfo005_";
        yield return StartCoroutine(GetItemSupport());
        ForKaKao.instance._ui.text += "GetGameInfo006_";
        yield return StartCoroutine(GetItemStrong());
        ForKaKao.instance._ui.text += "GetGameInfo007_";
        yield return StartCoroutine(GetItemNuclear());
        ForKaKao.instance._ui.text += "GetGameInfo008_";
        yield return StartCoroutine(GetItemBoost());
        ForKaKao.instance._ui.text += "GetGameInfo009_";
        yield return StartCoroutine(GetGameSpecial());
        ForKaKao.instance._ui.text += "GetGameInfo010_";
        yield return StartCoroutine(GetGameSpecialOn());
        ForKaKao.instance._ui.text += "GetGameInfo011_";
        yield return StartCoroutine(GetGameSpecialCount());
        ForKaKao.instance._ui.text += "GetGameInfo012_";
        yield return StartCoroutine(GetPhantom());
        ForKaKao.instance._ui.text += "GetGameInfo013_";
        yield return StartCoroutine(GetPhantomLock());
        ForKaKao.instance._ui.text += "GetGameInfo014_";
        yield return StartCoroutine(GetPhantomSkin());
        ForKaKao.instance._ui.text += "GetGameInfo015_";
        yield return StartCoroutine(GetFokker());
        ForKaKao.instance._ui.text += "GetGameInfo016_";
        yield return StartCoroutine(GetFokkerLock());
        ForKaKao.instance._ui.text += "GetGameInfo017_";
        yield return StartCoroutine(GetFokkerSkin());
        ForKaKao.instance._ui.text += "GetGameInfo018_";
        yield return StartCoroutine(GetComanche());
        ForKaKao.instance._ui.text += "GetGameInfo019_";
        yield return StartCoroutine(GetComancheLock());
        ForKaKao.instance._ui.text += "GetGameInfo020_";
        yield return StartCoroutine(GetComancheSkin());
        ForKaKao.instance._ui.text += "GetGameInfo021_";
        yield return StartCoroutine(GetAirCraft());
        ForKaKao.instance._ui.text += "GetGameInfo022_";
        yield return StartCoroutine(GetFriendScoreInfo());
        ForKaKao.instance._ui.text += "_Into_SetPlayerDB_";
        yield return StartCoroutine(SetPlayerDB());
        ForKaKao.instance._ui.text += "GetGameInfo024";

        Debug.Log("Game Info Update Complete !!!!!");


    }
    IEnumerator GetGameInfo2()
    {
        yield return StartCoroutine(GetUserNickName());
        yield return StartCoroutine(GetUserGameItem());
        yield return StartCoroutine(GetUserGameServerInfo());
        yield return StartCoroutine(GetRanking());
        yield return StartCoroutine(GetMailBox());
        yield return StartCoroutine(GetItemSupport());
        yield return StartCoroutine(GetItemStrong());
        yield return StartCoroutine(GetItemNuclear());
        yield return StartCoroutine(GetItemBoost());
        yield return StartCoroutine(GetGameSpecial());
        yield return StartCoroutine(GetGameSpecialOn());
        yield return StartCoroutine(GetGameSpecialCount());
        yield return StartCoroutine(GetPhantom());
        yield return StartCoroutine(GetPhantomLock());
        yield return StartCoroutine(GetPhantomSkin());
        yield return StartCoroutine(GetFokker());
        yield return StartCoroutine(GetFokkerLock());
        yield return StartCoroutine(GetFokkerSkin());
        yield return StartCoroutine(GetComanche());
        yield return StartCoroutine(GetComancheLock());
        yield return StartCoroutine(GetComancheSkin());
        yield return StartCoroutine(GetAirCraft());
        yield return StartCoroutine(GetFriendScoreInfo());
        yield return StartCoroutine(SetPlayerDB2());

        Debug.Log("Game Info Update Complete !!!!!");
        //yield return new WaitForSeconds(0.5f);
    }
	 IEnumerator GetGameInfo3()
    {
        yield return StartCoroutine(GetFriendScoreInfo());
        yield return StartCoroutine(LoadHanger());
        Debug.Log("Game Info With Ranking Data Complete !!!!!");
        //yield return new WaitForSeconds(0.5f);
    }
    IEnumerator GetUserNickName()
    {
        ForKaKao.instance._ui.text += "GetUserNickName00 ";

        yield return null;
        ForKaKao.instance._ui.text += "GetUserNickName_0 ";

        string hash = Md5Sum(secretKey).ToLower();
        ForKaKao.instance._ui.text += "GetUserNickName01 ";

        int userUniqueNumber = userUniqueNum;
        ForKaKao.instance._ui.text += "GetUserNickName02 ";

        WWWForm form = new WWWForm();
        ForKaKao.instance._ui.text += "GetUserNickName03 ";

        form.AddField("hash", hash);
        ForKaKao.instance._ui.text += "GetUserNickName04 ";

        form.AddField("User_Number", userUniqueNumber);
        ForKaKao.instance._ui.text += "GetUserNickName05 ";


        WWW www = new WWW(GetUserNickNameUrl, form);
        ForKaKao.instance._ui.text += "GetUserNickName06 ";

        yield return www;
        ForKaKao.instance._ui.text += "GetUserNickName07 ";


        result = www.text;
        ForKaKao.instance._ui.text += "GetUserNickName08 ";


        Debug.Log("User Nick Name is " + result);
        Debug.Log("UserNickName Info Get");
        ValueDeliverScript.playerName = result;

        yield return StartCoroutine(SetUserNickName());


    }

    IEnumerator SetUserNickName()
    {
        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = userUniqueNum;
        string userName = ValueDeliverScript.playerName;
        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);
        form.AddField("User_Name", userName);

        WWW www = new WWW(SetUserNickNameUrl, form);
        yield return www;

        result = www.text;
        Debug.Log("============================ " + result + " =====================================");
        if (result == "NickNameInsert")
        {
            Debug.Log("============================ Nick Name Insert Complete =====================================");
            Debug.Log("It's Same!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        }
    }
    IEnumerator GetFriendScoreInfo()
    {
        yield return StartCoroutine(GetFriendNameInfo());

        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = userUniqueNum;

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);

        WWW www = new WWW(GetFriendScoreURL, form);
        yield return www;

        result = www.text;
        ValueDeliverScript.serverFriendScoreInfo = result.Split(new char[] { '?' });

        Debug.Log("============= Get Friender Score Info Get =============");

    }

    IEnumerator GetFriendNameInfo()
    {
        yield return null;
        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = userUniqueNum;

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);

        WWW www = new WWW(GetFriendNameURL, form);
        yield return www;

        result = www.text;
        ValueDeliverScript.serverFriendNameInfo = result.Split(new char[] { '?' });

        Debug.Log("============= Get Friender Name Info Get =============");

    }

    IEnumerator GetUserGameItem()
    {
        yield return null;
        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = userUniqueNum;

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);

        WWW www = new WWW(GetUserGameItemUrl, form);
        yield return www;

        result = www.text;

        serverGameItem = result.Split(new char[] { '?' });


        Debug.Log("UserGameItem Info Get");

    }

    IEnumerator GetUserGameServerInfo()
    {
        yield return null;
        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = userUniqueNum;

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);

        WWW www = new WWW(GetUserGameInfoUrl, form);
        yield return www;

        result = www.text;

        serverGameInfo = result.Split(new char[] { '?' });

        Debug.Log("UserGame Info Get");

    }

    IEnumerator GetRanking()
    {
        yield return null;
        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = userUniqueNum;

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);

        WWW www = new WWW(GetRankingInfoUrl, form);
        yield return www;

        result = www.text;

        serverRakingInfo = result.Split(new char[] { '?' });

        Debug.Log("Ranking Info Get");

    }

    IEnumerator GetMailBox()
    {
        yield return null;
        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = userUniqueNum;

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);

        WWW www = new WWW(GetMailInfoUrl, form);
        yield return www;

        result = www.text;

        serverMailInfo = result.Split(new char[] { '?' });

        Debug.Log("Mail Info Get");
    }

    IEnumerator GetItemSupport()
    {
        yield return null;

        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = userUniqueNum;

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);

        WWW www = new WWW(GetSupportInfoUrl, form);
        yield return www;

        result = www.text;

        serverItemSupport = result.Split(new char[] { '?' });

        Debug.Log("ItemSupport Info Get");
    }

    IEnumerator GetItemStrong()
    {
        yield return null;

        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = userUniqueNum;

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);

        WWW www = new WWW(GetStrongInfoUrl, form);
        yield return www;

        result = www.text;

        serverItemStrong = result.Split(new char[] { '?' });

        Debug.Log("ItemStrong Info Get");
    }

    IEnumerator GetItemNuclear()
    {
        yield return null;

        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = userUniqueNum;

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);

        WWW www = new WWW(GetNuclearInfoUrl, form);
        yield return www;

        result = www.text;

        serverItemNuclear = result.Split(new char[] { '?' });

        Debug.Log("ItemNuclear Info Get");
    }

    IEnumerator GetItemBoost()
    {
        yield return null;
        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = userUniqueNum;

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);

        WWW www = new WWW(GetBoostInfoUrl, form);
        yield return www;

        result = www.text;

        serverItemBoost = result.Split(new char[] { '?' });

        Debug.Log("ItemBoost Info Get");
    }

    IEnumerator GetGameSpecial()
    {
        yield return null;
        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = userUniqueNum;

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);

        WWW www = new WWW(GetGameSpecialUrl, form);
        yield return www;

        result = www.text;

        serverGameSpecial = result.Split(new char[] { '?' });

        //        Debug.Log("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&     " + serverGameSpecial[0]);
        //        Debug.Log("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&     " + serverGameSpecial[1]);
        //        Debug.Log("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&     " + serverGameSpecial[2]);
        //        Debug.Log("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&     " + serverGameSpecial[3]);
        //        Debug.Log("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&     " + serverGameSpecial[4]);
        //        Debug.Log("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&     " + serverGameSpecial[5]);
        //        Debug.Log("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&     " + serverGameSpecial[6]);
        //        Debug.Log("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&     " + serverGameSpecial[7]);
        //        Debug.Log("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&     " + serverGameSpecial[8]);

        Debug.Log("GameSpecial Info Get");
    }

    IEnumerator GetGameSpecialOn()
    {
        yield return null;
        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = userUniqueNum;

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);

        WWW www = new WWW(GetGameSpecialOnUrl, form);
        yield return www;

        result = www.text;

        serverGameSpecialOn = result.Split(new char[] { '?' });

        Debug.Log("GameSpecialOn Info Get");

    }
    IEnumerator GetGameSpecialCount()
    {
        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = userUniqueNum;

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);

        WWW www = new WWW(GetGameSpecialCountUrl, form);
        yield return www;

        result = www.text;
        //Debug.Log(result);
        serverGameSpecialCount = result.Split(new char[] { '?' });

        //        Debug.Log(">>>>>>>>>>>>>>>>>   H  E  R  E  !!!!!   >>>>>>>>>>>>>>>>>>>>>>>>" + serverGameSpecialCount[0]);
        //        Debug.Log(">>>>>>>>>>>>>>>>>   H  E  R  E  !!!!!   >>>>>>>>>>>>>>>>>>>>>>>>" + serverGameSpecialCount[1]);
        //        Debug.Log(">>>>>>>>>>>>>>>>>   H  E  R  E  !!!!!   >>>>>>>>>>>>>>>>>>>>>>>>" + serverGameSpecialCount[2]);
        //        Debug.Log(">>>>>>>>>>>>>>>>>   H  E  R  E  !!!!!   >>>>>>>>>>>>>>>>>>>>>>>>" + serverGameSpecialCount[3]);
        Debug.Log("GameSpecialOn Info Get");

    }

    IEnumerator GetPhantom()
    {
        yield return null;

        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = userUniqueNum;

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);

        WWW www = new WWW(GetPhantomInfoUrl, form);
        yield return www;

        result = www.text;

        serverAircraft_Phantom = result.Split(new char[] { '?' });

        Debug.Log("Phangom Info Get");
    }

    IEnumerator GetPhantomLock()
    {
        yield return null;

        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = userUniqueNum;

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);

        WWW www = new WWW(GetPhantomLockInfoUrl, form);
        yield return www;

        result = www.text;

        serverAircraft_PhantomLock = result.Split(new char[] { '?' });

        Debug.Log("Phangom Lock Info Get");
        //		Debug.Log ("$$$$$$$$$$$$$$$$$$$$$$$$$$$  " +serverAircraft_PhantomLock[0] +"  $$$$$$$$$$$$$$$$$$$$$$$$$$$");
        //		Debug.Log ("$$$$$$$$$$$$$$$$$$$$$$$$$$$  " +serverAircraft_PhantomLock[1] +"  $$$$$$$$$$$$$$$$$$$$$$$$$$$");
        //		Debug.Log ("$$$$$$$$$$$$$$$$$$$$$$$$$$$  " +serverAircraft_PhantomLock[2] +"  $$$$$$$$$$$$$$$$$$$$$$$$$$$");
    }

    IEnumerator GetPhantomSkin()
    {
        yield return null;

        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = userUniqueNum;

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);

        WWW www = new WWW(GetPhantomSkinInfoUrl, form);
        yield return www;

        result = www.text;

        serverAircraft_PhantomSkin = result.Split(new char[] { '?' });

        Debug.Log("Phangom Info Get");
    }


    IEnumerator GetFokker()
    {
        yield return null;

        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = userUniqueNum;

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);

        WWW www = new WWW(GetFokkerInfoUrl, form);
        yield return www;

        result = www.text;

        serverAircraft_Fokker = result.Split(new char[] { '?' });

        Debug.Log("Fokker Info Get");
    }

    IEnumerator GetFokkerLock()
    {
        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = userUniqueNum;

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);

        WWW www = new WWW(GetFokkerLockInfoUrl, form);
        yield return www;

        result = www.text;
        serverAircraft_FokkerLock = result.Split(new char[] { '?' });

        Debug.Log("Fokker Lock Info Get");
        //		Debug.Log ("$$$$$$$$$$$$$$$$$$$$$$$$$$$  " +serverAircraft_FokkerLock[0] +"  $$$$$$$$$$$$$$$$$$$$$$$$$$$");
        //		Debug.Log ("$$$$$$$$$$$$$$$$$$$$$$$$$$$  " +serverAircraft_FokkerLock[1] +"  $$$$$$$$$$$$$$$$$$$$$$$$$$$");
        //		Debug.Log ("$$$$$$$$$$$$$$$$$$$$$$$$$$$  " +serverAircraft_FokkerLock[2] +"  $$$$$$$$$$$$$$$$$$$$$$$$$$$");
    }

    IEnumerator GetFokkerSkin()
    {
        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = userUniqueNum;

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);

        WWW www = new WWW(GetFokkerSkinInfoUrl, form);
        yield return www;

        result = www.text;
        serverAircraft_FokkerSkin = result.Split(new char[] { '?' });

        Debug.Log("Fokker Skin Info Get");
    }

    IEnumerator GetComanche()
    {
        yield return null;

        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = userUniqueNum;

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);

        WWW www = new WWW(GetComancheInfoUrl, form);
        yield return www;

        result = www.text;

        serverAircraft_Comanche = result.Split(new char[] { '?' });

        Debug.Log("Comanche Info Get");
    }

    IEnumerator GetComancheLock()
    {
        yield return null;

        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = userUniqueNum;

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);

        WWW www = new WWW(GetComancheLockInfoUrl, form);
        yield return www;

        result = www.text;

        serverAircraft_ComancheLock = result.Split(new char[] { '?' });

        Debug.Log("Comanche Lock Info Get");
        //		Debug.Log ("$$$$$$$$$$$$$$$$$$$$$$$$$$$  " +serverAircraft_ComancheLock[0] +"  $$$$$$$$$$$$$$$$$$$$$$$$$$$");
        //		Debug.Log ("$$$$$$$$$$$$$$$$$$$$$$$$$$$  " +serverAircraft_ComancheLock[1] +"  $$$$$$$$$$$$$$$$$$$$$$$$$$$");
        //		Debug.Log ("$$$$$$$$$$$$$$$$$$$$$$$$$$$  " +serverAircraft_ComancheLock[2] +"  $$$$$$$$$$$$$$$$$$$$$$$$$$$");
    }

    IEnumerator GetComancheSkin()
    {
        yield return null;

        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = userUniqueNum;

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);

        WWW www = new WWW(GetComancheSKinInfoUrl, form);
        yield return www;

        result = www.text;

        serverAircraft_ComancheSkin = result.Split(new char[] { '?' });

        Debug.Log("Comanche Info Get");
    }

    IEnumerator GetAirCraft()
    {
        ForKaKao.instance._ui.text += " _GetAirCraft00_";
        yield return null;

        string hash = Md5Sum(secretKey).ToLower();
        ForKaKao.instance._ui.text += " _GetAirCraft01_";

        int userUniqueNumber = userUniqueNum;
        ForKaKao.instance._ui.text += " _GetAirCraft02_";
        WWWForm form = new WWWForm();
        ForKaKao.instance._ui.text += " _GetAirCraft03_";
        form.AddField("hash", hash);
        ForKaKao.instance._ui.text += " _GetAirCraft04_";
        form.AddField("User_Number", userUniqueNumber);
        ForKaKao.instance._ui.text += " _GetAirCraft05_";

        WWW www = new WWW(GetAirCraftInfoUrl, form);
        ForKaKao.instance._ui.text += " _GetAirCraft06_";
        yield return www;
        ForKaKao.instance._ui.text += " _GetAirCraft07_";

        result = www.text;
        ForKaKao.instance._ui.text += " _GetAirCraft08_";
        serverAircraftInfo = result.Split(new char[] { '?' });
        ForKaKao.instance._ui.text += " _GetAirCraft09_";
        Debug.Log("AirCraft Info Get");
    }

    IEnumerator SetHash()
    {
        ForKaKao.instance._ui.text += "_IntoSetHash_";
        yield return StartCoroutine(GetAirCraft());
        ForKaKao.instance._ui.text += "_Finish GetAirCraft_";
        if (!ValueDeliverScript.isFlightSkinExpLoad)
        {
            ValueDeliverScript.flightSkinExp.Add("Flight000Skin001", serverAircraft_Fokker[5]);
            ValueDeliverScript.flightSkinExp.Add("Flight000Skin002", serverAircraft_Fokker[8]);
            ValueDeliverScript.flightSkinExp.Add("Flight000Skin003", serverAircraft_Fokker[11]);
            ValueDeliverScript.flightSkinExp.Add("Flight000Skin004", serverAircraft_Fokker[14]);
            ValueDeliverScript.flightSkinExp.Add("Flight000Skin005", serverAircraft_Fokker[17]);

            ValueDeliverScript.flightSkinExp.Add("Flight001Skin001", serverAircraft_Comanche[5]);
            ValueDeliverScript.flightSkinExp.Add("Flight001Skin002", serverAircraft_Comanche[8]);
            ValueDeliverScript.flightSkinExp.Add("Flight001Skin003", serverAircraft_Comanche[11]);
            ValueDeliverScript.flightSkinExp.Add("Flight001Skin004", serverAircraft_Comanche[14]);
            ValueDeliverScript.flightSkinExp.Add("Flight001Skin005", serverAircraft_Comanche[17]);

            ValueDeliverScript.flightSkinExp.Add("Flight002Skin001", serverAircraft_Phantom[5]);
            ValueDeliverScript.flightSkinExp.Add("Flight002Skin002", serverAircraft_Phantom[8]);
            ValueDeliverScript.flightSkinExp.Add("Flight002Skin003", serverAircraft_Phantom[11]);
            ValueDeliverScript.flightSkinExp.Add("Flight002Skin004", serverAircraft_Phantom[14]);
            ValueDeliverScript.flightSkinExp.Add("Flight002Skin005", serverAircraft_Phantom[17]);

            ValueDeliverScript.isFlightSkinExpLoad = true;

        }

        ForKaKao.instance._ui.text += " SetHash01_";


        if (!ValueDeliverScript.isSkinLockOffLoad)
        {
            ValueDeliverScript.skinLockOff.Add("Flight000Skin001", serverAircraft_FokkerLock[0]);
            ValueDeliverScript.skinLockOff.Add("Flight000Skin002", serverAircraft_FokkerLock[1]);
            ValueDeliverScript.skinLockOff.Add("Flight000Skin003", serverAircraft_FokkerLock[2]);
            ValueDeliverScript.skinLockOff.Add("Flight000Skin004", serverAircraft_FokkerLock[3]);
            ValueDeliverScript.skinLockOff.Add("Flight000Skin005", serverAircraft_FokkerLock[4]);

            ValueDeliverScript.skinLockOff.Add("Flight001Skin001", serverAircraft_ComancheLock[0]);
            ValueDeliverScript.skinLockOff.Add("Flight001Skin002", serverAircraft_ComancheLock[1]);
            ValueDeliverScript.skinLockOff.Add("Flight001Skin003", serverAircraft_ComancheLock[2]);
            ValueDeliverScript.skinLockOff.Add("Flight001Skin004", serverAircraft_ComancheLock[3]);
            ValueDeliverScript.skinLockOff.Add("Flight001Skin005", serverAircraft_ComancheLock[4]);

            ValueDeliverScript.skinLockOff.Add("Flight002Skin001", serverAircraft_PhantomLock[0]);
            ValueDeliverScript.skinLockOff.Add("Flight002Skin002", serverAircraft_PhantomLock[1]);
            ValueDeliverScript.skinLockOff.Add("Flight002Skin003", serverAircraft_PhantomLock[2]);
            ValueDeliverScript.skinLockOff.Add("Flight002Skin004", serverAircraft_PhantomLock[3]);
            ValueDeliverScript.skinLockOff.Add("Flight002Skin005", serverAircraft_PhantomLock[4]);

            ValueDeliverScript.isSkinLockOffLoad = true;
        }
        ForKaKao.instance._ui.text += " SetHash02_";


        if (!ValueDeliverScript.isFlightSkinLevelLoad)
        {
            ValueDeliverScript.flightSkinLevel.Add("Flight000Skin001", 1);
            ValueDeliverScript.flightSkinLevel.Add("Flight000Skin002", 1);
            ValueDeliverScript.flightSkinLevel.Add("Flight000Skin003", 1);
            ValueDeliverScript.flightSkinLevel.Add("Flight000Skin004", 1);
            ValueDeliverScript.flightSkinLevel.Add("Flight000Skin005", 1);

            ValueDeliverScript.flightSkinLevel.Add("Flight001Skin001", 1);
            ValueDeliverScript.flightSkinLevel.Add("Flight001Skin002", 1);
            ValueDeliverScript.flightSkinLevel.Add("Flight001Skin003", 1);
            ValueDeliverScript.flightSkinLevel.Add("Flight001Skin004", 1);
            ValueDeliverScript.flightSkinLevel.Add("Flight001Skin005", 1);

            ValueDeliverScript.flightSkinLevel.Add("Flight002Skin001", 1);
            ValueDeliverScript.flightSkinLevel.Add("Flight002Skin002", 1);
            ValueDeliverScript.flightSkinLevel.Add("Flight002Skin003", 1);
            ValueDeliverScript.flightSkinLevel.Add("Flight002Skin004", 1);
            ValueDeliverScript.flightSkinLevel.Add("Flight002Skin005", 1);

            ValueDeliverScript.isFlightSkinLevelLoad = true;
        }
        ForKaKao.instance._ui.text += " SetHash03_";

        if (!ValueDeliverScript.isFlightDuraLevelLoad)
        {
            ValueDeliverScript.flightSkinDura.Add("Flight000Skin001", serverAircraft_Fokker[4]);
            ValueDeliverScript.flightSkinDura.Add("Flight000Skin002", serverAircraft_Fokker[7]);
            ValueDeliverScript.flightSkinDura.Add("Flight000Skin003", serverAircraft_Fokker[10]);
            ValueDeliverScript.flightSkinDura.Add("Flight000Skin004", serverAircraft_Fokker[13]);
            ValueDeliverScript.flightSkinDura.Add("Flight000Skin005", serverAircraft_Fokker[16]);

            ValueDeliverScript.flightSkinDura.Add("Flight001Skin001", serverAircraft_Comanche[4]);
            ValueDeliverScript.flightSkinDura.Add("Flight001Skin002", serverAircraft_Comanche[7]);
            ValueDeliverScript.flightSkinDura.Add("Flight001Skin003", serverAircraft_Comanche[10]);
            ValueDeliverScript.flightSkinDura.Add("Flight001Skin004", serverAircraft_Comanche[13]);
            ValueDeliverScript.flightSkinDura.Add("Flight001Skin005", serverAircraft_Comanche[16]);

            ValueDeliverScript.flightSkinDura.Add("Flight002Skin001", serverAircraft_Phantom[4]);
            ValueDeliverScript.flightSkinDura.Add("Flight002Skin002", serverAircraft_Phantom[7]);
            ValueDeliverScript.flightSkinDura.Add("Flight002Skin003", serverAircraft_Phantom[10]);
            ValueDeliverScript.flightSkinDura.Add("Flight002Skin004", serverAircraft_Phantom[13]);
            ValueDeliverScript.flightSkinDura.Add("Flight002Skin005", serverAircraft_Phantom[16]);

            ValueDeliverScript.isFlightDuraLevelLoad = true;
        }
        ForKaKao.instance._ui.text += " SetHash04_";


        if (!ValueDeliverScript.isMyEquipload)
        {
            ValueDeliverScript.myEquip.Add("Bomb01", serverItemNuclear[0]);
            ValueDeliverScript.myEquip.Add("Bomb02", serverItemNuclear[1]);
            ValueDeliverScript.myEquip.Add("Bomb03", serverItemNuclear[2]);
            ValueDeliverScript.myEquip.Add("Bomb04", serverItemNuclear[3]);
            ValueDeliverScript.myEquip.Add("Bomb05", serverItemNuclear[4]);
            ValueDeliverScript.myEquip.Add("Bomb06", 0);
            ValueDeliverScript.myEquip.Add("Bomb07", 0);
            ValueDeliverScript.myEquip.Add("Bomb08", 0);
            ValueDeliverScript.myEquip.Add("Bomb09", 0);
            ValueDeliverScript.myEquip.Add("Bomb10", 0);
            ValueDeliverScript.myEquip.Add("Bomb11", 0);
            ValueDeliverScript.myEquip.Add("Bomb12", 0);

            ValueDeliverScript.myEquip.Add("Reinforce01", serverItemStrong[0]);
            ValueDeliverScript.myEquip.Add("Reinforce02", serverItemStrong[1]);
            ValueDeliverScript.myEquip.Add("Reinforce03", serverItemStrong[2]);
            ValueDeliverScript.myEquip.Add("Reinforce04", serverItemStrong[3]);
            ValueDeliverScript.myEquip.Add("Reinforce05", serverItemStrong[4]);
            ValueDeliverScript.myEquip.Add("Reinforce06", serverItemStrong[5]);
            ValueDeliverScript.myEquip.Add("Reinforce07", serverItemStrong[6]);
            ValueDeliverScript.myEquip.Add("Reinforce08", 0);
            ValueDeliverScript.myEquip.Add("Reinforce09", 0);
            ValueDeliverScript.myEquip.Add("Reinforce10", 0);
            ValueDeliverScript.myEquip.Add("Reinforce11", 0);
            ValueDeliverScript.myEquip.Add("Reinforce12", 0);

            ValueDeliverScript.myEquip.Add("Assist01", serverItemSupport[0]);
            ValueDeliverScript.myEquip.Add("Assist02", serverItemSupport[1]);
            ValueDeliverScript.myEquip.Add("Assist03", serverItemSupport[2]);
            ValueDeliverScript.myEquip.Add("Assist04", serverItemSupport[3]);
            ValueDeliverScript.myEquip.Add("Assist05", 0);
            ValueDeliverScript.myEquip.Add("Assist06", 0);
            ValueDeliverScript.myEquip.Add("Assist07", 0);
            ValueDeliverScript.myEquip.Add("Assist08", 0);
            ValueDeliverScript.myEquip.Add("Assist09", 0);
            ValueDeliverScript.myEquip.Add("Assist10", 0);
            ValueDeliverScript.myEquip.Add("Assist11", 0);
            ValueDeliverScript.myEquip.Add("Assist12", 0);

            ValueDeliverScript.myEquip.Add("Boost01", serverItemBoost[0]);
            ValueDeliverScript.myEquip.Add("Boost02", serverItemBoost[1]);
            ValueDeliverScript.myEquip.Add("Boost03", serverItemBoost[2]);
            ValueDeliverScript.myEquip.Add("Boost04", serverItemBoost[3]);
            ValueDeliverScript.myEquip.Add("Boost05", serverItemBoost[4]);
            ValueDeliverScript.myEquip.Add("Boost06", serverItemBoost[5]);
            ValueDeliverScript.myEquip.Add("Boost07", serverItemBoost[6]);
            ValueDeliverScript.myEquip.Add("Boost08", 0);
            ValueDeliverScript.myEquip.Add("Boost09", 0);
            ValueDeliverScript.myEquip.Add("Boost10", 0);
            ValueDeliverScript.myEquip.Add("Boost11", 0);
            ValueDeliverScript.myEquip.Add("Boost12", 0);

            ValueDeliverScript.isMyEquipload = true;
        }
        ForKaKao.instance._ui.text += " SetHash_05";


        if (!ValueDeliverScript.isFlightLockOff)
        {
            ValueDeliverScript.flightLockOff.Add("Flight000", true);
            ValueDeliverScript.flightLockOff.Add("Flight001", false);
            ValueDeliverScript.flightLockOff.Add("Flight002", false);
            ValueDeliverScript.flightLockOff.Add("Flight001Coin", 29000);
            ValueDeliverScript.flightLockOff.Add("Flight002Coin", 36000);
            ValueDeliverScript.flightLockOff.Add("Flight001Medal", 49);
            ValueDeliverScript.flightLockOff.Add("Flight002Medal", 59);


            ValueDeliverScript.isFlightLockOff = true;
        }
        ForKaKao.instance._ui.text += " SetHash06_";


        Debug.Log("=========== Hash Initializing Complete ==========");
    }

    IEnumerator SetPlayerDB()
    {
        ForKaKao.instance._ui.text += "_Into SetPlayerDB00_";
        yield return StartCoroutine(SetHash());
        ForKaKao.instance._ui.text += "_Into SetPlayerDB01_";

        UserGameInfoCoinInfo(out ValueDeliverScript.coinRest);
        ForKaKao.instance._ui.text += "_Into SetPlayerDB02_";
        UserGameInfoMedalInfo(out ValueDeliverScript.medalRest);
        ForKaKao.instance._ui.text += "_Into SetPlayerDB03_";
        UserGameInfoPilotExp(out ValueDeliverScript.userExp);
        ForKaKao.instance._ui.text += "_Into SetPlayerDB04_";
        UserGameInfoPilotLevel(out ValueDeliverScript.userLevel);
        ForKaKao.instance._ui.text += "_Into SetPlayerDB05_";
        UserGameInfoFuelInfo(out ValueDeliverScript.gasRest);
        ForKaKao.instance._ui.text += "_Into SetPlayerDB06_";

        UserGameItemNuclearEquip(out ValueDeliverScript.activeBomb);
        ForKaKao.instance._ui.text += "_Into SetPlayerDB07_";
        UserGameItemStrongEquip(out ValueDeliverScript.activeReinforce);
        ForKaKao.instance._ui.text += "_Into SetPlayerDB08_";
        UserGameItemBoostEquip(out ValueDeliverScript.activeBoost);
        ForKaKao.instance._ui.text += "_Into SetPlayerDB09_";
        UserGameItemSupporterEquip(out ValueDeliverScript.activeAssist);
        ForKaKao.instance._ui.text += "_Into SetPlayerDB10_";

        GameSpecialEndTime(out ValueDeliverScript.specialEndTime);
        ForKaKao.instance._ui.text += "_Into SetPlayerDB11_";
        GameSpecialAttackItemName(out ValueDeliverScript.specialAttackItemName);
        ForKaKao.instance._ui.text += "_Into SetPlayerDB12_";
        GameSpecialAttackItemMaxNumber(out ValueDeliverScript.specialAttackItemMaxNumber);
        ForKaKao.instance._ui.text += "_Into SetPlayerDB13_";
        GameSpecialGasLastAddTime(out ValueDeliverScript.gasLastAddTime);
        ForKaKao.instance._ui.text += "_Into SetPlayerDB14_";
        GameSpecialGasNextAddTime(out ValueDeliverScript.gasNextAddTime);
        ForKaKao.instance._ui.text += "_Into SetPlayerDB15_";
        GameSpecialTimeRecord(out ValueDeliverScript.timeRecord);
        ForKaKao.instance._ui.text += "_Into SetPlayerDB16_";

        GameSpecialOnIsSpecialAttack(out ValueDeliverScript.isSpecialAttack);
        ForKaKao.instance._ui.text += "_Into SetPlayerDB17_";
        GameSpecialOnSpecialAttack(out ValueDeliverScript.specialAttack);
        ForKaKao.instance._ui.text += "_Into SetPlayerDB18_";
        GameSpecialOnSpecialAttackOn(out ValueDeliverScript.specialAttackOn);
        ForKaKao.instance._ui.text += "_Into SetPlayerDB19_";

        GameSpecialCountDart(out ValueDeliverScript.dartCount);
        ForKaKao.instance._ui.text += "_Into SetPlayerDB20_";
        GameSpecialCountDust(out ValueDeliverScript.dustCount);
        ForKaKao.instance._ui.text += "_Into SetPlayerDB21_";
        GameSpecialCountShield(out ValueDeliverScript.shieldCount);
        ForKaKao.instance._ui.text += "_Into SetPlayerDB22_";
        GameSpecialCountSpinball(out ValueDeliverScript.spinballCount);
        ForKaKao.instance._ui.text += "_Into SetPlayerDB23_";

        RankingBestScore(out ValueDeliverScript.scoreHigh);
        ForKaKao.instance._ui.text = "_Into SetPlayerDB24_";

        Aircraft_FokkerBulletGrade(out ValueDeliverScript.flight000Bullet);
        ForKaKao.instance._ui.text += "_Into SetPlayerDB25_";
        Aircraft_FokkerSkillGrade(out ValueDeliverScript.flight000Skill);
        ForKaKao.instance._ui.text += "_Into SetPlayerDB26_";
        Aircraft_FokkerSkinSelect(out ValueDeliverScript.flight000Skin);
        ForKaKao.instance._ui.text += "_Into SetPlayerDB27_";

        Aircraft_FokkerSkinSortieNumber(out ValueDeliverScript.flight000SortieNumber);
        ForKaKao.instance._ui.text += "_Into SetPlayerDB28_";
        Aircraft_FokkerSkinBombUseNumber(out ValueDeliverScript.flight000BombUseNumber);
        ForKaKao.instance._ui.text += "_Into SetPlayerDB29_";
        Aircraft_FokkerSkinScoreHigh(out ValueDeliverScript.flight000ScoreHigh);
        ForKaKao.instance._ui.text += "_Into SetPlayerDB30_";

        Aircraft_PhantomBulletGrade(out ValueDeliverScript.flight002Bullet);
        ForKaKao.instance._ui.text += "_Into SetPlayerDB31_";
        Aircraft_PhantomSkillGrade(out ValueDeliverScript.flight002Skill);
        ForKaKao.instance._ui.text += "_Into SetPlayerDB32_";
        Aircraft_PhantomSkinSelect(out ValueDeliverScript.flight002Skin);
        ForKaKao.instance._ui.text += "_Into SetPlayerDB33_";

        Aircraft_PhantomSkinKillSpinball(out ValueDeliverScript.flight002KillSpinball);
        ForKaKao.instance._ui.text += "_Into SetPlayerDB34_";
        Aircraft_PhantomSkinSpecialAttack(out ValueDeliverScript.flight002SpecialAttack);
        ForKaKao.instance._ui.text += "_Into SetPlayerDB35_";
        Aircraft_PhantomSkinCompleteInstanceMission(out ValueDeliverScript.flight002CompleteInstanceMission);
        ForKaKao.instance._ui.text += "_Into SetPlayerDB36_";
        Aircraft_PhantomSkinRescueFriend(out ValueDeliverScript.flight002RescueFriend);
        ForKaKao.instance._ui.text += "_Into SetPlayerDB37_";
        Aircraft_PhantomSkinWormLevel5(out ValueDeliverScript.flight002WormLevel5);
        ForKaKao.instance._ui.text += "_Into SetPlayerDB38_";

        Aircraft_ComancheBulletGrade(out ValueDeliverScript.flight001Bullet);
        ForKaKao.instance._ui.text += "_Into SetPlayerDB39_";
        Aircraft_ComancheSkillGrade(out ValueDeliverScript.flight001Skill);
        ForKaKao.instance._ui.text += "_Into SetPlayerDB40_";
        Aircraft_ComancheSkinSelect(out ValueDeliverScript.flight001Skin);
        ForKaKao.instance._ui.text += "_Into SetPlayerDB41_";

        Aircraft_ComancheSkinEnemyKill(out ValueDeliverScript.flight001EnemyKill);
        ForKaKao.instance._ui.text += "_Into SetPlayerDB42_";
        Aircraft_ComancheSkinGetCoin(out ValueDeliverScript.flight001GetCoin);
        ForKaKao.instance._ui.text += "_Into SetPlayerDB43_";
        Aircraft_ComancheSkinUseSkill(out ValueDeliverScript.flight001UseSkill);
        ForKaKao.instance._ui.text += "_Into SetPlayerDB44_";
        Aircraft_ComancheSkinGetPower(out ValueDeliverScript.flight001GetPowerItem);
        ForKaKao.instance._ui.text += "_Into SetPlayerDB45_";
        
        AircraftInfoAircraftSelect(out ValueDeliverScript.flightNumber);
        ForKaKao.instance._ui.text += "_Into SetPlayerDB46_";
        ValueDeliverScript.flightLockOff["Flight001"] = serverAircraftInfo[2];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB47_";
        ValueDeliverScript.flightLockOff["Flight002"] = serverAircraftInfo[3];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB48_";
        

        ValueDeliverScript.flightSkinExp["Flight000Skin00"] = serverAircraft_Fokker[5];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB49_";
        ValueDeliverScript.flightSkinExp["Flight000Skin002"] = serverAircraft_Fokker[8];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB50_";
        ValueDeliverScript.flightSkinExp["Flight000Skin003"] = serverAircraft_Fokker[11];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB51_";
        ValueDeliverScript.flightSkinExp["Flight000Skin004"] = serverAircraft_Fokker[14];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB52_";
        ValueDeliverScript.flightSkinExp["Flight000Skin005"] = serverAircraft_Fokker[17];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB53_";
        
        ValueDeliverScript.flightSkinExp["Flight001Skin001"] = serverAircraft_Comanche[5];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB54_";
        ValueDeliverScript.flightSkinExp["Flight001Skin002"] = serverAircraft_Comanche[8];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB55_";
        ValueDeliverScript.flightSkinExp["Flight001Skin003"] = serverAircraft_Comanche[11];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB56_";
        ValueDeliverScript.flightSkinExp["Flight001Skin004"] = serverAircraft_Comanche[14];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB57_";
        ValueDeliverScript.flightSkinExp["Flight001Skin005"] = serverAircraft_Comanche[17];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB58_";
        
        ValueDeliverScript.flightSkinExp["Flight002Skin001"] = serverAircraft_Phantom[5];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB59_";
        ValueDeliverScript.flightSkinExp["Flight002Skin002"] = serverAircraft_Phantom[8];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB60_";
        ValueDeliverScript.flightSkinExp["Flight002Skin003"] = serverAircraft_Phantom[11];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB61_";
        ValueDeliverScript.flightSkinExp["Flight002Skin004"] = serverAircraft_Phantom[14];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB62_";
        ValueDeliverScript.flightSkinExp["Flight002Skin005"] = serverAircraft_Phantom[17];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB63_";
        
        ValueDeliverScript.flightSkinDura["Flight000Skin001"] = serverAircraft_Fokker[4];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB64_";
        ValueDeliverScript.flightSkinDura["Flight000Skin002"] = serverAircraft_Fokker[7];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB65_";
        ValueDeliverScript.flightSkinDura["Flight000Skin003"] = serverAircraft_Fokker[10];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB66_";
        ValueDeliverScript.flightSkinDura["Flight000Skin004"] = serverAircraft_Fokker[13];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB67_";
        ValueDeliverScript.flightSkinDura["Flight000Skin005"] = serverAircraft_Fokker[16];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB68_";
        
        ValueDeliverScript.flightSkinDura["Flight001Skin001"] = serverAircraft_Comanche[4];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB69_";
        ValueDeliverScript.flightSkinDura["Flight001Skin002"] = serverAircraft_Comanche[7];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB70_";
        ValueDeliverScript.flightSkinDura["Flight001Skin003"] = serverAircraft_Comanche[10];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB71_";
        ValueDeliverScript.flightSkinDura["Flight001Skin004"] = serverAircraft_Comanche[13];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB72_";
        ValueDeliverScript.flightSkinDura["Flight001Skin005"] = serverAircraft_Comanche[16];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB73_";
        
        ValueDeliverScript.flightSkinDura["Flight002Skin001"] = serverAircraft_Phantom[4];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB74_";
        ValueDeliverScript.flightSkinDura["Flight002Skin002"] = serverAircraft_Phantom[7];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB75_";
        ValueDeliverScript.flightSkinDura["Flight002Skin003"] = serverAircraft_Phantom[10];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB76_";
        ValueDeliverScript.flightSkinDura["Flight002Skin004"] = serverAircraft_Phantom[13];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB77_";
        ValueDeliverScript.flightSkinDura["Flight002Skin005"] = serverAircraft_Phantom[16];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB78_";
        

        ValueDeliverScript.skinLockOff["Flight000Skin001"] = serverAircraft_FokkerLock[0];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB79_";
        ValueDeliverScript.skinLockOff["Flight000Skin002"] = serverAircraft_FokkerLock[1];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB80_";
        ValueDeliverScript.skinLockOff["Flight000Skin003"] = serverAircraft_FokkerLock[2];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB81_";
        ValueDeliverScript.skinLockOff["Flight000Skin004"] = serverAircraft_FokkerLock[3];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB82_";
        ValueDeliverScript.skinLockOff["Flight000Skin005"] = serverAircraft_FokkerLock[4];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB83_";
        
        //		Debug.Log ("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@  "+ValueDeliverScript.skinLockOff["Flight000Skin001"]+"  @@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        //		Debug.Log ("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@  "+ValueDeliverScript.skinLockOff["Flight000Skin002"]+"  @@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        //		Debug.Log ("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@  "+ValueDeliverScript.skinLockOff["Flight000Skin003"]+"  @@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        //		Debug.Log ("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@  "+ValueDeliverScript.skinLockOff["Flight000Skin004"]+"  @@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        //		Debug.Log ("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@  "+ValueDeliverScript.skinLockOff["Flight000Skin005"]+"  @@@@@@@@@@@@@@@@@@@@@@@@@@@@@");

        ValueDeliverScript.skinLockOff["Flight001Skin001"] = serverAircraft_ComancheLock[0];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB84_";
        ValueDeliverScript.skinLockOff["Flight001Skin002"] = serverAircraft_ComancheLock[1];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB85_";
        ValueDeliverScript.skinLockOff["Flight001Skin003"] = serverAircraft_ComancheLock[2];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB86_";
        ValueDeliverScript.skinLockOff["Flight001Skin004"] = serverAircraft_ComancheLock[3];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB87_";
        ValueDeliverScript.skinLockOff["Flight001Skin005"] = serverAircraft_ComancheLock[4];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB88_";
        
        ValueDeliverScript.skinLockOff["Flight002Skin001"] = serverAircraft_PhantomLock[0];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB89_";
        ValueDeliverScript.skinLockOff["Flight002Skin002"] = serverAircraft_PhantomLock[1];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB90_";
        ValueDeliverScript.skinLockOff["Flight002Skin003"] = serverAircraft_PhantomLock[2];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB91_";
        ValueDeliverScript.skinLockOff["Flight002Skin004"] = serverAircraft_PhantomLock[3];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB92_";
        ValueDeliverScript.skinLockOff["Flight002Skin005"] = serverAircraft_PhantomLock[4];
        ForKaKao.instance._ui.text += "_Into SetPlayerDB93_";
        
        Debug.Log("=================  SET DB COMPLETE  =================");

        ForKaKao.instance._ui.text = "_SET DB COMPLETE_";
        StartCoroutine(LoadHanger());

    }

    IEnumerator SetPlayerDB2()
    {
        yield return null;

        UserGameInfoCoinInfo(out ValueDeliverScript.coinRest);
        UserGameInfoMedalInfo(out ValueDeliverScript.medalRest);
        UserGameInfoPilotExp(out ValueDeliverScript.userExp);
        UserGameInfoPilotLevel(out ValueDeliverScript.userLevel);
        UserGameInfoFuelInfo(out ValueDeliverScript.gasRest);

        UserGameItemNuclearEquip(out ValueDeliverScript.activeBomb);
        UserGameItemStrongEquip(out ValueDeliverScript.activeReinforce);
        UserGameItemBoostEquip(out ValueDeliverScript.activeBoost);
        UserGameItemSupporterEquip(out ValueDeliverScript.activeAssist);

        GameSpecialEndTime(out ValueDeliverScript.specialEndTime);
        GameSpecialAttackItemName(out ValueDeliverScript.specialAttackItemName);
        GameSpecialAttackItemMaxNumber(out ValueDeliverScript.specialAttackItemMaxNumber);
        GameSpecialGasLastAddTime(out ValueDeliverScript.gasLastAddTime);
        GameSpecialGasNextAddTime(out ValueDeliverScript.gasNextAddTime);
        GameSpecialTimeRecord(out ValueDeliverScript.timeRecord);

        GameSpecialOnIsSpecialAttack(out ValueDeliverScript.isSpecialAttack);
        GameSpecialOnSpecialAttack(out ValueDeliverScript.specialAttack);
        GameSpecialOnSpecialAttackOn(out ValueDeliverScript.specialAttackOn);

        GameSpecialCountDart(out ValueDeliverScript.dartCount);
        GameSpecialCountDust(out ValueDeliverScript.dustCount);
        GameSpecialCountShield(out ValueDeliverScript.shieldCount);
        GameSpecialCountSpinball(out ValueDeliverScript.spinballCount);

        RankingBestScore(out ValueDeliverScript.scoreHigh);

        Aircraft_FokkerBulletGrade(out ValueDeliverScript.flight000Bullet);
        Aircraft_FokkerSkillGrade(out ValueDeliverScript.flight000Skill);
        Aircraft_FokkerSkinSelect(out ValueDeliverScript.flight000Skin);

        Aircraft_FokkerSkinSortieNumber(out ValueDeliverScript.flight000SortieNumber);
        Aircraft_FokkerSkinBombUseNumber(out ValueDeliverScript.flight000BombUseNumber);
        Aircraft_FokkerSkinScoreHigh(out ValueDeliverScript.flight000ScoreHigh);

        Aircraft_PhantomBulletGrade(out ValueDeliverScript.flight002Bullet);
        Aircraft_PhantomSkillGrade(out ValueDeliverScript.flight002Skill);
        Aircraft_PhantomSkinSelect(out ValueDeliverScript.flight002Skin);

        Aircraft_PhantomSkinKillSpinball(out ValueDeliverScript.flight002KillSpinball);
        Aircraft_PhantomSkinSpecialAttack(out ValueDeliverScript.flight002SpecialAttack);
        Aircraft_PhantomSkinCompleteInstanceMission(out ValueDeliverScript.flight002CompleteInstanceMission);
        Aircraft_PhantomSkinRescueFriend(out ValueDeliverScript.flight002RescueFriend);
        Aircraft_PhantomSkinWormLevel5(out ValueDeliverScript.flight002WormLevel5);

        Aircraft_ComancheBulletGrade(out ValueDeliverScript.flight001Bullet);
        Aircraft_ComancheSkillGrade(out ValueDeliverScript.flight001Skill);
        Aircraft_ComancheSkinSelect(out ValueDeliverScript.flight001Skin);

        Aircraft_ComancheSkinEnemyKill(out ValueDeliverScript.flight001EnemyKill);
        Aircraft_ComancheSkinGetCoin(out ValueDeliverScript.flight001GetCoin);
        Aircraft_ComancheSkinUseSkill(out ValueDeliverScript.flight001UseSkill);
        Aircraft_ComancheSkinGetPower(out ValueDeliverScript.flight001GetPowerItem);

        AircraftInfoAircraftSelect(out ValueDeliverScript.flightNumber);
        ValueDeliverScript.flightLockOff["Flight001"] = serverAircraftInfo[2];
        ValueDeliverScript.flightLockOff["Flight002"] = serverAircraftInfo[3];

        ValueDeliverScript.flightSkinExp["Flight000Skin001"] = serverAircraft_Fokker[5];
        ValueDeliverScript.flightSkinExp["Flight000Skin002"] = serverAircraft_Fokker[8];
        ValueDeliverScript.flightSkinExp["Flight000Skin003"] = serverAircraft_Fokker[11];
        ValueDeliverScript.flightSkinExp["Flight000Skin004"] = serverAircraft_Fokker[14];
        ValueDeliverScript.flightSkinExp["Flight000Skin005"] = serverAircraft_Fokker[17];

        ValueDeliverScript.flightSkinExp["Flight001Skin001"] = serverAircraft_Comanche[5];
        ValueDeliverScript.flightSkinExp["Flight001Skin002"] = serverAircraft_Comanche[8];
        ValueDeliverScript.flightSkinExp["Flight001Skin003"] = serverAircraft_Comanche[11];
        ValueDeliverScript.flightSkinExp["Flight001Skin004"] = serverAircraft_Comanche[14];
        ValueDeliverScript.flightSkinExp["Flight001Skin005"] = serverAircraft_Comanche[17];

        ValueDeliverScript.flightSkinExp["Flight002Skin001"] = serverAircraft_Phantom[5];
        ValueDeliverScript.flightSkinExp["Flight002Skin002"] = serverAircraft_Phantom[8];
        ValueDeliverScript.flightSkinExp["Flight002Skin003"] = serverAircraft_Phantom[11];
        ValueDeliverScript.flightSkinExp["Flight002Skin004"] = serverAircraft_Phantom[14];
        ValueDeliverScript.flightSkinExp["Flight002Skin005"] = serverAircraft_Phantom[17];

        ValueDeliverScript.flightSkinDura["Flight000Skin001"] = serverAircraft_Fokker[4];
        ValueDeliverScript.flightSkinDura["Flight000Skin002"] = serverAircraft_Fokker[7];
        ValueDeliverScript.flightSkinDura["Flight000Skin003"] = serverAircraft_Fokker[10];
        ValueDeliverScript.flightSkinDura["Flight000Skin004"] = serverAircraft_Fokker[13];
        ValueDeliverScript.flightSkinDura["Flight000Skin005"] = serverAircraft_Fokker[16];

        ValueDeliverScript.flightSkinDura["Flight001Skin001"] = serverAircraft_Comanche[4];
        ValueDeliverScript.flightSkinDura["Flight001Skin002"] = serverAircraft_Comanche[7];
        ValueDeliverScript.flightSkinDura["Flight001Skin003"] = serverAircraft_Comanche[10];
        ValueDeliverScript.flightSkinDura["Flight001Skin004"] = serverAircraft_Comanche[13];
        ValueDeliverScript.flightSkinDura["Flight001Skin005"] = serverAircraft_Comanche[16];

        ValueDeliverScript.flightSkinDura["Flight002Skin001"] = serverAircraft_Phantom[4];
        ValueDeliverScript.flightSkinDura["Flight002Skin002"] = serverAircraft_Phantom[7];
        ValueDeliverScript.flightSkinDura["Flight002Skin003"] = serverAircraft_Phantom[10];
        ValueDeliverScript.flightSkinDura["Flight002Skin004"] = serverAircraft_Phantom[13];
        ValueDeliverScript.flightSkinDura["Flight002Skin005"] = serverAircraft_Phantom[16];


        ValueDeliverScript.skinLockOff["Flight000Skin001"] = serverAircraft_FokkerLock[0];
        ValueDeliverScript.skinLockOff["Flight000Skin002"] = serverAircraft_FokkerLock[1];
        ValueDeliverScript.skinLockOff["Flight000Skin003"] = serverAircraft_FokkerLock[2];
        ValueDeliverScript.skinLockOff["Flight000Skin004"] = serverAircraft_FokkerLock[3];
        ValueDeliverScript.skinLockOff["Flight000Skin005"] = serverAircraft_FokkerLock[4];

        //		Debug.Log ("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@  "+ValueDeliverScript.skinLockOff["Flight000Skin001"]+"  @@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        //		Debug.Log ("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@  "+ValueDeliverScript.skinLockOff["Flight000Skin002"]+"  @@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        //		Debug.Log ("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@  "+ValueDeliverScript.skinLockOff["Flight000Skin003"]+"  @@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        //		Debug.Log ("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@  "+ValueDeliverScript.skinLockOff["Flight000Skin004"]+"  @@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        //		Debug.Log ("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@  "+ValueDeliverScript.skinLockOff["Flight000Skin005"]+"  @@@@@@@@@@@@@@@@@@@@@@@@@@@@@");

        ValueDeliverScript.skinLockOff["Flight001Skin001"] = serverAircraft_ComancheLock[0];
        ValueDeliverScript.skinLockOff["Flight001Skin002"] = serverAircraft_ComancheLock[1];
        ValueDeliverScript.skinLockOff["Flight001Skin003"] = serverAircraft_ComancheLock[2];
        ValueDeliverScript.skinLockOff["Flight001Skin004"] = serverAircraft_ComancheLock[3];
        ValueDeliverScript.skinLockOff["Flight001Skin005"] = serverAircraft_ComancheLock[4];

        ValueDeliverScript.skinLockOff["Flight002Skin001"] = serverAircraft_PhantomLock[0];
        ValueDeliverScript.skinLockOff["Flight002Skin002"] = serverAircraft_PhantomLock[1];
        ValueDeliverScript.skinLockOff["Flight002Skin003"] = serverAircraft_PhantomLock[2];
        ValueDeliverScript.skinLockOff["Flight002Skin004"] = serverAircraft_PhantomLock[3];
        ValueDeliverScript.skinLockOff["Flight002Skin005"] = serverAircraft_PhantomLock[4];
		
		StartCoroutine(LoadHanger());

    }
	
	IEnumerator LoadHanger()
	{
        ForKaKao.instance._ui.text = "_LoadHanger_";
		yield return null;
		Time.timeScale = 1f;
        Application.LoadLevel(1);	
	}

    //내가 인터넷에서 긁어온 Md5메소드.
    public string Md5Sum(string input)
    {
        //ForKaKao.instance._ui.text += "Md5Sum00";
        byte[] data = Encoding.ASCII.GetBytes(input);
        //ForKaKao.instance._ui.text += "Md5Sum01";
        System.Security.Cryptography.MD5 md5 = new System.Security.Cryptography.MD5CryptoServiceProvider();
        //ForKaKao.instance._ui.text += "Md5Sum02";
        byte[] result = md5.ComputeHash(data);
        //ForKaKao.instance._ui.text += "Md5Sum03";

        ForKaKao.instance._ui.text += " Md5SumCompl_";

        //return Encoding.ASCII.GetString(result);
        return Convert.ToBase64String(result);
    }


    /*//수호씨가 짠것//
    public string Md5Sum(string input)
    {

        ForKaKao.instance._ui.text += "Md5Sum00";
        // step 1, calculate MD5 hash from input
        System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create();
        ForKaKao.instance._ui.text += "Md5Sum01";

        //byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);

        //ForKaKao.instance._ui.text += "Md5Sum01_1";

        //StringBuilder sBuilder = new StringBuilder();
        //ForKaKao.instance._ui.text += "Md5Sum01_2";

        //for (int i = 0; i < inputBytes.Length; i++)
        //{
        //    sBuilder.Append( inputBytes[i].ToString());
        //}
        //ForKaKao.instance._ui.text += "Md5Sum01_3";

        ForKaKao.instance._ui.text += "Md5Sum02";

        byte[] hash = md5.ComputeHash(Encoding.UTF8.GetBytes(input));
        ForKaKao.instance._ui.text += "Md5Sum03";


        // step 2, convert byte array to hex string
        StringBuilder sb = new StringBuilder();
        ForKaKao.instance._ui.text += "Md5Sum04";

        for (int i = 0; i < hash.Length; i++)
        {
            sb.Append(hash[i].ToString("X2"));
        }
        ForKaKao.instance._ui.text += "Md5Sum05";

        return sb.ToString();
    }
    */ //수호씨가 짠것//


    //↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓  게임아이템 DB 변수 ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓//		

    public void UserGameItemNuclearEquip(out int userGameItemNuclearEquip)	 //장착중 핵폭탄.
    {
        userGameItemNuclearEquip = int.Parse(serverGameItem[0]);
    }
    public void UserGameItemStrongEquip(out int userGameItemStrongEquip)	//장착중 강화품.
    {
        userGameItemStrongEquip = int.Parse(serverGameItem[1]);
    }
    public void UserGameItemSupporterEquip(out int userGameItemSupporterEquip)	// 장착중 보조품.
    {
        userGameItemSupporterEquip = int.Parse(serverGameItem[2]);
    }
    public void UserGameItemBoostEquip(out int userGameItemBoostEquip)	// 장착중 부스트.
    {
        userGameItemBoostEquip = int.Parse(serverGameItem[3]);
    }

    //↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓  인게임정보 DB 변수 ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓//	

    public void UserGameInfoPilotLevel(out int userGameInfoPilotLevel)	// 파이럿레벨.
    {
        userGameInfoPilotLevel = int.Parse(serverGameInfo[0]);
    }
    public void UserGameInfoPilotExp(out int userGameInfoPilotExp)	// 파일럿 경험치.
    {
        userGameInfoPilotExp = int.Parse(serverGameInfo[1]);
    }
    public void UserGameInfoFuelInfo(out int userGameInfoFuelInfo)	// 보유연료.
    {
        userGameInfoFuelInfo = int.Parse(serverGameInfo[2]);
    }
    public void UserGameInfoFuelTime(out int userGameInfoFuelTime)	// 생산시간.
    {
        userGameInfoFuelTime = int.Parse(serverGameInfo[3]);
    }
    public void UserGameInfoCoinInfo(out int userGameInfoCoinInfo)	// 보유코인.
    {
        userGameInfoCoinInfo = int.Parse(serverGameInfo[4]);
    }
    public void UserGameInfoMedalInfo(out int userGameInfoMedalInfo)	//보유훈장.
    {
        userGameInfoMedalInfo = int.Parse(serverGameInfo[5]);
    }
    public void UserGameInfoSocialPoint(out int userGameInfoSocialPoint)	 //소셜포인트.
    {
        userGameInfoSocialPoint = int.Parse(serverGameInfo[6]);
    }

    //↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓ 랭킹 관련 DB 변수 ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓//	

    public void RankingBestScore(out int rankingBestScore)	//금주 최고기록.
    {
        rankingBestScore = int.Parse(serverRakingInfo[0]);
    }
    public void BestScoreAircraft(out int bestScoreAircraft)	//최고기록기체.
    {
        bestScoreAircraft = int.Parse(serverRakingInfo[1]);
    }
    public void BestScoreNuclear(out int bestScoreNuclear)	//최고기록 핵폭탄.
    {
        bestScoreNuclear = int.Parse(serverRakingInfo[2]);
    }
    public void BestScoreStrong(out int bestScoreStrong) //최고기록 강화품.
    {
        bestScoreStrong = int.Parse(serverRakingInfo[3]);
    }
    public void BestScoreSupporter(out int bestScoreSupporter)	//최고기록 보조품.
    {
        bestScoreSupporter = int.Parse(serverRakingInfo[4]);
    }
    public void BestScoreBoost(out int bestScoreBoost)	// 최고기록 부스트.
    {
        bestScoreBoost = int.Parse(serverRakingInfo[5]);
    }
    public void SendFuelCheck(out int sendFuelCheck)	 // 연료발송 허락여부.
    {
        sendFuelCheck = int.Parse(serverRakingInfo[6]);
    }
    public void SendFuelTime(out int sendFuelTime)	// 연료발송 대기시간.
    {
        sendFuelTime = int.Parse(serverRakingInfo[7]);
    }

    //↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓ 메일 관련 DB 변수 ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓//	

    public void MailBoxType(out int mailBoxType)	//우편 타입.
    {
        mailBoxType = int.Parse(serverMailInfo[0]);
    }
    public void MailBoxRewardID(out int mailBoxRewardID)	// 보상ID.
    {
        mailBoxRewardID = int.Parse(serverMailInfo[1]);
    }
    public void MailBoxInviteTime(out int mailBoxInviteTime)	// 초대타임.
    {
        mailBoxInviteTime = int.Parse(serverMailInfo[2]);
    }

    //↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓ 아이템 부스트 DB 변수 ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓//	

    public void ItemSupportShieldCount(out int itemSupportShieldCount)	 //보호막 수량.
    {
        itemSupportShieldCount = int.Parse(serverItemSupport[0]);
    }
    public void ItemSupportMagnetStoneCount(out int itemSupportMagnetStoneCount)	//자석 수량.
    {
        itemSupportMagnetStoneCount = int.Parse(serverItemSupport[1]);
    }
    public void ItemSupportFastNuclearCount(out int itemSupportFastNuclearCount)	// 빠른핵폭탄.
    {
        itemSupportFastNuclearCount = int.Parse(serverItemSupport[2]);
    }
    public void ItemSupportSkillDrainCount(out int itemSupportSkillDrainCount)	//스킬드레인.
    {
        itemSupportSkillDrainCount = int.Parse(serverItemSupport[3]);
    }

    //↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓ 아이템 스트롱 DB 변수 ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓//	

    public void ItemStrongSingleAmplifierCount(out int itemStrongSingleAmplifierCount)	//싱글증폭기 수량.
    {
        itemStrongSingleAmplifierCount = int.Parse(serverItemStrong[0]);
    }
    public void ItemDuelAmplifierCount(out int itemStrongDuelAmplifierCount)	//듀얼증폭기 수량.
    {
        itemStrongDuelAmplifierCount = int.Parse(serverItemStrong[1]);
    }
    public void ItemStrongSpinballAmplifierCount(out int itemStrongSpinballAmplifierCount)	//스핀폴증폭기 수량.
    {
        itemStrongSpinballAmplifierCount = int.Parse(serverItemStrong[2]);
    }
    public void ItemStrongDartAmplifierCount(out int itemStrongDartAmplifierCount)	//다트증폭기 수량.
    {
        itemStrongDartAmplifierCount = int.Parse(serverItemStrong[3]);
    }
    public void ItemStrongDustAmplifierCount(out int itemStrongDustAmplifierCount)	//더스트증폭기 수량.
    {
        itemStrongDustAmplifierCount = int.Parse(serverItemStrong[4]);
    }
    public void ItemStrongShieldAmplifierCount(out int itemStrongShieldAmplifierCount)	//쉴드증폭기 수량.
    {
        itemStrongShieldAmplifierCount = int.Parse(serverItemStrong[5]);
    }
    public void ItemStrongDoubleCriticalCount(out int itemStrongDoubleCriticalCount)	 //크리티컬엑셀레이터 수량.
    {
        itemStrongDoubleCriticalCount = int.Parse(serverItemStrong[6]);
    }

    //↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓ 아이템 뉴클리어 DB 변수 ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓//

    public void ItemNuclearPlasmaWaveCount(out int itemNuclearPlasmaWaveCount)	//플라즈마웨이브 수량.
    {
        itemNuclearPlasmaWaveCount = int.Parse(serverItemNuclear[0]);
    }
    public void ItemNuclearFireStormCount(out int itemNuclearFireStormCount)	 //파이어스톰 수량.
    {
        itemNuclearFireStormCount = int.Parse(serverItemNuclear[1]);
    }
    public void ItemNuclearIceShieldCount(out int itemNuclearIceShieldCount)	//아이스쉴드 수량.
    {
        itemNuclearIceShieldCount = int.Parse(serverItemNuclear[2]);
    }
    public void ItemNuclearCycloneCount(out int itemNuclearCycloneCount)	//싸이클론봄 수량.
    {
        itemNuclearCycloneCount = int.Parse(serverItemNuclear[3]);
    }
    public void ItemNuclearBlackHoleCount(out int itemNuclearBlackHoleCount)	//블랙홀 수량.
    {
        itemNuclearBlackHoleCount = int.Parse(serverItemNuclear[4]);
    }

    //↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓ 아이템 부트스 DB 변수 ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓//	

    public void ItemBoostFinalPowerUpCount(out int itemBoostFinalPowerUpCount)	 //파이날파워업 수량.
    {
        itemBoostFinalPowerUpCount = int.Parse(serverItemBoost[0]);
    }
    public void ItemBoostSpinballDetectorCount(out int itemBoostSpinballDetectorCount)	 //스핀볼 탐지기 수량.
    {
        itemBoostSpinballDetectorCount = int.Parse(serverItemBoost[1]);
    }
    public void ItemBoostShieldDetectorCount(out int itemBoostShieldDetectorCount)	 //쉴드 탐지기 수량.
    {
        itemBoostShieldDetectorCount = int.Parse(serverItemBoost[2]);
    }
    public void ItemBoostDartDetectorCount(out int itemBoostDartDetectorCount)	 // 다트탐지기 수량.
    {
        itemBoostDartDetectorCount = int.Parse(serverItemBoost[3]);
    }
    public void ItemBoostDustDetectorCount(out int itemBoostDustDetectorCount)	 //더스트 탐지기 수량.
    {
        itemBoostDustDetectorCount = int.Parse(serverItemBoost[4]);
    }
    public void ItemBoostStrongWormholeCount(out int itemBoostStrongWormholeCount)	//스트롱 웜홀 수량.
    {
        itemBoostStrongWormholeCount = int.Parse(serverItemBoost[5]);
    }
    public void ItemBoostStrongDoubleWingboxCount(out int itemBoostDoubleWingboxCount)	//더블 윙박스 수량.
    {
        itemBoostDoubleWingboxCount = int.Parse(serverItemBoost[6]);
    }

    //↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓ 스폐셜 DB 변수 ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓//

    public void GameSpecialSpecialOngoing(out int gameSpecialSpecialOngoing)	//진행중 스폐셜 출격.
    {
        gameSpecialSpecialOngoing = int.Parse(serverGameSpecial[0]);
    }
    public void GameSpecialSpecialRate(out int gameSpecialSpecialRate)	 // 스폐셜 출격 달성율.
    {
        gameSpecialSpecialRate = int.Parse(serverGameSpecial[1]);
    }
    public void GameSpecialSpecialTime(out int gameSpecialSpecialTime)	 // 남은 스폐셜 출격시간.
    {
        gameSpecialSpecialTime = int.Parse(serverGameSpecial[2]);
    }
    public void GameSpecialEndTime(out string gameSpecialEndTime)	 // 남은 스폐셜 출격시간.
    {
        gameSpecialEndTime = serverGameSpecial[3];
    }
    public void GameSpecialAttackItemName(out string gameSpecialAttackItemName)	 // 남은 스폐셜 출격시간.
    {
        gameSpecialAttackItemName = serverGameSpecial[4];
    }
    public void GameSpecialAttackItemMaxNumber(out int gameSpecialAttackItemMaxNumber)	 // 남은 스폐셜 출격시간.
    {
        gameSpecialAttackItemMaxNumber = int.Parse(serverGameSpecial[5]);
    }
    public void GameSpecialGasLastAddTime(out string gameSpecialGasLastAddTime)	 // 남은 스폐셜 출격시간.
    {
        gameSpecialGasLastAddTime = serverGameSpecial[6];
    }
    public void GameSpecialGasNextAddTime(out string gameSpecialGasNextAddTime)	 // 남은 스폐셜 출격시간.
    {
        gameSpecialGasNextAddTime = serverGameSpecial[7];
    }
    public void GameSpecialTimeRecord(out int gameSpecialTimeRecord)	 // 남은 스폐셜 출격시간.
    {
        gameSpecialTimeRecord = int.Parse(serverGameSpecial[8]);
    }

    //↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓ 스페셜온 DB 변수 ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓//
    public void GameSpecialOnIsSpecialAttack(out bool gameSpecialOnIsSpecialAttack)	 // 스페셜출격 진행여부.
    {
        if (serverGameSpecialOn[0] == "False")
        {
            gameSpecialOnIsSpecialAttack = false;
        }
        else
        {
            gameSpecialOnIsSpecialAttack = true;
        }
    }

    public void GameSpecialOnSpecialAttack(out int gameSpecialOnSpecialAttack)	 // 진행중인 스페셜 출격.
    {
        gameSpecialOnSpecialAttack = int.Parse(serverGameSpecialOn[1]);
    }

    public void GameSpecialOnSpecialAttackOn(out bool gameSpecialOnSpecialAttackOn)	 // 진행중인 스페셜 출격.
    {
        if (serverGameSpecialOn[2] == "False")
        {
            gameSpecialOnSpecialAttackOn = false;
        }
        else
        {
            gameSpecialOnSpecialAttackOn = true;
        }
    }

    //↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓ 스페셜카운트 ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓//	

    public void GameSpecialCountDart(out int gameSpecialCountDart)
    {
        gameSpecialCountDart = int.Parse(serverGameSpecialCount[0]);
    }
    public void GameSpecialCountDust(out int gameSpecialCountDust)
    {
        gameSpecialCountDust = int.Parse(serverGameSpecialCount[1]);
    }
    public void GameSpecialCountShield(out int gameSpecialCountShield)
    {
        gameSpecialCountShield = int.Parse(serverGameSpecialCount[2]);
    }
    public void GameSpecialCountSpinball(out int gameSpecialCountSpinball)
    {
        gameSpecialCountSpinball = int.Parse(serverGameSpecialCount[3]);
    }

    //↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓ 팬텀 DB 변수 ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓//	

    public void Aircraft_PhantomBulletGrade(out int aircraft_PhantomBulletGrade)	// 팬텀 탄환 등급.
    {
        aircraft_PhantomBulletGrade = int.Parse(serverAircraft_Phantom[0]);
    }
    public void Aircraft_PhantomSkillGrade(out int aircraft_PhantomSkillGrade)	// 팬텀 스킬 등급.
    {
        aircraft_PhantomSkillGrade = int.Parse(serverAircraft_Phantom[1]);
    }
    public void Aircraft_PhantomSkinSelect(out int aircraft_PhantomSkinSelect)	// 선택중 스킨.
    {
        aircraft_PhantomSkinSelect = int.Parse(serverAircraft_Phantom[2]);
    }
    public void Aircraft_PhantomArchievementRateA(out int aircraft_PhantomArchievementRateA)	// A스킨 획득 조건 달성률.
    {
        aircraft_PhantomArchievementRateA = int.Parse(serverAircraft_Phantom[3]);
    }
    public void Aircraft_PhantomDurabilityA(out int aircraft_PhantomDurabilityA)	 //A스킨 내구도.
    {
        aircraft_PhantomDurabilityA = int.Parse(serverAircraft_Phantom[4]);
    }
    public void Aircraft_PhantomExpA(out int aircraft_PhantomExpA)	//A스킨 누적 경험치.
    {
        aircraft_PhantomExpA = int.Parse(serverAircraft_Phantom[5]);
    }
    public void Aircraft_PhantomArchievementRateB(out int aircraft_PhantomArchievementRateB)	// B스킨 획득 조건 달성률.
    {
        aircraft_PhantomArchievementRateB = int.Parse(serverAircraft_Phantom[6]);
    }
    public void Aircraft_PhantomDurabilityB(out int aircraft_PhantomDurabilityB)	//B스킨 내구도.
    {
        aircraft_PhantomDurabilityB = int.Parse(serverAircraft_Phantom[7]);
    }
    public void Aircraft_PhantomExpB(out int aircraft_PhantomExpB)	 //B스킨 누적 경험치.
    {
        aircraft_PhantomExpB = int.Parse(serverAircraft_Phantom[8]);
    }
    public void Aircraft_PhantomArchievementRateC(out int aircraft_PhantomArchievementRateC)	// C스킨 획득 조건 달성률.
    {
        aircraft_PhantomArchievementRateC = int.Parse(serverAircraft_Phantom[9]);
    }
    public void Aircraft_PhantomDurabilityC(out int aircraft_PhantomDurabilityC)	//C스킨 내구도.
    {
        aircraft_PhantomDurabilityC = int.Parse(serverAircraft_Phantom[10]);
    }
    public void Aircraft_PhantomExpC(out int aircraft_PhantomExpC)	//C스킨 누적 경험치.
    {
        aircraft_PhantomExpC = int.Parse(serverAircraft_Phantom[11]);
    }
    public void Aircraft_PhantomArchievementRateD(out int aircraft_PhantomArchievementRateD)	// D스킨 획득 조건 달성률.
    {
        aircraft_PhantomArchievementRateD = int.Parse(serverAircraft_Phantom[12]);
    }
    public void Aircraft_PhantomDurabilityD(out int aircraft_PhantomDurabilityD)	 //D스킨 내구도.
    {
        aircraft_PhantomDurabilityD = int.Parse(serverAircraft_Phantom[13]);
    }
    public void Aircraft_PhantomExpD(out int aircraft_PhantomExpD)	//D스킨 누적 경험치.
    {
        aircraft_PhantomExpD = int.Parse(serverAircraft_Phantom[14]);
    }
    public void Aircraft_PhantomArchievementRateE(out int aircraft_PhantomArchievementRateE)	// E스킨 획득 조건 달성률.
    {
        aircraft_PhantomArchievementRateE = int.Parse(serverAircraft_Phantom[15]);
    }
    public void Aircraft_PhantomDurabilityE(out int aircraft_PhantomDurabilityE)	//E스킨 내구도.
    {
        aircraft_PhantomDurabilityE = int.Parse(serverAircraft_Phantom[16]);
    }
    public void Aircraft_PhantomExpE(out int aircraft_PhantomExpE)	 //E스킨 누적 경험치.
    {
        aircraft_PhantomExpE = int.Parse(serverAircraft_Phantom[17]);
    }
    //	//↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓ 팬텀 스킨Lock DB 변수 ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓//	

    //↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓ 팬텀 스킨 DB 변수 ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓//	

    public void Aircraft_PhantomSkinKillSpinball(out int aircraft_PhantomSkinKillSpinball)
    {
        aircraft_PhantomSkinKillSpinball = int.Parse(serverAircraft_PhantomSkin[0]);
    }
    public void Aircraft_PhantomSkinSpecialAttack(out int aircraft_PhantomSkinSpecialAttack)
    {
        aircraft_PhantomSkinSpecialAttack = int.Parse(serverAircraft_PhantomSkin[1]);
    }
    public void Aircraft_PhantomSkinCompleteInstanceMission(out int aircraft_PhantomSkinCompleteInstanceMission)
    {
        aircraft_PhantomSkinCompleteInstanceMission = int.Parse(serverAircraft_PhantomSkin[2]);
    }
    public void Aircraft_PhantomSkinRescueFriend(out int aircraft_PhantomSkinRescueFriend)
    {
        aircraft_PhantomSkinRescueFriend = int.Parse(serverAircraft_PhantomSkin[3]);
    }
    public void Aircraft_PhantomSkinWormLevel5(out bool aircraft_PhantomSkinWormLevel5)
    {
        if (serverAircraft_PhantomSkin[4] == "False")
        {
            aircraft_PhantomSkinWormLevel5 = false;
        }
        else
        {
            aircraft_PhantomSkinWormLevel5 = true;
        }
    }

    //↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓ 포커 스킨Lock DB 변수 ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓//	

    //↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓ 포커 스킨 DB 변수 ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓//	

    public void Aircraft_FokkerSkinSortieNumber(out int aircraft_FokkerSkinSortieNumber)
    {
        aircraft_FokkerSkinSortieNumber = int.Parse(serverAircraft_FokkerSkin[0]);
    }
    public void Aircraft_FokkerSkinBombUseNumber(out int aircraft_FokkerSkinBombUseNumber)
    {
        aircraft_FokkerSkinBombUseNumber = int.Parse(serverAircraft_FokkerSkin[1]);
    }
    public void Aircraft_FokkerSkinScoreHigh(out int aircraft_FokkerSkinScoreHigh)
    {
        aircraft_FokkerSkinScoreHigh = int.Parse(serverAircraft_FokkerSkin[2]);

    }

    //↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓ 포커 DB 변수 ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓//	

    public void Aircraft_FokkerBulletGrade(out int aircraft_FokkerBulletGrade)
    {
        aircraft_FokkerBulletGrade = int.Parse(serverAircraft_Fokker[0]);
    }
    public void Aircraft_FokkerSkillGrade(out int aircraft_FokkerSkillGrade)
    {
        aircraft_FokkerSkillGrade = int.Parse(serverAircraft_Fokker[1]);
    }
    public void Aircraft_FokkerSkinSelect(out int aircraft_FokkerSkinSelect)
    {
        aircraft_FokkerSkinSelect = int.Parse(serverAircraft_Fokker[2]);
    }
    public void Aircraft_FokkerArchievementRateA(out int aircraft_FokkerArchievementRateA)
    {
        aircraft_FokkerArchievementRateA = int.Parse(serverAircraft_Fokker[3]);
    }
    public void Aircraft_FokkerDurabilityA(out int aircraft_FokkerDurabilityA)
    {
        aircraft_FokkerDurabilityA = int.Parse(serverAircraft_Fokker[4]);
    }
    public void Aircraft_FokkerExpA(out int aircraft_FokkerExpA)
    {
        aircraft_FokkerExpA = int.Parse(serverAircraft_Fokker[5]);
    }
    public void Aircraft_FokkerArchievementRateB(out int aircraft_FokkerArchievementRateB)
    {
        aircraft_FokkerArchievementRateB = int.Parse(serverAircraft_Fokker[6]);
    }
    public void Aircraft_FokkerDurabilityB(out int aircraft_FokkerDurabilityB)
    {
        aircraft_FokkerDurabilityB = int.Parse(serverAircraft_Fokker[7]);
    }
    public void Aircraft_FokkerExpB(out int aircraft_FokkerExpB)
    {
        aircraft_FokkerExpB = int.Parse(serverAircraft_Fokker[8]);
    }
    public void Aircraft_FokkerArchievementRateC(out int aircraft_FokkerArchievementRateC)
    {
        aircraft_FokkerArchievementRateC = int.Parse(serverAircraft_Fokker[9]);
    }
    public void Aircraft_FokkerDurabilityC(out int aircraft_FokkerDurabilityC)
    {
        aircraft_FokkerDurabilityC = int.Parse(serverAircraft_Fokker[10]);
    }
    public void Aircraft_FokkerExpC(out int aircraft_FokkerExpC)
    {
        aircraft_FokkerExpC = int.Parse(serverAircraft_Fokker[11]);
    }
    public void Aircraft_FokkerArchievementRateD(out int aircraft_FokkerArchievementRateD)
    {
        aircraft_FokkerArchievementRateD = int.Parse(serverAircraft_Fokker[12]);
    }
    public void Aircraft_FokkerDurabilityD(out int aircraft_FokkerDurabilityD)
    {
        aircraft_FokkerDurabilityD = int.Parse(serverAircraft_Fokker[13]);
    }
    public void Aircraft_FokkerExpD(out int aircraft_FokkerExpD)
    {
        aircraft_FokkerExpD = int.Parse(serverAircraft_Fokker[14]);
    }
    public void Aircraft_FokkerArchievementRateE(out int aircraft_FokkerArchievementRateE)
    {
        aircraft_FokkerArchievementRateE = int.Parse(serverAircraft_Fokker[15]);
    }
    public void Aircraft_FokkerDurabilityE(out int aircraft_FokkerDurabilityE)
    {
        aircraft_FokkerDurabilityE = int.Parse(serverAircraft_Fokker[16]);
    }
    public void Aircraft_FokkerExpE(out int aircraft_FokkerExpE)
    {
        aircraft_FokkerExpE = int.Parse(serverAircraft_Fokker[17]);
    }

    //↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓ 코만치 스킨 DB 변수 ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓//	

    public void Aircraft_ComancheSkinEnemyKill(out int aircraft_ComancheSkinEnemyKill)
    {
        aircraft_ComancheSkinEnemyKill = int.Parse(serverAircraft_ComancheSkin[0]);
    }
    public void Aircraft_ComancheSkinGetCoin(out int aircraft_ComancheSkinGetCoin)
    {
        aircraft_ComancheSkinGetCoin = int.Parse(serverAircraft_ComancheSkin[1]);
    }
    public void Aircraft_ComancheSkinUseSkill(out int aircraft_ComancheSkinUseSkill)
    {
        aircraft_ComancheSkinUseSkill = int.Parse(serverAircraft_ComancheSkin[2]);
    }
    public void Aircraft_ComancheSkinGetPower(out int aircraft_ComancheSkinGetPower)
    {
        aircraft_ComancheSkinGetPower = int.Parse(serverAircraft_ComancheSkin[3]);
    }

    //↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓ 코만치 스킨Lock DB 변수 ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓//	

    //    public void Aircraft_ComancheLock001(out bool aircraft_ComancheLock001)	
    //    {
    //        if(serverAircraft_ComancheLock[0] == "False")
    //		{
    //			aircraft_ComancheLock001 = false;    
    //		}
    //		else
    //		{
    //			aircraft_ComancheLock001 = true;	
    //		}
    //	}
    //	public void Aircraft_ComancheLock002(out bool aircraft_ComancheLock002)	
    //    {
    //        if(serverAircraft_ComancheLock[1] == "False")
    //		{
    //			aircraft_ComancheLock002 = false;    
    //		}
    //		else
    //		{
    //			aircraft_ComancheLock002 = true;	
    //		}
    //	}
    //	public void Aircraft_ComancheLock003(out bool aircraft_ComancheLock003)	
    //    {
    //        if(serverAircraft_ComancheLock[2] == "False")
    //		{
    //			aircraft_ComancheLock003 = false;    
    //		}
    //		else
    //		{
    //			aircraft_ComancheLock003 = true;	
    //		}
    //	}
    //	public void Aircraft_ComancheLock004(out bool aircraft_ComancheLock004)	
    //    {
    //        if(serverAircraft_ComancheLock[3] == "False")
    //		{
    //			aircraft_ComancheLock004 = false;    
    //		}
    //		else
    //		{
    //			aircraft_ComancheLock004 = true;	
    //		}
    //	} 
    //	public void Aircraft_ComancheLock005(out bool aircraft_ComancheLock005)	
    //    {
    //        if(serverAircraft_ComancheLock[4] == "False")
    //		{
    //			aircraft_ComancheLock005 = false;    
    //		}
    //		else
    //		{
    //			aircraft_ComancheLock005 = true;	
    //		}
    //	} 
    //↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓ 코만치 DB 변수 ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓//	

    public void Aircraft_ComancheBulletGrade(out int aircraft_ComancheBulletGrade)
    {
        aircraft_ComancheBulletGrade = int.Parse(serverAircraft_Comanche[0]);
    }
    public void Aircraft_ComancheSkillGrade(out int aircraft_ComancheSkillGrade)
    {
        aircraft_ComancheSkillGrade = int.Parse(serverAircraft_Comanche[1]);
    }
    public void Aircraft_ComancheSkinSelect(out int aircraft_ComancheSkinSelect)
    {
        aircraft_ComancheSkinSelect = int.Parse(serverAircraft_Comanche[2]);
    }
    public void Aircraft_ComancheArchievementRateA(out int aircraft_ComancheArchievementRateA)
    {
        aircraft_ComancheArchievementRateA = int.Parse(serverAircraft_Comanche[3]);
    }
    public void Aircraft_ComancheDurabilityA(out int aircraft_ComancheDurabilityA)
    {
        aircraft_ComancheDurabilityA = int.Parse(serverAircraft_Comanche[4]);
    }
    public void Aircraft_ComancheExpA(out int aircraft_ComancheExpA)
    {
        aircraft_ComancheExpA = int.Parse(serverAircraft_Comanche[5]);
    }
    public void Aircraft_ComancheArchievementRateB(out int aircraft_ComancheArchievementRateB)
    {
        aircraft_ComancheArchievementRateB = int.Parse(serverAircraft_Comanche[6]);
    }
    public void Aircraft_ComancheDurabilityB(out int aircraft_ComancheDurabilityB)
    {
        aircraft_ComancheDurabilityB = int.Parse(serverAircraft_Comanche[7]);
    }
    public void Aircraft_ComancheExpB(out int aircraft_ComancheExpB)
    {
        aircraft_ComancheExpB = int.Parse(serverAircraft_Comanche[8]);
    }
    public void Aircraft_ComancheArchievementRateC(out int aircraft_ComancheArchievementRateC)
    {
        aircraft_ComancheArchievementRateC = int.Parse(serverAircraft_Comanche[9]);
    }
    public void Aircraft_ComancheDurabilityC(out int aircraft_ComancheDurabilityC)
    {
        aircraft_ComancheDurabilityC = int.Parse(serverAircraft_Comanche[10]);
    }
    public void Aircraft_ComancheExpC(out int aircraft_ComancheExpC)
    {
        aircraft_ComancheExpC = int.Parse(serverAircraft_Comanche[11]);
    }
    public void Aircraft_ComancheArchievementRateD(out int aircraft_ComancheArchievementRateD)
    {
        aircraft_ComancheArchievementRateD = int.Parse(serverAircraft_Comanche[12]);
    }
    public void Aircraft_ComancheDurabilityD(out int aircraft_ComancheDurabilityD)
    {
        aircraft_ComancheDurabilityD = int.Parse(serverAircraft_Comanche[13]);
    }
    public void Aircraft_ComancheExpD(out int aircraft_ComancheExpD)
    {
        aircraft_ComancheExpD = int.Parse(serverAircraft_Comanche[14]);
    }
    public void Aircraft_ComancheArchievementRateE(out int aircraft_ComancheArchievementRateE)
    {
        aircraft_ComancheArchievementRateE = int.Parse(serverAircraft_Comanche[15]);
    }
    public void Aircraft_ComancheDurabilityE(out int aircraft_ComancheDurabilityE)
    {
        aircraft_ComancheDurabilityE = int.Parse(serverAircraft_Comanche[16]);
    }
    public void Aircraft_ComancheExpE(out int aircraft_ComancheExpE)
    {
        aircraft_ComancheExpE = int.Parse(serverAircraft_Comanche[17]);
    }

    //↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓ 비행기정보 DB 변수 ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓//	

    public void AircraftInfoAircraftSelect(out int aircraftInfoAircraftSelect)	 // 선택중인 기체.
    {
        aircraftInfoAircraftSelect = int.Parse(serverAircraftInfo[0]);
    }
    
}
