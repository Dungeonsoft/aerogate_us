using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using SimpleJSON;
using System.Text;
using System;

public class ForKaKao : MonoBehaviour {

    public UILabel _ui;

    public static ForKaKao instance;
    void Awake()
    {
        ForKaKao.instance = this;
    }

	// Use this for initialization
	void Start ()
    {
        
        string accessToken = PlayerPrefs.GetString(KakaoStringKey.access_token);
        string refreshToken = PlayerPrefs.GetString(KakaoStringKey.refresh_token);
        

        //���� ������ ������ �ڵ�. ó���� īī�� �α����� �������� �� �ڵ尡 �α����� �����ش�.
        //�α����� ������ �ٷ� ���ӽ����� ����.
        //KakaoNativeExtension.Instance.Init(accessToken, refreshToken, onInitComplete, onTokens);
       

        //��ξ��� ������ �ڵ�. ���ٸ� �����. ���ٿ� ���� ���ذ� �ʿ�.
        ///*
        KakaoNativeExtension.Instance.Init(accessToken, refreshToken,
            () =>
            {
                Debug.Log("> Post Initialized.");
                //KakaoNativeExtension.Instance.Unregister(onUnregisterComplete, onUnregisterError);

                KakaoNativeExtension.Instance.Unregister(
                    () => onInitComplete(),
                    (status, messageon) =>
                    {
                        _ui.text += "UnregisterFalse:" + status + ", " + messageon;
                        onInitComplete();
                    });
            }
            , onTokens);
        //*/
        //��ξ��� ������ �ڵ�. ���ٸ� �����. ���ٿ� ���� ���ذ� �ʿ�.


	}


    private void onAuthorized(bool _authorized)
    {
        if (_authorized == true)
        {
            //KakaoNativeExtension.Instance.ShowAlertMessage("Move to Main, Because Already finished Login Process!");
            //KakaoSample.Instance.moveToView(KakaoViewType.Main);
            _ui.text += " onAuthorized True";
            //StartCoroutine(UniqueLogin.instance.SetStart());    //��ξ� ����.

            //GetFriendInfo.instance.SetStart();
            UniqueLogin.instance.SetStart();   //���� ����.

        }
        else
        {
            //KakaoSample.Instance.moveToView(KakaoViewType.Login);
            _ui.text += " onAuthorized False";
            KakaoNativeExtension.Instance.Login(onLoginComplete, onLoginError);
        }
    }

    private void onInitComplete()
    {
        KakaoNativeExtension.Instance.Authorized(onAuthorized);
        _ui.text += "OnComplete";
    }
    private void onTokens(string accessToken, string refreshToken)
    {
        KakaoNativeExtension.Instance.updateTokenCache(accessToken, refreshToken);

        if (KakaoNativeExtension.Instance.hasValidTokenCache() == true)
        {
            //moveToView(KakaoViewType.Main);
            _ui.text += " onTokens True";

            //GetFriendInfo.instance.SetStart();
            UniqueLogin.instance.SetStart();   //���� ����.

        }
        else
        {
            //moveToView(KakaoViewType.Login);
            _ui.text += "onTokens False";
        }
    }

    private void onLoginComplete()
    {
        //KakaoNativeExtension.Instance.ShowAlertMessage("Login Success!");
        //StartCoroutine(UniqueLogin.instance.SetStart());    //��ξ� ����.

        //GetFriendInfo.instance.SetStart();
        _ui.text += "\n !OnLoginComp! ";
        //UniqueLogin.instance.SetStart();   //���� ����.

    }

    private void onLoginError(string status, string message)
    {
        //showAlertErrorMessage(status, message);
    }

    private void onUnregisterComplete()
    {
    }

    private void onUnregisterError(string status, string message)
    {
        _ui.text += "Unregister";
    }

    private void onLogoutComplete()
    {
    }

    private void onLogoutError(string status, string message)
    {
        _ui.text += "LogOut";
    }



}
