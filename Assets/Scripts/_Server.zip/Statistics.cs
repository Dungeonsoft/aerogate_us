using UnityEngine;
using System.Collections;

public class Statistics : MonoBehaviour {

	public string statisticsUrl = "http://leessoda.cafe24.com/statistics.php";
		
	void Start () 
	{
		StartCoroutine(StatisticChecker());
	}
	
	IEnumerator StatisticChecker()
	{
		WWW www = new WWW(statisticsUrl);
        yield return www;
		Debug.Log("==============  Statistics Data Complete   ==============");	
		//Debug.Log (www.text);
	}
	
}
