using UnityEngine;
using System.Collections;

public class UIManager : MonoBehaviour {

	public GameObject ServerManager;
	public GameObject okWindow;
	public GameObject signUpWindow;
	public GameObject signUpText;
	public GameObject signUpComplete;
	public GameObject welcomeWindow;
	
	
	void Start () {
	
	}
	
	
	void Update () 
	{
		if(Input.GetKey(KeyCode.Escape))
		{
			Application.Quit ();	
		}
	}
	
	void OkWindowClose()
	{
		okWindow.SetActive(false);	
	}
	
	void SignUpWindowClose()
	{
		signUpWindow.SetActive(false);
		Debug.Log("Sing Up!!!!!!!!!!!!");
	}
	
	void WelcomeWindowClose()
	{
		welcomeWindow.SetActive(false);
		
	}
	
	void WelcomeWindowOn()
	{
		welcomeWindow.SetActive(true);
	}
	
	void SignUpCompleteWindowOn()
	{
		signUpComplete.SetActive(true);	
	}
	
	void SignUpCompleteWindowClose()
	{
		Application.LoadLevel("DB_Test");
	}
}
