using UnityEngine;
using System.Collections;
using System.Text;
using System.Security;

public class PostUserGameInfo : MonoBehaviour
{

    public string PostUserGameItemUrl = "http://leessoda.cafe24.com/update_usergameitem.php";
    public string PostUserGameInfoUrl = "http://leessoda.cafe24.com/update_usergameinfo.php";
    public string PostRankingInfoUrl = "http://leessoda.cafe24.com/update_ranking.php";
    public string PostMailBoxInfoUrl = "http://leessoda.cafe24.com/update_mailinfo.php";
    public string PostItemSupportInfoUrl = "http://leessoda.cafe24.com/update_itemsupport.php";
    public string PostItemStrongInfoUrl = "http://leessoda.cafe24.com/update_itemstrong.php";
    public string PostItemNuclearInfoUrl = "http://leessoda.cafe24.com/update_itemnuclear.php";
    public string PostItemBoostInfoUrl = "http://leessoda.cafe24.com/update_boost.php";
    public string PostGameSpecialInfoUrl = "http://leessoda.cafe24.com/update_gamespecial.php";
    public string PostGameSpecialInfoOnUrl = "http://leessoda.cafe24.com/update_gamespecialon.php";
    public string PostGameSpecialInfoCountUrl = "http://leessoda.cafe24.com/update_gamespecialcount.php";
    public string PostPhantomInfoUrl = "http://leessoda.cafe24.com/update_phantom.php";
    public string PostPhantomLockInfoUrl = "http://leessoda.cafe24.com/update_phantomlock.php";
    public string PostPhantomSkinInfoUrl = "http://leessoda.cafe24.com/update_phantomskin.php";
    public string PostFokkerInfoUrl = "http://leessoda.cafe24.com/update_fokker.php";
    public string PostFokkerLockInfoUrl = "http://leessoda.cafe24.com/update_fokkerlock.php";
    public string PostFokkerSkinInfoUrl = "http://leessoda.cafe24.com/update_fokkerskin.php";
    public string PostComancheInfoUrl = "http://leessoda.cafe24.com/update_comanche.php";
    public string PostComancheLockInfoUrl = "http://leessoda.cafe24.com/update_comanchelock.php";
    public string PostComancheSkinInfoUrl = "http://leessoda.cafe24.com/update_comancheskin.php";
    public string PostAircraftInfoInfoUrl = "http://leessoda.cafe24.com/update_aircraftinfo.php";
    private string secretKey = "12345";
    string result;
    public int userUniqueNum;

    void Start()
    {
        userUniqueNum = PlayerPrefs.GetInt("UserUnique");

    }

    IEnumerator PostInfo()
    {
        yield return StartCoroutine(PostGameItem());
        yield return StartCoroutine(PostGameInfo());
        yield return StartCoroutine(PostRanking());
        yield return StartCoroutine(PostPhantom());
        yield return StartCoroutine(PostPhantomLock());
        yield return StartCoroutine(PostPhantomSkin());
        yield return StartCoroutine(PostFokker());
        yield return StartCoroutine(PostFokkerLock());
        yield return StartCoroutine(PostFokkerSkin());
        yield return StartCoroutine(PostComanche());
        yield return StartCoroutine(PostComancheLock());
        yield return StartCoroutine(PostComancheSkin());
        yield return StartCoroutine(PostItemStrong());
        yield return StartCoroutine(PostItemSupport());
        yield return StartCoroutine(PostItemNuclear());
        yield return StartCoroutine(PostGameSpecial());
        yield return StartCoroutine(PostGameSpecialOn());
        yield return StartCoroutine(PostGameSpecialCount());
        yield return StartCoroutine(PostItemBoost());
        yield return StartCoroutine(PostAircraft());
        yield return StartCoroutine(GetUserData());

    }
    IEnumerator GetUserData()
    {
        yield return null;
        GameObject.Find("GetUserInfoManager").SendMessage("GetGameInfo2");
    }
	
	IEnumerator GetUserDataWithRanking()
	{
		yield return null;
        GameObject.Find("GetUserInfoManager").SendMessage("GetGameInfo3");	
	}

    IEnumerator PostAircraftInfo()
    {
        yield return StartCoroutine(PostGameItem());
        yield return StartCoroutine(PostGameInfo());
        yield return StartCoroutine(PostRanking());
        yield return StartCoroutine(PostPhantom());
        yield return StartCoroutine(PostPhantomLock());
        yield return StartCoroutine(PostPhantomSkin());
        yield return StartCoroutine(PostFokker());
        yield return StartCoroutine(PostFokkerLock());
        yield return StartCoroutine(PostFokkerSkin());
        yield return StartCoroutine(PostComanche());
        yield return StartCoroutine(PostComancheLock());
        yield return StartCoroutine(PostComancheSkin());
        yield return StartCoroutine(PostItemStrong());
        yield return StartCoroutine(PostItemSupport());
        yield return StartCoroutine(PostItemNuclear());
        yield return StartCoroutine(PostGameSpecial());
        yield return StartCoroutine(PostGameSpecialOn());
        yield return StartCoroutine(PostGameSpecialCount());
        yield return StartCoroutine(PostItemBoost());
        yield return StartCoroutine(PostAircraft());

        Debug.Log("GameObject.Find(:::GameManager:::).SendMessage(:::LoadInGame02:::)");
        GameObject.Find("GameManager").SendMessage("LoadInGame02");
        //Application.LoadLevel("InGame01");
    }
	
	IEnumerator PostInfoWithGetRanking()
    {
        yield return StartCoroutine(PostGameItem());
        yield return StartCoroutine(PostGameInfo());
        yield return StartCoroutine(PostRanking());
        yield return StartCoroutine(PostPhantom());
        yield return StartCoroutine(PostPhantomLock());
        yield return StartCoroutine(PostPhantomSkin());
        yield return StartCoroutine(PostFokker());
        yield return StartCoroutine(PostFokkerLock());
        yield return StartCoroutine(PostFokkerSkin());
        yield return StartCoroutine(PostComanche());
        yield return StartCoroutine(PostComancheLock());
        yield return StartCoroutine(PostComancheSkin());
        yield return StartCoroutine(PostItemStrong());
        yield return StartCoroutine(PostItemSupport());
        yield return StartCoroutine(PostItemNuclear());
        yield return StartCoroutine(PostGameSpecial());
        yield return StartCoroutine(PostGameSpecialOn());
        yield return StartCoroutine(PostGameSpecialCount());
        yield return StartCoroutine(PostItemBoost());
        yield return StartCoroutine(PostAircraft());
        yield return StartCoroutine(GetUserDataWithRanking());		

    }

    IEnumerator PostGameItem()
    {
        yield return null;

        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = userUniqueNum;

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);
        form.AddField("UserGameItem_NuclearEquip", ValueDeliverScript.activeBomb);
        form.AddField("UserGameItem_StrongEquip", ValueDeliverScript.activeReinforce);
        form.AddField("UserGameItem_SupporterEquip", ValueDeliverScript.activeAssist);
        form.AddField("UserGameItem_BoostEquip", ValueDeliverScript.activeBoost);


        WWW www = new WWW(PostUserGameItemUrl, form);
        yield return www;

        result = www.text;
        if (result == "UserGameItemInsert")
        {
            Debug.Log(result);
            Debug.Log("======UserGameItem Info Insert======");
        }
    }

    IEnumerator PostGameInfo()
    {
        yield return null;

        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = userUniqueNum;

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);
        form.AddField("UserGameInfo_PilotLevel", ValueDeliverScript.userLevel);
        form.AddField("UserGameInfo_PilotExp", ValueDeliverScript.userExp);
        form.AddField("UserGameInfo_FuelInfo", ValueDeliverScript.gasRest);
        form.AddField("UserGameInfo_FuelTime", 5);
        form.AddField("UserGameInfo_CoinInfo", ValueDeliverScript.coinRest);
        form.AddField("UserGameInfo_MedalInfo", ValueDeliverScript.medalRest);
        form.AddField("UserGameInfo_SocialPoint", 5);

        WWW www = new WWW(PostUserGameInfoUrl, form);
        yield return www;

        result = www.text;
        if (result == "UserGameInfoInsert")
        {
            Debug.Log(result);
            Debug.Log("======UserGameInfo Info Insert======");
        }
    }

    IEnumerator PostRanking()
    {
        yield return null;

        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = userUniqueNum;

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);
        form.AddField("Ranking_BestScore", ValueDeliverScript.scoreHigh);
        form.AddField("Ranking_BestScoreAircraft", 3);
        form.AddField("Ranking_BestScoreNuclear", 10);
        form.AddField("Ranking_BestScoreStrong", 5);
        form.AddField("Ranking_BestScoreSupporter", 5);
        form.AddField("Ranking_BestScoreBoost", 5);
        form.AddField("Ranking_SendFuelCheck", 5);
        form.AddField("Ranking_SendFuelTime", 5);

        WWW www = new WWW(PostRankingInfoUrl, form);
        yield return www;

        result = www.text;
        if (result == "RankingInsert")
        {
            Debug.Log(result);
            Debug.Log("======Ranking Info Insert======");
        }
    }

    IEnumerator PostMail()
    {
        yield return null;

        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = userUniqueNum;

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);
        form.AddField("Mail_Type", 2);
        form.AddField("Mail_RewardID", 3);
        form.AddField("Mail_InviteTime", 10);

        WWW www = new WWW(PostMailBoxInfoUrl, form);
        yield return www;

        result = www.text;
        if (result == "MailboxInsert")
        {
            Debug.Log(result);
            Debug.Log("======Mailbox Info Insert======");
        }
    }

    IEnumerator PostItemSupport()
    {
        yield return null;

        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = userUniqueNum;

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);
        form.AddField("ItemSupport_ShieldCount", int.Parse(ValueDeliverScript.myEquip["Assist01"].ToString()));
        form.AddField("ItemSupport_MagnetStoneCount", int.Parse(ValueDeliverScript.myEquip["Assist02"].ToString()));
        form.AddField("ItemSupport_FastNuclearCount", int.Parse(ValueDeliverScript.myEquip["Assist03"].ToString()));
        form.AddField("ItemSupport_SkillDrainCount", int.Parse(ValueDeliverScript.myEquip["Assist04"].ToString()));

        WWW www = new WWW(PostItemSupportInfoUrl, form);
        yield return www;

        result = www.text;
        if (result == "ItemSupportInsert")
        {
            Debug.Log(result);
            Debug.Log("======ItemSupport Info Insert======");
        }
    }

    IEnumerator PostItemStrong()
    {
        yield return null;

        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = userUniqueNum;

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);
        form.AddField("ItemStrong_SingleAmplifierCount", int.Parse(ValueDeliverScript.myEquip["Reinforce01"].ToString()));
        form.AddField("ItemStrong_DuelAmplifierCount", int.Parse(ValueDeliverScript.myEquip["Reinforce02"].ToString()));
        form.AddField("ItemStrong_SpinballAmplifierCount", int.Parse(ValueDeliverScript.myEquip["Reinforce03"].ToString()));
        form.AddField("ItemStrong_DustAmplifierCount", int.Parse(ValueDeliverScript.myEquip["Reinforce04"].ToString()));
        form.AddField("ItemStrong_DartAmplifierCount", int.Parse(ValueDeliverScript.myEquip["Reinforce05"].ToString()));
        form.AddField("ItemStrong_ShieldAmplifierCount", int.Parse(ValueDeliverScript.myEquip["Reinforce06"].ToString()));
        form.AddField("ItemStrong_DoubleCriticalCount", int.Parse(ValueDeliverScript.myEquip["Reinforce07"].ToString()));

        WWW www = new WWW(PostItemStrongInfoUrl, form);
        yield return www;

        result = www.text;
        if (result == "ItemStrongInsert")
        {
            Debug.Log(result);
            Debug.Log("======ItemStrong Info Insert======");
        }
    }

    IEnumerator PostItemNuclear()
    {
        yield return null;

        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = userUniqueNum;

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);
        form.AddField("ItemNuclear_PlasmaWaveCount", int.Parse(ValueDeliverScript.myEquip["Bomb01"].ToString()));
        form.AddField("ItemNuclear_FireStormCount", int.Parse(ValueDeliverScript.myEquip["Bomb02"].ToString()));
        form.AddField("ItemNuclear_IceShieldCount", int.Parse(ValueDeliverScript.myEquip["Bomb03"].ToString()));
        form.AddField("ItemNuclear_CycloneCount", int.Parse(ValueDeliverScript.myEquip["Bomb04"].ToString()));
        form.AddField("ItemNuclear_BlackHoleCount", int.Parse(ValueDeliverScript.myEquip["Bomb05"].ToString()));

        WWW www = new WWW(PostItemNuclearInfoUrl, form);
        yield return www;

        result = www.text;
        if (result == "ItemNuclearInsert")
        {
            Debug.Log(result);
            Debug.Log("======ItemNuclear Info Insert======");
        }
    }

    IEnumerator PostItemBoost()
    {
        yield return null;

        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = userUniqueNum;

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);
        form.AddField("ItemBoost_FinalPowerUpCount", int.Parse(ValueDeliverScript.myEquip["Boost01"].ToString()));
        form.AddField("ItemBoost_SpinballDetectorCount", int.Parse(ValueDeliverScript.myEquip["Boost02"].ToString()));
        form.AddField("ItemBoost_ShieldDetectorCount", int.Parse(ValueDeliverScript.myEquip["Boost03"].ToString()));
        form.AddField("ItemBoost_DartDetectorCount", int.Parse(ValueDeliverScript.myEquip["Boost04"].ToString()));
        form.AddField("ItemBoost_DustDetectorCount", int.Parse(ValueDeliverScript.myEquip["Boost05"].ToString()));
        form.AddField("ItemBoost_StrongWormholeCount", int.Parse(ValueDeliverScript.myEquip["Boost06"].ToString()));
        form.AddField("ItemBoost_DoubleWingboxCount", int.Parse(ValueDeliverScript.myEquip["Boost07"].ToString()));

        WWW www = new WWW(PostItemBoostInfoUrl, form);
        yield return www;

        result = www.text;
        if (result == "ItemBoostInsert")
        {
            Debug.Log(result);
            Debug.Log("======ItemBoost Info Insert======");
        }
    }

    IEnumerator PostGameSpecial()
    {
        yield return null;

        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = userUniqueNum;

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);
        form.AddField("GameSpecial_SpecialOngoing", 2);
        form.AddField("GameSpecial_SpecialRate", 3);
        form.AddField("GameSpecial_SpecialTime", 10);
        form.AddField("GameSpecial_SpecialEndTime", ValueDeliverScript.specialEndTime);

        form.AddField("GameSpecial_SpecialAttackItemName", ValueDeliverScript.specialAttackItemName);
        form.AddField("GameSpecial_SpecialAttackItemMaxNumber", ValueDeliverScript.specialAttackItemMaxNumber);
        form.AddField("GameSpecial_GasLastAddTime", ValueDeliverScript.gasLastAddTime);
        form.AddField("GameSpecial_GasNextAddTime", ValueDeliverScript.gasNextAddTime);
        form.AddField("GameSpecial_TimeRecord", 1);

        WWW www = new WWW(PostGameSpecialInfoUrl, form);
        yield return www;

        result = www.text;

        if (result == "GameSpecialInsert")
        {
            Debug.Log(result);
            Debug.Log(ValueDeliverScript.specialEndTime);
            Debug.Log("======GameSpecial Info Insert======");
        }
    }
    IEnumerator PostGameSpecialOn()
    {
        yield return null;

        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = userUniqueNum;

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);
        form.AddField("GameSpecialOn_IsSpecialAttack", ValueDeliverScript.isSpecialAttack.ToString());
        form.AddField("GameSpecialOn_SpecialAttack", ValueDeliverScript.specialAttack);
        form.AddField("GameSpecialOn_SpecialAttackOn", ValueDeliverScript.specialAttackOn.ToString());

        WWW www = new WWW(PostGameSpecialInfoOnUrl, form);
        yield return www;

        result = www.text;

        if (result == "GameSpecialOnInsert")
        {
            Debug.Log(result);
            Debug.Log("====== GameSpecial On Info Insert ======");
        }
    }
    IEnumerator PostGameSpecialCount()
    {
        yield return null;

        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = userUniqueNum;

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);
        form.AddField("GameSpecialCount_Dart", ValueDeliverScript.dartCount);
        form.AddField("GameSpecialCount_Dust", ValueDeliverScript.dustCount);
        form.AddField("GameSpecialCount_Shield", ValueDeliverScript.shieldCount);
        form.AddField("GameSpecialCount_Spinball", ValueDeliverScript.spinballCount);

        WWW www = new WWW(PostGameSpecialInfoCountUrl, form);
        yield return www;

        result = www.text;

        if (result == "GameSpecialCountInsert")
        {
            Debug.Log(result);
            Debug.Log("====== GameSpecial Count Info Insert ======");
        }
    }
    IEnumerator PostPhantom()
    {
        yield return null;

        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = userUniqueNum;

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);
        form.AddField("Aircraft_Phantom_BulletGrade", ValueDeliverScript.flight002Bullet);
        form.AddField("Aircraft_Phantom_SkillGrade", ValueDeliverScript.flight002Skill);
        form.AddField("Aircraft_Phantom_SkinSelect", ValueDeliverScript.flight002Skin);
        form.AddField("Aircraft_Phantom_ArchievementRateA", 10);
        form.AddField("Aircraft_Phantom_DurabilityA", int.Parse(ValueDeliverScript.flightSkinDura["Flight002Skin001"].ToString()));
        form.AddField("Aircraft_Phantom_ExpA", int.Parse(ValueDeliverScript.flightSkinExp["Flight002Skin001"].ToString()));
        form.AddField("Aircraft_Phantom_ArchievementRateB", 2);
        form.AddField("Aircraft_Phantom_DurabilityB", int.Parse(ValueDeliverScript.flightSkinDura["Flight002Skin002"].ToString()));
        form.AddField("Aircraft_Phantom_ExpB", int.Parse(ValueDeliverScript.flightSkinExp["Flight002Skin002"].ToString()));
        form.AddField("Aircraft_Phantom_ArchievementRateC", 2);
        form.AddField("Aircraft_Phantom_DurabilityC", int.Parse(ValueDeliverScript.flightSkinDura["Flight002Skin003"].ToString()));
        form.AddField("Aircraft_Phantom_ExpC", int.Parse(ValueDeliverScript.flightSkinExp["Flight002Skin003"].ToString()));
        form.AddField("Aircraft_Phantom_ArchievementRateD", 2);
        form.AddField("Aircraft_Phantom_DurabilityD", int.Parse(ValueDeliverScript.flightSkinDura["Flight002Skin004"].ToString()));
        form.AddField("Aircraft_Phantom_ExpD", int.Parse(ValueDeliverScript.flightSkinExp["Flight002Skin004"].ToString()));
        form.AddField("Aircraft_Phantom_ArchievementRateE", 2);
        form.AddField("Aircraft_Phantom_DurabilityE", int.Parse(ValueDeliverScript.flightSkinDura["Flight002Skin005"].ToString()));
        form.AddField("Aircraft_Phantom_ExpE", int.Parse(ValueDeliverScript.flightSkinExp["Flight002Skin005"].ToString()));

        WWW www = new WWW(PostPhantomInfoUrl, form);
        yield return www;

        result = www.text;
        if (result == "PhantomInsert")
        {
            Debug.Log(result);
            Debug.Log("======Phantom Info Insert======");
        }
    }
    IEnumerator PostPhantomLock()
    {
        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = userUniqueNum;

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);
        form.AddField("Aircraft_Phantom_Lock_001", ValueDeliverScript.skinLockOff["Flight002Skin001"].ToString());
        form.AddField("Aircraft_Phantom_Lock_002", ValueDeliverScript.skinLockOff["Flight002Skin002"].ToString());
        form.AddField("Aircraft_Phantom_Lock_003", ValueDeliverScript.skinLockOff["Flight002Skin003"].ToString());
        form.AddField("Aircraft_Phantom_Lock_004", ValueDeliverScript.skinLockOff["Flight002Skin004"].ToString());
        form.AddField("Aircraft_Phantom_Lock_005", ValueDeliverScript.skinLockOff["Flight002Skin005"].ToString());

        WWW www = new WWW(PostPhantomLockInfoUrl, form);
        yield return www;

        result = www.text;
        Debug.Log(result);
        if (result == "PhantomLockInsert")
        {
            Debug.Log(result);
            Debug.Log("======Phantom Lock Info Insert======");
        }
    }
    IEnumerator PostPhantomSkin()
    {
        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = userUniqueNum;

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);
        form.AddField("Aircraft_Phantom_Skin_KillSpinball", ValueDeliverScript.flight002KillSpinball);
        form.AddField("Aircraft_Phantom_Skin_SpecialAttack", ValueDeliverScript.flight002SpecialAttack);
        form.AddField("Aircraft_Phantom_Skin_CompleteInstanceMission", ValueDeliverScript.flight002CompleteInstanceMission);
        form.AddField("Aircraft_Phantom_Skin_RescueFriend", ValueDeliverScript.flight002RescueFriend);
        form.AddField("Aircraft_Phantom_Skin_WormLevel5", ValueDeliverScript.flight002WormLevel5.ToString());

        WWW www = new WWW(PostPhantomSkinInfoUrl, form);
        yield return www;

        result = www.text;
        if (result == "PhantomSkinInsert")
        {
            Debug.Log(result);
            Debug.Log("======Phantom Skin Info Insert======");
        }
    }

    IEnumerator PostFokker()
    {
        yield return null;

        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = userUniqueNum;

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);
        form.AddField("Aircraft_Fokker_BulletGrade", ValueDeliverScript.flight000Bullet);
        form.AddField("Aircraft_Fokker_SkillGrade", ValueDeliverScript.flight000Skill);
        form.AddField("Aircraft_Fokker_SkinSelect", ValueDeliverScript.flight000Skin);
        form.AddField("Aircraft_Fokker_ArchievementRateA", 2);
        form.AddField("Aircraft_Fokker_DurabilityA", int.Parse(ValueDeliverScript.flightSkinDura["Flight000Skin001"].ToString()));
        form.AddField("Aircraft_Fokker_ExpA", int.Parse(ValueDeliverScript.flightSkinExp["Flight000Skin001"].ToString()));
        form.AddField("Aircraft_Fokker_ArchievementRateB", 2);
        form.AddField("Aircraft_Fokker_DurabilityB", int.Parse(ValueDeliverScript.flightSkinDura["Flight000Skin002"].ToString()));
        form.AddField("Aircraft_Fokker_ExpB", int.Parse(ValueDeliverScript.flightSkinExp["Flight000Skin002"].ToString()));
        form.AddField("Aircraft_Fokker_ArchievementRateC", 2);
        form.AddField("Aircraft_Fokker_DurabilityC", int.Parse(ValueDeliverScript.flightSkinDura["Flight000Skin003"].ToString()));
        form.AddField("Aircraft_Fokker_ExpC", int.Parse(ValueDeliverScript.flightSkinExp["Flight000Skin003"].ToString()));
        form.AddField("Aircraft_Fokker_ArchievementRateD", 2);
        form.AddField("Aircraft_Fokker_DurabilityD", int.Parse(ValueDeliverScript.flightSkinDura["Flight000Skin004"].ToString()));
        form.AddField("Aircraft_Fokker_ExpD", int.Parse(ValueDeliverScript.flightSkinExp["Flight000Skin004"].ToString()));
        form.AddField("Aircraft_Fokker_ArchievementRateE", 2);
        form.AddField("Aircraft_Fokker_DurabilityE", int.Parse(ValueDeliverScript.flightSkinDura["Flight000Skin005"].ToString()));
        form.AddField("Aircraft_Fokker_ExpE", int.Parse(ValueDeliverScript.flightSkinExp["Flight000Skin005"].ToString()));

        WWW www = new WWW(PostFokkerInfoUrl, form);
        yield return www;

        result = www.text;
        if (result == "FokkerInsert")
        {
            Debug.Log(result);
            Debug.Log("======Fokker Info Insert======");
        }
    }

    IEnumerator PostFokkerLock()
    {
        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = userUniqueNum;

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);
        form.AddField("Aircraft_Fokker_Lock_001", ValueDeliverScript.skinLockOff["Flight000Skin001"].ToString());
        form.AddField("Aircraft_Fokker_Lock_002", ValueDeliverScript.skinLockOff["Flight000Skin002"].ToString());
        form.AddField("Aircraft_Fokker_Lock_003", ValueDeliverScript.skinLockOff["Flight000Skin003"].ToString());
        form.AddField("Aircraft_Fokker_Lock_004", ValueDeliverScript.skinLockOff["Flight000Skin004"].ToString());
        form.AddField("Aircraft_Fokker_Lock_005", ValueDeliverScript.skinLockOff["Flight000Skin005"].ToString());

        WWW www = new WWW(PostFokkerLockInfoUrl, form);
        yield return www;

        result = www.text;

        Debug.Log(result);
        if (result == "FokkerLockInsert")
        {
            Debug.Log(result);
            Debug.Log("======Fokker Lock Info Insert======");
        }
    }

    IEnumerator PostFokkerSkin()
    {
        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = userUniqueNum;

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);
        form.AddField("Aircraft_Fokker_Skin_SortieNumber", ValueDeliverScript.flight000Bullet);
        form.AddField("Aircraft_Fokker_Skin_BombUseNumber", ValueDeliverScript.flight000Skill);
        form.AddField("Aircraft_Fokker_Skin_ScoreHigh", ValueDeliverScript.flight000Skin);

        WWW www = new WWW(PostFokkerSkinInfoUrl, form);
        yield return www;

        result = www.text;
        if (result == "FokkerSkinInsert")
        {
            Debug.Log(result);
            Debug.Log("======Fokker Skin Info Insert======");
        }
    }

    IEnumerator PostComanche()
    {
        yield return null;

        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = userUniqueNum;

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);
        form.AddField("Aircraft_Comanche_BulletGrade", ValueDeliverScript.flight001Bullet);
        form.AddField("Aircraft_Comanche_SkillGrade", ValueDeliverScript.flight001Skill);
        form.AddField("Aircraft_Comanche_SkinSelect", ValueDeliverScript.flight001Skin);
        form.AddField("Aircraft_Comanche_ArchievementRateA", 2);
        form.AddField("Aircraft_Comanche_DurabilityA", int.Parse(ValueDeliverScript.flightSkinDura["Flight001Skin001"].ToString()));
        form.AddField("Aircraft_Comanche_ExpA", int.Parse(ValueDeliverScript.flightSkinExp["Flight001Skin001"].ToString()));
        form.AddField("Aircraft_Comanche_ArchievementRateB", 2);
        form.AddField("Aircraft_Comanche_DurabilityB", int.Parse(ValueDeliverScript.flightSkinDura["Flight001Skin002"].ToString()));
        form.AddField("Aircraft_Comanche_ExpB", int.Parse(ValueDeliverScript.flightSkinExp["Flight001Skin002"].ToString()));
        form.AddField("Aircraft_Comanche_ArchievementRateC", 2);
        form.AddField("Aircraft_Comanche_DurabilityC", int.Parse(ValueDeliverScript.flightSkinDura["Flight001Skin003"].ToString()));
        form.AddField("Aircraft_Comanche_ExpC", int.Parse(ValueDeliverScript.flightSkinExp["Flight001Skin003"].ToString()));
        form.AddField("Aircraft_Comanche_ArchievementRateD", 2);
        form.AddField("Aircraft_Comanche_DurabilityD", int.Parse(ValueDeliverScript.flightSkinDura["Flight001Skin004"].ToString()));
        form.AddField("Aircraft_Comanche_ExpD", int.Parse(ValueDeliverScript.flightSkinExp["Flight001Skin004"].ToString()));
        form.AddField("Aircraft_Comanche_ArchievementRateE", 2);
        form.AddField("Aircraft_Comanche_DurabilityE", int.Parse(ValueDeliverScript.flightSkinDura["Flight001Skin005"].ToString()));
        form.AddField("Aircraft_Comanche_ExpE", int.Parse(ValueDeliverScript.flightSkinExp["Flight001Skin005"].ToString()));

        WWW www = new WWW(PostComancheInfoUrl, form);
        yield return www;

        result = www.text;
        if (result == "ComancheInsert")
        {
            Debug.Log(result);
            Debug.Log("======Comanche Info Insert======");
        }
    }

    IEnumerator PostComancheLock()
    {
        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = userUniqueNum;

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);
        form.AddField("Aircraft_Comanche_Lock_001", ValueDeliverScript.skinLockOff["Flight001Skin001"].ToString());
        form.AddField("Aircraft_Comanche_Lock_002", ValueDeliverScript.skinLockOff["Flight001Skin002"].ToString());
        form.AddField("Aircraft_Comanche_Lock_003", ValueDeliverScript.skinLockOff["Flight001Skin003"].ToString());
        form.AddField("Aircraft_Comanche_Lock_004", ValueDeliverScript.skinLockOff["Flight001Skin004"].ToString());
        form.AddField("Aircraft_Comanche_Lock_005", ValueDeliverScript.skinLockOff["Flight001Skin005"].ToString());

        WWW www = new WWW(PostComancheLockInfoUrl, form);
        yield return www;

        result = www.text;
        Debug.Log(result);
        if (result == "ComancheLockInsert")
        {
            Debug.Log(result);
            Debug.Log("======Comanche Lock Info Insert======");
        }
    }

    IEnumerator PostComancheSkin()
    {
        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = userUniqueNum;

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);
        form.AddField("Aircraft_Comanche_Skin_EnemyKill", ValueDeliverScript.flight001EnemyKill);
        form.AddField("Aircraft_Comanche_Skin_GetCoin", ValueDeliverScript.flight001GetCoin);
        form.AddField("Aircraft_Comanche_Skin_UseSkill", ValueDeliverScript.flight001UseSkill);
        form.AddField("Aircraft_Comanche_Skin_GetPower", ValueDeliverScript.flight001GetPowerItem);

        WWW www = new WWW(PostComancheSkinInfoUrl, form);
        yield return www;

        result = www.text;
        if (result == "ComancheSkinInsert")
        {
            Debug.Log(result);
            Debug.Log("======Comanche Skin Info Insert======");
        }
    }

    IEnumerator PostAircraft()
    {
        yield return null;

        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = userUniqueNum;

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);
        form.AddField("AircraftInfo_AircraftSelect", ValueDeliverScript.flightNumber);
        form.AddField("AircraftInfo_FokkerLock", 1);
        form.AddField("AircraftInfo_ComancheLock", ValueDeliverScript.flightLockOff["Flight001"].ToString());
        form.AddField("AircraftInfo_PhantomLock", ValueDeliverScript.flightLockOff["Flight002"].ToString());

        WWW www = new WWW(PostAircraftInfoInfoUrl, form);
        yield return www;

        result = www.text;
        if (result == "AircraftInfoInsert")
        {
            Debug.Log(result);
            Debug.Log("======Aircraft Info Insert======");
        }
    }

    public string Md5Sum(string input)
    {
        // step 1, calculate MD5 hash from input
        System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create();
        byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
        byte[] hash = md5.ComputeHash(inputBytes);

        // step 2, convert byte array to hex string
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < hash.Length; i++)
        {
            sb.Append(hash[i].ToString("X2"));
        }
        return sb.ToString();
    }
}
