using UnityEngine;
using System.Collections;


public class LogIn : MonoBehaviour  //현재 쓰지 않는 스크립트. 차후에 지워야 될것임.
{

    string deviceName;
    string phoneNumber;

    public int[] scoreDividRange;

    Player[] playerList;
    Player[] friendSelected;

    public static LogIn instance;

    void Awake()
    {
        LogIn.instance = this;
    }

   public void SetStart()
    {
        if (!ValueDeliverScript.isTableGet)
        {
            string friendsData = "friendB?5000?1?3&friendC?7000?1?4&friendG?9500?1?10&friendE?11000?1?7&friendF?13000?1?9&friendH?15000?1?4&friendAE?15300?1?6&friendI?16800?1?5&friendJ?18900?1?7&friendV?21100?3?1&friendL?21300?3?2&friendK?21300?3?2&friendS?22500?3?1&friendM?23300?3?1&friendN?25600?3?2&friendO?27000?3?4&friendP?31500?3?3&friendQ?33200?3?1&friendR?37200?3?5&friendU?37250?3?6&friendJR?38956?3?7&friendT?44500?3?6&friendY?47130?3?9&friendW?51600?3?8&friendZ?57900?3?13&friendAA?72370?4?6&friendAF?73689?3?22&friendAC?81300?3?16&friendAG?91452?4?8&friendAB?95700?4?18&flightABCtest?113500?4?15&friendAD?123575?4?23&friendA?140000?4?15&FriendNull?2147483647?1?1&";
            //Debug.Log("getFriendData" + friendsData);
            string[] friendDataByName;
            friendDataByName = friendsData.Split('&');
            //			Debug.Log ("friendDataLength ::: " + friendDataByName.Length);

            playerList = new Player[friendDataByName.Length - 1];
            for (int i = 0; i < friendDataByName.Length - 1; i++)
            {
                string[] dataTable = friendDataByName[i].Split('?');
                Player friendlistSub = new Player();
                //				Debug.Log(dataTable[0] + ", " + dataTable[1] + " , " + dataTable[2] + " , " + dataTable[3]);

                friendlistSub.friendName = dataTable[0];
                friendlistSub.friendScore = int.Parse(dataTable[1]);
                friendlistSub.friendFlightNumber = int.Parse(dataTable[2]);
                friendlistSub.friendBulletNumber = int.Parse(dataTable[3]);
                playerList[i] = friendlistSub;
                //				Debug.Log ("friendJail[" + i + "] ::: " + friendJail[i].friendName + " , " +  friendJail[i].friendScore + " , " +  friendJail[i].friendFlightNumber + " , " +  friendJail[i].friendBulletNumber );
            }
            //						}	//여기까지 해서 서버에 있는 유저 데이터 정리.
            ValueDeliverScript.friendJail = playerList;
        }

        playerList = ValueDeliverScript.friendJail;

        // 범위값 안에서 랜덤하게 친구 선택.----시작.
        int rangeStartNumber = 0;
        friendSelected = new Player[scoreDividRange.Length];

        //				Debug.Log ("scoreDividRange" + scoreDividRange.Length); 	//한명의 친구를 고르는 범위값의 수.
        //				Debug.Log ("friendJail.Length ::: " + playerList.Length);	//현재 나의 친구 목록의 수.

        for (int i = 0; i < scoreDividRange.Length; i++)
        {
            //			Debug.Log ("Number of I :::::: " + i);
            for (int j = 0; j < playerList.Length; j++)
            {
                //				Debug.Log ("friendJail["+j+"].friendScore :::: "+friendJail[j].friendScore);
                //				Debug.Log ("Number of J :::::: " + j);
                if (playerList[j].friendScore > scoreDividRange[i] || playerList[playerList.Length - 1].friendScore == 0)
                {
                    if (playerList[playerList.Length - 1].friendScore == 0)
                        Debug.Log("Final Count!!!");

                    if (j > 0 && rangeStartNumber <= j)
                    {
                        int randomSelNum = Random.Range(rangeStartNumber, j);
                        rangeStartNumber = j;
                        if (playerList[randomSelNum].friendScore <= scoreDividRange[i])
                        {
                            friendSelected[i] = playerList[randomSelNum];
                            //														Debug.Log ("friendSelected[" + i + "] ::::: " + friendSelected[i].friendName + " , " + friendSelected[i].friendScore + " , "  + friendSelected[i].friendFlightNumber +  " , " + friendSelected[i].friendBulletNumber);
                            //							Debug.Log ("Break1");
                            //							break;
                        }
                        //						Debug.Log ("Break2");
                        break;
                    }
                }
            }
        }

        //Debug.Log ("friendSelected Length :::: " + friendSelected.Length + " ::::"); //배열의 길이가 얼마인지 검사.
        for (int i = 0; i < friendSelected.Length; i++)
        {	//배열에서 친구 이름만 골라서 출력.
            if (friendSelected[i] != null)
            {
            }
            //								Debug.Log (friendSelected[i].friendName);
        }

        ValueDeliverScript.friendForRescue = friendSelected;

    }

}
