using UnityEngine;
using System.Collections;
using System.Text;
using System.Security;

public class InitailizingUserInfo : MonoBehaviour
{
    public string InitRankingInfoUrl = "http://leessoda.cafe24.com/ranking_record.php";
    public string InitMailBoxUrl = "http://leessoda.cafe24.com/mailbox_record.php";
    public string InitGameInfoUrl = "http://leessoda.cafe24.com/gameinfo_record.php";
    public string InitGameItemUrl = "http://leessoda.cafe24.com/iteminfo_record.php";
    public string InitItemSupportUrl = "http://leessoda.cafe24.com/itemsupport_record.php";
    public string InitItemStrongUrl = "http://leessoda.cafe24.com/itemstrong_record.php";
    public string InitItemNuclearUrl = "http://leessoda.cafe24.com/itemnuclear_record.php";
    public string InitItemBoostUrl = "http://leessoda.cafe24.com/itemboost_record.php";
    public string InitPhantomUrl = "http://leessoda.cafe24.com/phantom_record.php";
    public string InitPhantomLockUrl = "http://leessoda.cafe24.com/phantomlock_record.php";
    public string InitPhantomSkinUrl = "http://leessoda.cafe24.com/phantomskin_record.php";
    public string InitFokkerUrl = "http://leessoda.cafe24.com/forkker_record.php";
    public string InitFokkerLockUrl = "http://leessoda.cafe24.com/forkkerlock_record.php";
    public string InitFokkerSkinUrl = "http://leessoda.cafe24.com/forkkerskin_record.php";
    public string InitComancheUrl = "http://leessoda.cafe24.com/comanche_record.php";
    public string InitComancheLockUrl = "http://leessoda.cafe24.com/comanchelock_record.php";
    public string InitComancheSkinUrl = "http://leessoda.cafe24.com/comancheskin_record.php";
    public string InitSpecialUrl = "http://leessoda.cafe24.com/special_record.php";
    public string InitSpecialOnUrl = "http://leessoda.cafe24.com/specialon_record.php";
    public string InitSpecialCountUrl = "http://leessoda.cafe24.com/specialcount_record.php";
    public string InitAircraftUrl = "http://leessoda.cafe24.com/aircraft_record.php";

    public GameObject loadingLog;
    public float loadingPercent = 0;
    public GameObject loadingBar;
    private string secretKey = "12345";
    private string result;

    void Update()
    {
        loadingLog.GetComponent<UILabel>().text = result;
        loadingBar.GetComponent<UISlider>().sliderValue = loadingPercent;
    }

    IEnumerator Initializing()
    {

        yield return new WaitForSeconds(0.5f);

        yield return StartCoroutine(RankingInfo());

        yield return StartCoroutine(UserGameInfo());

        yield return StartCoroutine(UserItemInfo());

        yield return StartCoroutine(MailInfo());

        yield return StartCoroutine(ItemSupportInfo());

        yield return StartCoroutine(ItemStrongInfo());

        yield return StartCoroutine(ItemNuclearInfo());

        yield return StartCoroutine(ItemBoostInfo());

        yield return StartCoroutine(GameSpecialInfo());

        yield return StartCoroutine(GameSpecialOnInfo());

        yield return StartCoroutine(GameSpecialCountInfo());

        yield return StartCoroutine(PhantomInfo());

        yield return StartCoroutine(PhantomLockInfo());

        yield return StartCoroutine(PhantomSkinInfo());

        yield return StartCoroutine(ForkkerInfo());

        yield return StartCoroutine(ForkkerSkinInfo());

        yield return StartCoroutine(ForkkerLockInfo());

        yield return StartCoroutine(ComancheInfo());

        yield return StartCoroutine(ComancheLockInfo());

        yield return StartCoroutine(ComancheSkinInfo());

        yield return StartCoroutine(AirCraftInfo());

        UniqueLogin.userInitialize = 1;

        PlayerPrefs.SetInt("userInitalizing", UniqueLogin.userInitialize);
        PlayerPrefs.SetInt("UserUnique", NewIDRecord.userNumber);
        loadingPercent = 1.0f;
        result = "All Initialize Complete!!!";
        yield return new WaitForSeconds(0.2f);
        Debug.Log("Load Next Game Scene !!!!!!!!!!!!!!!!");
        Application.LoadLevel(0);
    }

    IEnumerator RankingInfo()
    {
        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = NewIDRecord.userNumber;
        yield return new WaitForSeconds(0.1f);

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);

        WWW www = new WWW(InitRankingInfoUrl, form);
        yield return www;

        result = www.text;
        Debug.Log(result);

        if (result == "RankingUpdate")
        {
            Debug.Log("Ranking Initializing Complete!!!");
            loadingPercent += 0.025f;
        }

    }

    IEnumerator UserGameInfo()
    {
        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = NewIDRecord.userNumber;

        yield return new WaitForSeconds(0.1f);

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);

        WWW www = new WWW(InitGameInfoUrl, form);
        yield return www;

        result = www.text;

        if (result == "UserGameInfoUpdate")
        {
            Debug.Log("UserGameInfo Initializing Complete!!!");
            loadingPercent += 0.025f;
        }
    }

    IEnumerator UserItemInfo()
    {
        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = NewIDRecord.userNumber;

        yield return new WaitForSeconds(0.1f);

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);

        WWW www = new WWW(InitGameItemUrl, form);
        yield return www;

        result = www.text;

        if (result == "UserItemInfoUpdate")
        {
            Debug.Log("UserItemInfo Initializing Complete!!!");
            loadingPercent += 0.1f;
        }
    }

    IEnumerator MailInfo()
    {
        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = NewIDRecord.userNumber;

        yield return new WaitForSeconds(0.1f);

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);

        WWW www = new WWW(InitMailBoxUrl, form);
        yield return www;

        result = www.text;

        if (result == "MailUpdate")
        {
            Debug.Log("Mailinfo Initializing Complete!!!");
            loadingPercent += 0.1f;
        }

    }

    IEnumerator ItemSupportInfo()
    {
        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = NewIDRecord.userNumber;

        yield return new WaitForSeconds(0.1f);

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);

        WWW www = new WWW(InitItemSupportUrl, form);
        yield return www;

        result = www.text;

        if (result == "ItemSupportUpdate")
        {
            Debug.Log("ItemSupport Initializing Complete!!!");
            loadingPercent += 0.1f;
        }

    }

    IEnumerator ItemStrongInfo()
    {
        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = NewIDRecord.userNumber;

        yield return new WaitForSeconds(0.1f);

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);

        WWW www = new WWW(InitItemStrongUrl, form);
        yield return www;

        result = www.text;

        if (result == "ItemStrongUpdate")
        {
            Debug.Log("ItemStrong Initializing Complete!!!");
            loadingPercent += 0.1f;
        }
    }

    IEnumerator ItemNuclearInfo()
    {
        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = NewIDRecord.userNumber;

        yield return new WaitForSeconds(0.1f);

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);

        WWW www = new WWW(InitItemNuclearUrl, form);
        yield return www;

        result = www.text;

        if (result == "ItemNuclearUpdate")
        {
            Debug.Log("ItemNuclear Initializing Complete!!!");
            loadingPercent += 0.1f;
        }
    }

    IEnumerator ItemBoostInfo()
    {
        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = NewIDRecord.userNumber;

        yield return new WaitForSeconds(0.1f);

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);

        WWW www = new WWW(InitItemBoostUrl, form);
        yield return www;

        result = www.text;

        if (result == "ItemBoostUpdate")
        {
            Debug.Log("ItemBoost Initializing Complete!!!");
            loadingPercent += 0.1f;
        }
    }

    IEnumerator GameSpecialInfo()
    {
        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = NewIDRecord.userNumber;

        yield return new WaitForSeconds(0.1f);

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);

        WWW www = new WWW(InitSpecialUrl, form);
        yield return www;

        result = www.text;

        if (result == "SpecialInfoUpdate")
        {
            Debug.Log("SpecialInfo Initializing Complete!!!");
            loadingPercent += 0.05f;
        }
    }

    IEnumerator GameSpecialOnInfo()
    {
        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = NewIDRecord.userNumber;

        yield return new WaitForSeconds(0.1f);

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);

        WWW www = new WWW(InitSpecialOnUrl, form);
        yield return www;

        result = www.text;

        if (result == "SpecialOnInfoUpdate")
        {
            Debug.Log("SpecialOnInfo Initializing Complete!!!");
            loadingPercent += 0.05f;
        }
    }

    IEnumerator GameSpecialCountInfo()
    {
        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = NewIDRecord.userNumber;

        yield return new WaitForSeconds(0.1f);

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);

        WWW www = new WWW(InitSpecialCountUrl, form);
        yield return www;

        result = www.text;

        if (result == "SpecialCountInfoUpdate")
        {
            Debug.Log("SpecialCountInfo Initializing Complete!!!");
            loadingPercent += 0.05f;
        }
    }

    IEnumerator ForkkerInfo()
    {
        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = NewIDRecord.userNumber;

        yield return new WaitForSeconds(0.1f);

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);

        WWW www = new WWW(InitFokkerUrl, form);
        yield return www;

        result = www.text;

        if (result == "FokkerUpdate")
        {
            Debug.Log("Fokker Initializing Complete!!!");
            loadingPercent += 0.1f;
        }
    }

    IEnumerator ForkkerLockInfo()
    {
        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = NewIDRecord.userNumber;

        yield return new WaitForSeconds(0.1f);

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);

        WWW www = new WWW(InitFokkerLockUrl, form);
        yield return www;

        result = www.text;

        if (result == "FokkerLockUpdate")
        {
            Debug.Log("Fokker Lock Initializing Complete!!!");
            loadingPercent += 0.1f;
        }
    }


    IEnumerator ForkkerSkinInfo()
    {
        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = NewIDRecord.userNumber;

        yield return new WaitForSeconds(0.1f);

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);

        WWW www = new WWW(InitFokkerSkinUrl, form);
        yield return www;

        result = www.text;

        if (result == "FokkerSkinUpdate")
        {
            Debug.Log("Fokker Skin Initializing Complete!!!");
            loadingPercent += 0.1f;
        }
    }

    IEnumerator ComancheInfo()
    {
        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = NewIDRecord.userNumber;

        yield return new WaitForSeconds(0.2f);

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);

        WWW www = new WWW(InitComancheUrl, form);
        yield return www;

        result = www.text;

        if (result == "ComancheUpdate")
        {
            Debug.Log("Comanche Initializing Complete!!!");
            loadingPercent += 0.1f;
        }
    }

    IEnumerator ComancheLockInfo()
    {
        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = NewIDRecord.userNumber;

        yield return new WaitForSeconds(0.1f);

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);

        WWW www = new WWW(InitComancheLockUrl, form);
        yield return www;

        result = www.text;

        if (result == "ComancheLockUpdate")
        {
            Debug.Log("Comanche Lock Initializing Complete!!!");
            loadingPercent += 0.1f;
        }
    }
    IEnumerator ComancheSkinInfo()
    {
        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = NewIDRecord.userNumber;

        yield return new WaitForSeconds(0.1f);

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);

        WWW www = new WWW(InitComancheSkinUrl, form);
        yield return www;

        result = www.text;

        if (result == "ComancheSkinUpdate")
        {
            Debug.Log("Comanche Skin Initializing Complete!!!");
            loadingPercent += 0.1f;
        }
    }

    IEnumerator PhantomInfo()
    {
        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = NewIDRecord.userNumber;

        yield return new WaitForSeconds(0.1f);

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);

        WWW www = new WWW(InitPhantomUrl, form);
        yield return www;

        result = www.text;

        if (result == "PhantomUpdate")
        {
            Debug.Log("Phantom Initializing Complete!!!");
            loadingPercent += 0.1f;
        }
    }

    IEnumerator PhantomLockInfo()
    {
        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = NewIDRecord.userNumber;

        yield return new WaitForSeconds(0.1f);

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);

        WWW www = new WWW(InitPhantomLockUrl, form);
        yield return www;

        result = www.text;

        if (result == "PhantomLockUpdate")
        {
            Debug.Log("Phantom Lock Initializing Complete!!!");
            loadingPercent += 0.1f;
        }
    }

    IEnumerator PhantomSkinInfo()
    {
        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = NewIDRecord.userNumber;

        yield return new WaitForSeconds(0.1f);

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);

        WWW www = new WWW(InitPhantomSkinUrl, form);
        yield return www;

        result = www.text;

        if (result == "PhantomSkinUpdate")
        {
            Debug.Log("Phantom Skin Initializing Complete!!!");
            loadingPercent += 0.1f;
        }
    }

    IEnumerator AirCraftInfo()
    {
        string hash = Md5Sum(secretKey).ToLower();
        int userUniqueNumber = NewIDRecord.userNumber;

        yield return new WaitForSeconds(0.2f);

        WWWForm form = new WWWForm();

        form.AddField("hash", hash);
        form.AddField("User_Number", userUniqueNumber);

        WWW www = new WWW(InitAircraftUrl, form);
        yield return www;

        result = www.text;

        if (result == "AircraftInfoUpdate")
        {
            Debug.Log("AircraftInfo Initializing Complete!!!");
            loadingPercent += 0.05f;
        }
    }


    public string Md5Sum(string input)
    {
        // step 1, calculate MD5 hash from input
        System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create();
        byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
        byte[] hash = md5.ComputeHash(inputBytes);

        // step 2, convert byte array to hex string
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < hash.Length; i++)
        {
            sb.Append(hash[i].ToString("X2"));
        }
        return sb.ToString();
    }
}
