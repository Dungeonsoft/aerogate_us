using UnityEngine;
using System.Collections;
using System.Text;
using System.Security;

public class UniqueLogin : MonoBehaviour
{
    private string secretKey = "12345";
    public string wwwResult;
    public string LoginUrl = "http://leessoda.cafe24.com/unique_login.php";
    public string FindUserInfoUrl = "http://leessoda.cafe24.com/get_userunique.php";
    public string DelUserInfoUrl = "http://leessoda.cafe24.com/del_userunique.php";
    public string VersionUrl = "http://leessoda.cafe24.com/ver_check.php";
    public static int userInitialize = 0;
    public static int userUniNumber = 0;
    public static string userUnique;
    public GameObject loadingText;
    public GameObject newIDWindow;
    public GameObject findID;
    public GameObject inputIdWindow;
    public GameObject verCheckWindow;

    public static UniqueLogin instance;

    bool isStart = false;
    void Awake()
    {
        UniqueLogin.instance = this;
    }

    public void SetStart()
    {
        ForKaKao.instance._ui.text += " UniqueLogin SetStart True ";

        //StartCoroutine(CheckVersion());   //ý���� �������� �ӽ� �ּ�ó��.(������ �߰��� ����)
        GameObject.Find("GetUserInfoManager").SendMessage("GetGameInfo");   //ý������ ���ϰԵǸ� �� �޼ҵ尡 ������ �ȵǴ� �̺κи� ���� ��� �����ϵ��� �ӽ÷� 100���ٿ��� ������.

        //userInitialize = 0;
        //PlayerPrefs.SetInt("userInitalizing", userInitialize);
        userInitialize = PlayerPrefs.GetInt("userInitalizing");
        isStart = true;

    }

    void Update()
    {
        if (!isStart) return;   //SetStart �� ������� ������ ������ ����.


        if (inputIdWindow == false)
        {
            loadingText.SetActive(false);
        }
        else
        {
            loadingText.SetActive(true);
        }

    }

    IEnumerator CheckUserUnique()
    {
        //string userUnique = SystemInfo.deviceUniqueIdentifier;

        string userUnique = SystemInfo.deviceUniqueIdentifier;
        userUniNumber = PlayerPrefs.GetInt("UserUnique");
        string hash = Md5Sum(secretKey).ToLower();

        yield return null;

        WWWForm form = new WWWForm();

        form.AddField("Unique_number", userUniNumber);
        form.AddField("hash", hash);

        WWW www = new WWW(LoginUrl, form);
        yield return www;

        wwwResult = www.text;

        if (wwwResult == "UniqueNameFalse")
        {
            Debug.Log("User Not Exits!!!!!!!!!!!!!!!!!");
            Debug.Log(wwwResult);
            newIDWindow.SetActive(true);
        }
        else
        {
            if (userInitialize == 0)
            {
                Debug.Log("Not Initializing");
                //findID.SetActive(true);
            }
            else
            {
                Debug.Log("Initializing Complete");
                newIDWindow.SetActive(false);
                loadingText.GetComponent<UILabel>().text = "Yout User Code is " + PlayerPrefs.GetInt("UserUnique");
                yield return new WaitForSeconds(1.0f);
                GameObject.Find("GetUserInfoManager").SendMessage("GetGameInfo");
            }
        }
    }

    IEnumerator FindID()
    {
        string userUnique = SystemInfo.deviceUniqueIdentifier;
        string hash = Md5Sum(userUnique + secretKey).ToLower();

        WWWForm form = new WWWForm();

        form.AddField("Unique_name", userUnique);
        form.AddField("hash", hash);

        WWW www = new WWW(FindUserInfoUrl, form);
        yield return www;

        wwwResult = www.text;
        NewIDRecord.userNumber = int.Parse(wwwResult);

        PlayerPrefs.SetInt("UserUnique", NewIDRecord.userNumber);

        int userNumberUnique = PlayerPrefs.GetInt("UserUnique");

        userInitialize = 1;
        PlayerPrefs.SetInt("userInitalizing", userInitialize);
        Debug.Log("User Number is  " + userNumberUnique);

        Application.LoadLevel("Loading");
    }

    IEnumerator DeleteID()
    {
        string userUnique = SystemInfo.deviceUniqueIdentifier;
        string hash = Md5Sum(userUnique + secretKey).ToLower();

        WWWForm form = new WWWForm();

        form.AddField("Unique_name", userUnique);
        form.AddField("hash", hash);

        WWW www = new WWW(FindUserInfoUrl, form);
        yield return www;

        wwwResult = www.text;

        Debug.Log(wwwResult);

    }

    IEnumerator DeleteFindID()
    {
        yield return StartCoroutine(DeleteID());

        int userIDNumber = int.Parse(wwwResult);
        string serverResult;
        string hash = Md5Sum(secretKey).ToLower();

        WWWForm form = new WWWForm();

        form.AddField("User_IDNumber", userIDNumber);
        form.AddField("hash", hash);

        Debug.Log(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>                 " + userIDNumber);
        WWW www = new WWW(DelUserInfoUrl, form);
        yield return www;

        serverResult = www.text;
        Debug.Log(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>                 " + serverResult);
        if (serverResult == "DeleteUserInformation")
        {
            Debug.Log("============== Delete " + wwwResult + " User Information ==============");
            Application.LoadLevel("Loading");
        }
    }
    IEnumerator CheckVersion()
    {
        ForKaKao.instance._ui.text += " UniqueLogin CheckVersion True ";

        string userUnique = SystemInfo.deviceUniqueIdentifier;
        string hash = Md5Sum(secretKey).ToLower();

        WWWForm form = new WWWForm();

        form.AddField("Version", ValueDeliverScript.ver);
        form.AddField("hash", hash);

        WWW www = new WWW(VersionUrl, form);
        yield return www;

        wwwResult = www.text;

        if (wwwResult == ValueDeliverScript.ver)
        {
            Debug.Log("<<<<<<<<<<<<<<<<<   Version Check Complete    >>>>>>>>>>>>>>>");
            verCheckWindow.SetActive(false);
            StartCoroutine(CheckUserUnique());
        }
        else
        {
            Debug.Log("Version is wrong!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
            Debug.Log(wwwResult);
            verCheckWindow.SetActive(true);
        }
    }
    public string Md5Sum(string input)
    {

        System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create();
        byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
        byte[] hash = md5.ComputeHash(inputBytes);


        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < hash.Length; i++)
        {
            sb.Append(hash[i].ToString("X2"));
        }
        return sb.ToString();
    }
}
