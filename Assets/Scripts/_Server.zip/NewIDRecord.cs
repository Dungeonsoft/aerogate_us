using UnityEngine;
using System.Collections;
using System.Text;
using System.Security;

public class NewIDRecord : MonoBehaviour {

	private string secretKey = "12345"; 
	private string result;
	public string RecordUserInfoUrl = "http://leessoda.cafe24.com/newid_record.php";
	
	public GameObject userNameLabel;
	public GameObject ServerManager;
	public GameObject newIDWindow;
	public GameObject loadingText;
	
	public static int userNumber;
	
	IEnumerator NewIDInsert()
	{
		string userUnique = SystemInfo.deviceUniqueIdentifier;
		string userName = userNameLabel.GetComponent<UILabel>().text;
		string hash = Md5Sum(secretKey).ToLower();
		
		newIDWindow.SetActive(false);
		yield return new WaitForSeconds(0.2f);
		
		WWWForm form = new WWWForm();
		
		form.AddField("Unique_name",userUnique);
		form.AddField("User_name", userName);
		form.AddField("hash",hash);
		
		WWW www = new WWW(RecordUserInfoUrl,form);
		yield return www;
		
		result = www.text;
		
		if(result == "updateSuccess")
		{
			Debug.Log(result);
			loadingText.GetComponent<UILabel>().text = result;
			ServerManager.SendMessage("GetUserUniqueNumber");
		}
		else
		{
			Debug.Log(result);
			loadingText.GetComponent<UILabel>().text = result;
			Debug.Log("Sign Up Failed !!!!!!!!!!!!!!!!");
		}
	}
	
	
	public string Md5Sum(string input)
	{
    	// step 1, calculate MD5 hash from input
    	System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create();
    	byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
    	byte[] hash = md5.ComputeHash(inputBytes);
 
    	// step 2, convert byte array to hex string
    	StringBuilder sb = new StringBuilder();
    	for (int i = 0; i < hash.Length; i++)
    	{
    	    sb.Append(hash[i].ToString("X2"));
    	}
    	return sb.ToString();
	}
}
