﻿using UnityEngine;
using System.Collections;
using System;
using System.Collections.Generic;


delegate void PicDataInput(Texture2D pic);

public class FaceBookUseScript : MonoBehaviour
{

    string status;

    public GameObject facebookBTN;
    public GameObject afterInitialObject;
    public UILabel labelAll;

    public static FaceBookUseScript instance;

    [System.NonSerialized]
    public bool logIn = false;


    void Awake()
    {
        FaceBookUseScript.instance = this;
        DontDestroyOnLoad(instance);
    }

    #region 이니셜라이징 부분 메소드 모음
    //최초 게임 구동시 이니셜라이징//

    //호출할 메소드//
    public void CallFBInit()
    {
        FB.Init(OnInitComplete, OnHideUnity);
    }

    private void OnInitComplete()
    {
        status = "FB.Init completed: Is user logged in? " + FB.IsLoggedIn;
        Debug.Log(status);
        labelAll.text += status + "\n";

        //이니셜후 할 내용을 적는 부분 상시 변경 가능//
        ///////////////////////////////////////////////////////////////////////////////
        if (FB.IsLoggedIn == true)  //로긴까지 성공//
        {
            logIn = true;
            facebookBTN.SetActive(false);
            CAPI_MyInfo();
            GameObject.Find("LogIn").SetActive(false);
        }
        else   //이니셜만 성공//
        {
            logIn = false;
            facebookBTN.SetActive(true);
        }
        ///////////////////////////////////////////////////////////////////////////////
        //이니셜후 할 내용을 적는 부분 상시 변경 가능//
        
        //이니셜이 되면 로그인도 되도록 메소드 호출//
        //Login();
    }

    public void CAPI_MyInfo()
    {
        ApiQuery = "me?fields=id,name";
        Debug.Log("Query :: " + ApiQuery);
        FB.API(ApiQuery, Facebook.HttpMethod.GET, CallbackMy);
        ApiQuery = "";

    }

    public string myFBid;
    public Texture2D myPic;

    void picInput(Texture2D pic)
    {
        myPic = pic;
        CAPI_BuddyInfo();//내사진 부르기가 끝나면 친구사진을 불러온다.
    }

    PicDataInput dePicInput;

    void CallbackMy(FBResult result)
    {
        Debug.Log("My Info ::");
        Debug.Log(":: Result ::\n" + result.Text);

        var dict = MiniJSON.Json.Deserialize(result.Text) as Dictionary<string, object>;

        Debug.Log("dict ID :: " + dict["id"]);
        myFBid = dict["id"].ToString();

        dePicInput = new PicDataInput(picInput);

        StartCoroutine(loadMyPic(myFBid));
    }

    IEnumerator loadMyPic(string id)
    {

        WWW url = new WWW("https" + "://graph.facebook.com/" + id + "/picture");

        yield return url;

        dePicInput(url.texture);
    }


    
    
    public void CAPI_BuddyInfo()
    {
        ApiQuery = "me/friends";
        Debug.Log("Query :: " + ApiQuery);
        FB.API(ApiQuery, Facebook.HttpMethod.GET, CallbackBuddy);
        ApiQuery = "";

    }

    //친구 사진을 담기 위한 해쉬테이블 변수 선언//
    public Hashtable FriendsPic = new Hashtable();


    void CallbackBuddy(FBResult result)
    {
        var dict = MiniJSON.Json.Deserialize(result.Text) as Dictionary<string, object>;
        List<object> AccountList = (List<object>)dict["data"];

        int FriendsCount = AccountList.Count;
        Debug.Log("Friend Count :: " + FriendsCount);

        foreach (Dictionary<string, object> Ac in AccountList)
        {
            Debug.Log("data ID - " + Ac["id"]);
            Debug.Log("data Name - " + Ac["name"]);

            string id = Ac["id"].ToString();
            StartCoroutine(loadFriendPic(id));
        }

        afterInitialObject.GetComponent<AfterInitialScript>().SetStart();
    }


    IEnumerator loadFriendPic(string id)
    {

        WWW url = new WWW("https" + "://graph.facebook.com/" + id + "/picture");
        yield return url;

        FriendsPic.Add(id, url.texture);
    }

    private void OnHideUnity(bool isGameShown)
    {
        status = "Is game showing? " + isGameShown;
        Debug.Log(status);
        labelAll.text += status + "\n";

    }
    //최초 게임 구동시 이니셜라이징//
    #endregion

    #region 로그인/아웃 부분 메소드 모음
    //페이스북 로그인 로그아웃//
    string lastResponse;

    //로그인시 호출//
    public void Login()
    {
        CallFBLogin();
        status = "Login called";
        labelAll.text += status + "\n";
    }

    private void CallFBLogin()
    {
        FB.Login("email,publish_actions", LoginCallback);
    }

    void LoginCallback(FBResult result)
    {
        if (result.Error != null)
            lastResponse = "Error Response:\n" + result.Error;
        else if (!FB.IsLoggedIn)
        {
            lastResponse = "Login cancelled by Player";
        }
        else
        {
            lastResponse = "Login was successful!";
            CAPI_MyInfo();
        }

        status = "last Response :: " + lastResponse + " ::";
        Debug.Log(status);
        labelAll.text += status + "\n";

        logIn = true;
    }

    //로그아웃시 호출//
    public void CallFBLogout()
    {
        FB.Logout();
        Debug.Log("Log Out Btn Click");
        //테스트용 임시//
        ///////////////////////////////////////////////////////////////////////////////
        //GameObject.Find("BTNs").transform.FindChild("LogIn").gameObject.SetActive(true);
        ///////////////////////////////////////////////////////////////////////////////
        //테스트용 임시//

    }
    //페이스북 로그인 로그아웃//
    #endregion

    #region 퍼블리시 인스톨 부분 메소드 모음

    //호출할 메소드//
    public void PublishInstall()
    {
        CallFBActivateApp();
        status = "Install Published";
        labelAll.text += status + "\n";

    }

    private void CallFBActivateApp()
    {
        FB.ActivateApp();
        Callback(new FBResult("Check Insights section for your app in the App Dashboard under \"Mobile App Installs\""));
    }
    #endregion

    #region 친구선택 관련 메소드 모음
    //기능 수행을 위해선 OpenFriendSelector()을 호출

    public string FriendSelectorTitle = "";
    public string FriendSelectorMessage = "Derp";
    public string FriendSelectorFilters = "[\"app_users\"]";
    public string FriendSelectorData = "{}";
    public string FriendSelectorExcludeIds = "";
    public string FriendSelectorMax = "";

    protected Texture2D lastResponseTexture;

    //호출할 메소드//
    public void OpenFriendSelector()
    {
        try
        {
            CallAppRequestAsFriendSelector();
            status = "Friend Selector called";
            labelAll.text += status + "\n";

        }
        catch (Exception e)
        {
            status = e.Message;
            labelAll.text += status + "\n";

        }
        status = "Status :: " + status + " ::";
        Debug.Log(status);
        labelAll.text += status + "\n";

    }

    private void CallAppRequestAsFriendSelector()
    {
        // If there's a Max Recipients specified, include it
        int? maxRecipients = null;
        if (FriendSelectorMax != "")
        {
            try
            {
                maxRecipients = Int32.Parse(FriendSelectorMax);
            }
            catch (Exception e)
            {
                status = e.Message;
                labelAll.text += status + "\n";
            }
        }

        // include the exclude ids
        string[] excludeIds = (FriendSelectorExcludeIds == "") ? null : FriendSelectorExcludeIds.Split(',');
        List<object> FriendSelectorFiltersArr = null;
        if (!String.IsNullOrEmpty(FriendSelectorFilters))
        {
            try
            {
                FriendSelectorFiltersArr = Facebook.MiniJSON.Json.Deserialize(FriendSelectorFilters) as List<object>;
            }
            catch
            {
                throw new Exception("JSON Parse error");
            }
        }

        FB.AppRequest(
            FriendSelectorMessage,
            null,
            FriendSelectorFiltersArr,
            excludeIds,
            maxRecipients,
            FriendSelectorData,
            FriendSelectorTitle,
            Callback
        );
    }

    protected void Callback(FBResult result)
    {
        lastResponseTexture = null;
        // Some platforms return the empty string instead of null.
        if (!String.IsNullOrEmpty(result.Error))
        {
            lastResponse = "Error Response:\n" + result.Error;
            status = lastResponse;
            labelAll.text += status + "\n";

        }
        else if (!String.IsNullOrEmpty(result.Text))
        {
            lastResponse = "Success Response:\n" + result.Text;
            status = lastResponse;
            labelAll.text += status + "\n";
        }
        else if (result.Texture != null)
        {
            lastResponseTexture = result.Texture;
            lastResponse = "Success Response: texture\n";
            status = lastResponse;
            labelAll.text += status + "\n";
        }
        else
        {
            lastResponse = "Empty Response\n";
            status = lastResponse;
            labelAll.text += status + "\n";
        }
    }
    #endregion

    #region 앱 요청 관련(Request) 메소드 모음
    //기능을 수행하기 위해선 무조건 OpenDirectRequest () 메소드를 호출


    public string DirectRequestTitle = "";
    public string DirectRequestMessage = "Herp";
    public string DirectRequestTo = "";

    //호출할 메소드//
    public void OpenDirectRequest()
    {
        try
        {
            CallAppRequestAsDirectRequest();
            status = "Direct Request called";
            labelAll.text += status + "\n";

        }
        catch (Exception e)
        {
            status = e.Message;
            labelAll.text += status + "\n";
        }
    }

    private void CallAppRequestAsDirectRequest()
    {
        if (DirectRequestTo == "")
        {
            throw new ArgumentException("\"To Comma Ids\" must be specificed", "to");
        }
        FB.AppRequest(
            DirectRequestMessage,
            DirectRequestTo.Split(','),
            null,
            null,
            null,
            "",
            DirectRequestTitle,
            Callback
        );
    }

    #endregion

    #region 피드 다이얼로그 호출 메소드 모음

    public string FeedToId = "";
    public string FeedLink = "";
    public string FeedLinkName = "";
    public string FeedLinkCaption = "";
    public string FeedLinkDescription = "";
    public string FeedPicture = "";
    public string FeedMediaSource = "";
    public string FeedActionName = "";
    public string FeedActionLink = "";
    public string FeedReference = "";
    public bool IncludeFeedProperties = false;
    private Dictionary<string, string[]> FeedProperties = new Dictionary<string, string[]>();


    //호출할 메소드//
    public void OpenFeedDialog()
    {
        try
        {
            CallFBFeed();
            status = "Feed dialog called";
        }
        catch (Exception e)
        {
            status = e.Message;
        }

        Debug.Log("Status :: " + status + " ::");
        status = "Status :: " + status + " ::";
        labelAll.text += status + "\n";

    }


    private void CallFBFeed()
    {
        Dictionary<string, string[]> feedProperties = null;
        if (IncludeFeedProperties)
        {
            feedProperties = FeedProperties;
        }
        FB.Feed(
            toId: FeedToId,
            link: FeedLink,
            linkName: FeedLinkName,
            linkCaption: FeedLinkCaption,
            linkDescription: FeedLinkDescription,
            picture: FeedPicture,
            mediaSource: FeedMediaSource,
            actionName: FeedActionName,
            actionLink: FeedActionLink,
            reference: FeedReference,
            properties: feedProperties,
            callback: Callback
        );
    }

    #endregion

    #region 콜API 메소드 모음
    public string ApiQuery = "";

    public void CallAPI()
    {
        status = "API called";
        labelAll.text += status + "\n";

        CallFBAPI();
    }

    private void CallFBAPI()
    {
        FB.API(ApiQuery, Facebook.HttpMethod.GET, Callback);
    }
    #endregion

    #region 스크린샷 관련 메소드 모음
    public void TakeUploadScreenshot()
    {
        status = "Take screenshot";
        labelAll.text += status + "\n";

        StartCoroutine(TakeScreenshot());

    }


    private IEnumerator TakeScreenshot()
    {
        yield return new WaitForEndOfFrame();

        var width = Screen.width;
        var height = Screen.height;
        var tex = new Texture2D(width, height, TextureFormat.RGB24, false);
        // Read screen contents into the texture
        tex.ReadPixels(new Rect(0, 0, width, height), 0, 0);
        tex.Apply();
        byte[] screenshot = tex.EncodeToPNG();

        var wwwForm = new WWWForm();
        wwwForm.AddBinaryData("image", screenshot, "InteractiveConsole.png");
        wwwForm.AddField("message", "herp derp.  I did a thing!  Did I do this right?");

        FB.API("me/photos", Facebook.HttpMethod.POST, Callback, wwwForm);
    }
    #endregion

    #region 딮링크 가져오는 메소드 모음
    public void GetDeepLink()
    {
        CallFBGetDeepLink();
    }
    private void CallFBGetDeepLink()
    {
        FB.GetDeepLink(Callback);
    }
    #endregion

    #region 페이스북앱이벤트 호출 관련 메소드
#if UNITY_IOS || UNITY_ANDROID
    public float PlayerLevel = 1.0f;

    public void LogFbAppEvent()
    {
        status = "Logged FB.AppEvent";
        labelAll.text += status + "\n";

        CallAppEventLogEvent();
    }

    public void CallAppEventLogEvent()
    {
        var parameters = new Dictionary<string, object>();
        parameters[Facebook.FBAppEventParameterName.Level] = "Player Level";
        FB.AppEvents.LogEvent(Facebook.FBAppEventName.AchievedLevel, PlayerLevel, parameters);
        PlayerLevel++;
    }

#endif
    #endregion
}