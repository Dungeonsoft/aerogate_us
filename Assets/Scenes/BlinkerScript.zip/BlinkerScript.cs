using UnityEngine;
using System.Collections;

public class BlinkerScript : MonoBehaviour {

    bool enable = true;

    public void Activate(float duraTime)
    {
        StartCoroutine(Blinker(duraTime));
    }

    IEnumerator Blinker(float duraTime)
    {
        float spendTime = 0;
        while (duraTime > spendTime)
        {
            renderer.enabled = !enable;
            spendTime += Time.deltaTime;
            yield return null;
        }
    }
}
